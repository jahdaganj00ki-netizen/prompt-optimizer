using System;
using System.IO;

namespace PromptOptimizer.Utils
{
    public static class Logger
    {
        private static readonly string LogDirectory = "logs";
        private static readonly string LogFile = Path.Combine(LogDirectory, $"log_{DateTime.Now:yyyyMMdd}.txt");

        static Logger()
        {
            try
            {
                if (!Directory.Exists(LogDirectory))
                    Directory.CreateDirectory(LogDirectory);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to create log directory: {ex.Message}");
            }
        }

        public static void Log(string message)
        {
            try
            {
                string logMessage = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] INFO: {message}";
                File.AppendAllText(LogFile, logMessage + Environment.NewLine);
                Console.WriteLine(logMessage);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to write log: {ex.Message}");
            }
        }

        public static void LogError(string message, Exception ex)
        {
            try
            {
                string logMessage = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] ERROR: {message}\n{ex.Message}\n{ex.StackTrace}";
                File.AppendAllText(LogFile, logMessage + Environment.NewLine);
                Console.WriteLine(logMessage);
            }
            catch (Exception logEx)
            {
                Console.WriteLine($"Failed to write error log: {logEx.Message}");
            }
        }

        public static void LogWarning(string message)
        {
            try
            {
                string logMessage = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] WARNING: {message}";
                File.AppendAllText(LogFile, logMessage + Environment.NewLine);
                Console.WriteLine(logMessage);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Failed to write warning log: {ex.Message}");
            }
        }
    }
}
