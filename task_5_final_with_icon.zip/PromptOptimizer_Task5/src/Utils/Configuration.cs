using System;
using System.Configuration;

namespace PromptOptimizer.Utils
{
    public static class Configuration
    {
        public static string DatabasePath => ConfigurationManager.AppSettings["DatabasePath"] ?? "prompt_optimizer.db";
        public static string LogPath => ConfigurationManager.AppSettings["LogPath"] ?? "logs/";
        public static string DefaultModel => ConfigurationManager.AppSettings["DefaultModel"] ?? "llama-3.3-70b-versatile";
        public static int MaxTokens => int.Parse(ConfigurationManager.AppSettings["MaxTokens"] ?? "2000");
        public static double Temperature => double.Parse(ConfigurationManager.AppSettings["Temperature"] ?? "0.7");
    }
}
