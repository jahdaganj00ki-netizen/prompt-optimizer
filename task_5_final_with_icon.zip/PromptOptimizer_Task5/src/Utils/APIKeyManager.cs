using System;
using System.IO;
using Newtonsoft.Json;

namespace PromptOptimizer.Utils
{
    public class APIKeyManager
    {
        private static readonly string AppDataFolder = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "PromptOptimizer"
        );
        private static readonly string KeyFilePath = Path.Combine(AppDataFolder, "api_keys.json");

        public class APIKeys
        {
            public string GroqApiKey { get; set; }
            public string GoogleApiKey { get; set; }
        }

        static APIKeyManager()
        {
            try
            {
                if (!Directory.Exists(AppDataFolder))
                    Directory.CreateDirectory(AppDataFolder);
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to create AppData folder", ex);
            }
        }

        public static void SaveKeys(string groqKey, string googleKey)
        {
            try
            {
                var keys = new APIKeys
                {
                    GroqApiKey = groqKey,
                    GoogleApiKey = googleKey
                };

                string json = JsonConvert.SerializeObject(keys, Formatting.Indented);
                File.WriteAllText(KeyFilePath, json);
                Logger.Log("API keys saved successfully");
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to save API keys", ex);
                throw;
            }
        }

        public static APIKeys LoadKeys()
        {
            try
            {
                if (!File.Exists(KeyFilePath))
                {
                    Logger.LogWarning("API key file not found");
                    return new APIKeys();
                }

                string json = File.ReadAllText(KeyFilePath);
                var keys = JsonConvert.DeserializeObject<APIKeys>(json);
                Logger.Log("API keys loaded successfully");
                return keys ?? new APIKeys();
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to load API keys", ex);
                return new APIKeys();
            }
        }

        public static bool HasGroqKey()
        {
            var keys = LoadKeys();
            return !string.IsNullOrWhiteSpace(keys.GroqApiKey);
        }

        public static bool HasGoogleKey()
        {
            var keys = LoadKeys();
            return !string.IsNullOrWhiteSpace(keys.GoogleApiKey);
        }
    }
}
