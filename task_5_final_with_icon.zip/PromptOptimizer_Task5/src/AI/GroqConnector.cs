using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PromptOptimizer.Utils;

namespace PromptOptimizer.AI
{
    public class GroqConnector
    {
        private readonly string apiKey;
        private readonly HttpClient httpClient;
        private const string ApiUrl = "https://api.groq.com/openai/v1/chat/completions";

        public GroqConnector(string apiKey)
        {
            this.apiKey = apiKey;
            this.httpClient = new HttpClient();
            this.httpClient.DefaultRequestHeaders.Add("Authorization", $"Bearer {apiKey}");
        }

        public async Task<string> OptimizePromptAsync(string prompt)
        {
            try
            {
                var systemPrompt = @"Du bist ein Experte für Prompt-Engineering. Deine Aufgabe ist es, 
Prompts zu analysieren und zu optimieren, um bessere Ergebnisse von KI-Modellen zu erhalten.

Optimiere den folgenden Prompt nach diesen Kriterien:
1. Klarheit: Mache die Anfrage eindeutig und verständlich
2. Spezifität: Füge relevante Details und Kontext hinzu
3. Struktur: Organisiere den Prompt logisch
4. Ziel: Definiere klar das gewünschte Ergebnis

Gib NUR den optimierten Prompt zurück, ohne Erklärungen oder Kommentare.";

                var requestBody = new
                {
                    model = Configuration.DefaultModel,
                    messages = new[]
                    {
                        new { role = "system", content = systemPrompt },
                        new { role = "user", content = prompt }
                    },
                    temperature = Configuration.Temperature,
                    max_tokens = Configuration.MaxTokens
                };

                string jsonRequest = JsonConvert.SerializeObject(requestBody);
                var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                Logger.Log($"Sending request to Groq API with model {Configuration.DefaultModel}");
                var response = await httpClient.PostAsync(ApiUrl, content);
                
                if (!response.IsSuccessStatusCode)
                {
                    string errorContent = await response.Content.ReadAsStringAsync();
                    Logger.LogWarning($"Groq API error: {response.StatusCode} - {errorContent}");
                    throw new Exception($"Groq API Fehler: {response.StatusCode}");
                }

                string jsonResponse = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<GroqResponse>(jsonResponse);

                if (result?.Choices != null && result.Choices.Length > 0)
                {
                    string optimizedPrompt = result.Choices[0].Message.Content;
                    Logger.Log("Groq optimization successful");
                    return optimizedPrompt;
                }

                throw new Exception("Keine Antwort von Groq erhalten");
            }
            catch (Exception ex)
            {
                Logger.LogError("Groq optimization failed", ex);
                throw;
            }
        }

        public async Task<bool> TestConnectionAsync()
        {
            try
            {
                var requestBody = new
                {
                    model = "llama-3.3-70b-versatile",
                    messages = new[]
                    {
                        new { role = "user", content = "Test" }
                    },
                    max_tokens = 10
                };

                string jsonRequest = JsonConvert.SerializeObject(requestBody);
                var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                var response = await httpClient.PostAsync(ApiUrl, content);
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Logger.LogError("Groq connection test failed", ex);
                return false;
            }
        }

        private class GroqResponse
        {
            [JsonProperty("choices")]
            public Choice[] Choices { get; set; }
        }

        private class Choice
        {
            [JsonProperty("message")]
            public Message Message { get; set; }
        }

        private class Message
        {
            [JsonProperty("content")]
            public string Content { get; set; }
        }
    }
}
