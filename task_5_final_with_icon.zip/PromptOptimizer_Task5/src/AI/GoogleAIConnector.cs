using System;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using PromptOptimizer.Utils;

namespace PromptOptimizer.AI
{
    public class GoogleAIConnector
    {
        private readonly string apiKey;
        private readonly HttpClient httpClient;
        private const string ApiUrlTemplate = "https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key={0}";

        public GoogleAIConnector(string apiKey)
        {
            this.apiKey = apiKey;
            this.httpClient = new HttpClient();
        }

        public async Task<string> OptimizePromptAsync(string prompt)
        {
            try
            {
                var systemPrompt = @"Du bist ein Experte für Prompt-Engineering. Optimiere den folgenden Prompt 
nach den Kriterien Klarheit, Spezifität, Struktur und Zieldefinition. 
Gib NUR den optimierten Prompt zurück, ohne Erklärungen.";

                var requestBody = new
                {
                    contents = new[]
                    {
                        new
                        {
                            parts = new[]
                            {
                                new { text = $"{systemPrompt}\n\nPrompt: {prompt}" }
                            }
                        }
                    },
                    generationConfig = new
                    {
                        temperature = Configuration.Temperature,
                        maxOutputTokens = Configuration.MaxTokens
                    }
                };

                string jsonRequest = JsonConvert.SerializeObject(requestBody);
                var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                string apiUrl = string.Format(ApiUrlTemplate, apiKey);
                Logger.Log("Sending request to Google AI API");
                
                var response = await httpClient.PostAsync(apiUrl, content);

                if (!response.IsSuccessStatusCode)
                {
                    string errorContent = await response.Content.ReadAsStringAsync();
                    Logger.LogWarning($"Google AI API error: {response.StatusCode} - {errorContent}");
                    throw new Exception($"Google AI API Fehler: {response.StatusCode}");
                }

                string jsonResponse = await response.Content.ReadAsStringAsync();
                var result = JsonConvert.DeserializeObject<GoogleResponse>(jsonResponse);

                if (result?.Candidates != null && result.Candidates.Length > 0)
                {
                    string optimizedPrompt = result.Candidates[0].Content.Parts[0].Text;
                    Logger.Log("Google AI optimization successful");
                    return optimizedPrompt;
                }

                throw new Exception("Keine Antwort von Google AI erhalten");
            }
            catch (Exception ex)
            {
                Logger.LogError("Google AI optimization failed", ex);
                throw;
            }
        }

        public async Task<bool> TestConnectionAsync()
        {
            try
            {
                var requestBody = new
                {
                    contents = new[]
                    {
                        new
                        {
                            parts = new[]
                            {
                                new { text = "Test" }
                            }
                        }
                    },
                    generationConfig = new
                    {
                        maxOutputTokens = 10
                    }
                };

                string jsonRequest = JsonConvert.SerializeObject(requestBody);
                var content = new StringContent(jsonRequest, Encoding.UTF8, "application/json");

                string apiUrl = string.Format(ApiUrlTemplate, apiKey);
                var response = await httpClient.PostAsync(apiUrl, content);
                
                return response.IsSuccessStatusCode;
            }
            catch (Exception ex)
            {
                Logger.LogError("Google AI connection test failed", ex);
                return false;
            }
        }

        private class GoogleResponse
        {
            [JsonProperty("candidates")]
            public Candidate[] Candidates { get; set; }
        }

        private class Candidate
        {
            [JsonProperty("content")]
            public Content Content { get; set; }
        }

        private class Content
        {
            [JsonProperty("parts")]
            public Part[] Parts { get; set; }
        }

        private class Part
        {
            [JsonProperty("text")]
            public string Text { get; set; }
        }
    }
}
