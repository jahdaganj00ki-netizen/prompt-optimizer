using System;
using System.Threading.Tasks;
using PromptOptimizer.Utils;

namespace PromptOptimizer.AI
{
    public class AIProvider
    {
        private GroqConnector groqConnector;
        private GoogleAIConnector googleConnector;
        private string currentProvider = "None";

        public string CurrentProvider => currentProvider;

        public void Initialize()
        {
            var keys = APIKeyManager.LoadKeys();

            if (!string.IsNullOrWhiteSpace(keys.GroqApiKey))
            {
                groqConnector = new GroqConnector(keys.GroqApiKey);
                currentProvider = "Groq";
                Logger.Log("Groq connector initialized");
            }

            if (!string.IsNullOrWhiteSpace(keys.GoogleApiKey))
            {
                googleConnector = new GoogleAIConnector(keys.GoogleApiKey);
                if (currentProvider == "None")
                    currentProvider = "Google AI";
                Logger.Log("Google AI connector initialized");
            }
        }

        public async Task<string> OptimizePromptAsync(string prompt)
        {
            // Versuche zuerst Groq
            if (groqConnector != null)
            {
                try
                {
                    Logger.Log("Attempting optimization with Groq");
                    currentProvider = "Groq";
                    return await groqConnector.OptimizePromptAsync(prompt);
                }
                catch (Exception ex)
                {
                    Logger.LogWarning($"Groq optimization failed, trying fallback: {ex.Message}");
                }
            }

            // Fallback zu Google AI
            if (googleConnector != null)
            {
                try
                {
                    Logger.Log("Attempting optimization with Google AI (fallback)");
                    currentProvider = "Google AI";
                    return await googleConnector.OptimizePromptAsync(prompt);
                }
                catch (Exception ex)
                {
                    Logger.LogError("Google AI optimization also failed", ex);
                    throw new Exception("Beide AI-Provider sind fehlgeschlagen. Bitte überprüfen Sie Ihre API-Keys.");
                }
            }

            throw new Exception("Keine API-Keys konfiguriert. Bitte konfigurieren Sie mindestens einen API-Key in den Einstellungen.");
        }

        public async Task<bool> TestGroqConnectionAsync()
        {
            if (groqConnector == null)
                return false;

            try
            {
                return await groqConnector.TestConnectionAsync();
            }
            catch (Exception ex)
            {
                Logger.LogError("Groq connection test failed", ex);
                return false;
            }
        }

        public async Task<bool> TestGoogleConnectionAsync()
        {
            if (googleConnector == null)
                return false;

            try
            {
                return await googleConnector.TestConnectionAsync();
            }
            catch (Exception ex)
            {
                Logger.LogError("Google connection test failed", ex);
                return false;
            }
        }

        public bool HasAnyProvider()
        {
            return groqConnector != null || googleConnector != null;
        }
    }
}
