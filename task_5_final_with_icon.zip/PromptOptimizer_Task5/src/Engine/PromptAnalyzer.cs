using System;
using System.Linq;
using System.Text.RegularExpressions;

namespace PromptOptimizer.Engine
{
    public class PromptAnalyzer
    {
        public AnalysisResult Analyze(string prompt)
        {
            if (string.IsNullOrWhiteSpace(prompt))
                return new AnalysisResult { IsValid = false, ErrorMessage = "Prompt ist leer" };

            var result = new AnalysisResult
            {
                IsValid = true,
                OriginalPrompt = prompt,
                WordCount = CountWords(prompt),
                CharacterCount = prompt.Length,
                SentenceCount = CountSentences(prompt),
                HasContext = CheckContext(prompt),
                HasSpecificity = CheckSpecificity(prompt),
                HasStructure = CheckStructure(prompt),
                ClarityScore = CalculateClarityScore(prompt),
                SpecificityScore = CalculateSpecificityScore(prompt),
                StructureScore = CalculateStructureScore(prompt)
            };

            result.OverallScore = CalculateOverallScore(result);
            result.Suggestions = GenerateSuggestions(result);

            return result;
        }

        private int CountWords(string text)
        {
            return text.Split(new[] { ' ', '\t', '\n', '\r' }, StringSplitOptions.RemoveEmptyEntries).Length;
        }

        private int CountSentences(string text)
        {
            return Regex.Matches(text, @"[.!?]+").Count;
        }

        private bool CheckContext(string prompt)
        {
            string[] contextKeywords = { "für", "über", "bezüglich", "im Kontext", "als", "wie", "warum", "wann", "wo" };
            return contextKeywords.Any(kw => prompt.ToLower().Contains(kw));
        }

        private bool CheckSpecificity(string prompt)
        {
            string[] specificityKeywords = { "genau", "spezifisch", "detailliert", "beispiel", "konkret", "präzise" };
            return specificityKeywords.Any(kw => prompt.ToLower().Contains(kw)) || prompt.Length > 50;
        }

        private bool CheckStructure(string prompt)
        {
            return CountSentences(prompt) > 1 || prompt.Contains("\n") || prompt.Contains(":");
        }

        private double CalculateClarityScore(string prompt)
        {
            double score = 50.0;

            // Länge
            if (prompt.Length > 20) score += 10;
            if (prompt.Length > 50) score += 10;

            // Satzstruktur
            int sentences = CountSentences(prompt);
            if (sentences > 0) score += 10;
            if (sentences > 1) score += 10;

            // Keine übermäßige Komplexität
            if (prompt.Length < 500) score += 10;

            return Math.Min(100, score);
        }

        private double CalculateSpecificityScore(string prompt)
        {
            double score = 30.0;

            // Spezifische Wörter
            string[] specificWords = { "genau", "spezifisch", "detailliert", "beispiel", "konkret", "präzise", "format", "stil" };
            score += specificWords.Count(w => prompt.ToLower().Contains(w)) * 10;

            // Zahlen und Details
            if (Regex.IsMatch(prompt, @"\d+")) score += 10;

            // Anführungszeichen (Beispiele)
            if (prompt.Contains("\"")) score += 10;

            return Math.Min(100, score);
        }

        private double CalculateStructureScore(string prompt)
        {
            double score = 40.0;

            // Mehrere Sätze
            if (CountSentences(prompt) > 1) score += 20;

            // Absätze oder Listen
            if (prompt.Contains("\n")) score += 15;

            // Doppelpunkte (Strukturierung)
            if (prompt.Contains(":")) score += 15;

            // Aufzählungen
            if (Regex.IsMatch(prompt, @"[1-9]\.|[-*•]")) score += 10;

            return Math.Min(100, score);
        }

        private double CalculateOverallScore(AnalysisResult result)
        {
            return (result.ClarityScore * 0.4 + result.SpecificityScore * 0.3 + result.StructureScore * 0.3);
        }

        private string GenerateSuggestions(AnalysisResult result)
        {
            var suggestions = new System.Text.StringBuilder();

            if (result.ClarityScore < 70)
                suggestions.AppendLine("• Formulieren Sie den Prompt klarer und verständlicher");

            if (result.SpecificityScore < 70)
                suggestions.AppendLine("• Fügen Sie mehr spezifische Details und Beispiele hinzu");

            if (result.StructureScore < 70)
                suggestions.AppendLine("• Strukturieren Sie den Prompt mit Absätzen oder Listen");

            if (result.WordCount < 10)
                suggestions.AppendLine("• Der Prompt ist sehr kurz - fügen Sie mehr Kontext hinzu");

            if (!result.HasContext)
                suggestions.AppendLine("• Geben Sie mehr Kontext für die gewünschte Ausgabe");

            if (suggestions.Length == 0)
                suggestions.AppendLine("• Ihr Prompt ist bereits gut strukturiert!");

            return suggestions.ToString();
        }
    }

    public class AnalysisResult
    {
        public bool IsValid { get; set; }
        public string ErrorMessage { get; set; }
        public string OriginalPrompt { get; set; }
        public int WordCount { get; set; }
        public int CharacterCount { get; set; }
        public int SentenceCount { get; set; }
        public bool HasContext { get; set; }
        public bool HasSpecificity { get; set; }
        public bool HasStructure { get; set; }
        public double ClarityScore { get; set; }
        public double SpecificityScore { get; set; }
        public double StructureScore { get; set; }
        public double OverallScore { get; set; }
        public string Suggestions { get; set; }
    }
}
