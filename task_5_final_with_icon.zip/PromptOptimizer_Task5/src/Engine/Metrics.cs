using System;

namespace PromptOptimizer.Engine
{
    public class Metrics
    {
        public string PromptId { get; set; }
        public DateTime Timestamp { get; set; }
        public string OriginalPrompt { get; set; }
        public string OptimizedPrompt { get; set; }
        public double OriginalScore { get; set; }
        public double OptimizedScore { get; set; }
        public double ImprovementPercentage { get; set; }
        public int OriginalWordCount { get; set; }
        public int OptimizedWordCount { get; set; }
        public string Provider { get; set; }

        public Metrics()
        {
            PromptId = Guid.NewGuid().ToString();
            Timestamp = DateTime.Now;
        }

        public void CalculateImprovement()
        {
            if (OriginalScore > 0)
            {
                ImprovementPercentage = ((OptimizedScore - OriginalScore) / OriginalScore) * 100;
            }
        }

        public override string ToString()
        {
            return $"Metrics [ID: {PromptId}, Provider: {Provider}, " +
                   $"Original Score: {OriginalScore:F2}, Optimized Score: {OptimizedScore:F2}, " +
                   $"Improvement: {ImprovementPercentage:F2}%]";
        }
    }
}
