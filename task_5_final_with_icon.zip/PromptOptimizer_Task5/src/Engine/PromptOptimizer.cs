using System;
using System.Text;
using PromptOptimizer.Utils;

namespace PromptOptimizer.Engine
{
    public class PromptOptimizer
    {
        private readonly PromptAnalyzer analyzer;

        public PromptOptimizer()
        {
            analyzer = new PromptAnalyzer();
        }

        public string OptimizeLocally(string prompt)
        {
            try
            {
                var analysis = analyzer.Analyze(prompt);
                
                if (!analysis.IsValid)
                    return prompt;

                var optimized = new StringBuilder(prompt);

                // Füge Kontext hinzu wenn fehlend
                if (!analysis.HasContext && analysis.WordCount < 20)
                {
                    optimized.Insert(0, "Kontext: ");
                }

                // Strukturiere wenn nötig
                if (!analysis.HasStructure && analysis.SentenceCount > 2)
                {
                    string structured = optimized.ToString().Replace(". ", ".\n\n");
                    optimized = new StringBuilder(structured);
                }

                // Füge Spezifität hinzu
                if (!analysis.HasSpecificity)
                {
                    optimized.Append("\n\nBitte geben Sie eine detaillierte und spezifische Antwort.");
                }

                Logger.Log($"Local optimization completed. Score: {analysis.OverallScore:F2}");
                return optimized.ToString();
            }
            catch (Exception ex)
            {
                Logger.LogError("Local optimization failed", ex);
                return prompt;
            }
        }

        public Metrics CreateMetrics(string original, string optimized, string provider)
        {
            var originalAnalysis = analyzer.Analyze(original);
            var optimizedAnalysis = analyzer.Analyze(optimized);

            var metrics = new Metrics
            {
                OriginalPrompt = original,
                OptimizedPrompt = optimized,
                OriginalScore = originalAnalysis.OverallScore,
                OptimizedScore = optimizedAnalysis.OverallScore,
                OriginalWordCount = originalAnalysis.WordCount,
                OptimizedWordCount = optimizedAnalysis.WordCount,
                Provider = provider
            };

            metrics.CalculateImprovement();
            return metrics;
        }
    }
}
