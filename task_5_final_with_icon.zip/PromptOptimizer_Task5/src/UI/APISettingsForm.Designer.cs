namespace PromptOptimizer
{
    partial class APISettingsForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Label lblGroqKey;
        private System.Windows.Forms.Label lblGoogleKey;
        private System.Windows.Forms.TextBox txtGroqKey;
        private System.Windows.Forms.TextBox txtGoogleKey;
        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnTestGroq;
        private System.Windows.Forms.Button btnTestGoogle;
        private System.Windows.Forms.Label lblInfo;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.lblGroqKey = new System.Windows.Forms.Label();
            this.lblGoogleKey = new System.Windows.Forms.Label();
            this.txtGroqKey = new System.Windows.Forms.TextBox();
            this.txtGoogleKey = new System.Windows.Forms.TextBox();
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnTestGroq = new System.Windows.Forms.Button();
            this.btnTestGoogle = new System.Windows.Forms.Button();
            this.lblInfo = new System.Windows.Forms.Label();
            this.SuspendLayout();
            
            // lblGroqKey
            this.lblGroqKey.AutoSize = true;
            this.lblGroqKey.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblGroqKey.Location = new System.Drawing.Point(20, 70);
            this.lblGroqKey.Name = "lblGroqKey";
            this.lblGroqKey.Size = new System.Drawing.Size(95, 19);
            this.lblGroqKey.TabIndex = 0;
            this.lblGroqKey.Text = "Groq API-Key:";
            
            // txtGroqKey
            this.txtGroqKey.Font = new System.Drawing.Font("Consolas", 9F);
            this.txtGroqKey.Location = new System.Drawing.Point(20, 95);
            this.txtGroqKey.Name = "txtGroqKey";
            this.txtGroqKey.Size = new System.Drawing.Size(400, 22);
            this.txtGroqKey.TabIndex = 1;
            this.txtGroqKey.UseSystemPasswordChar = true;
            
            // btnTestGroq
            this.btnTestGroq.BackColor = System.Drawing.Color.FromArgb(80, 184, 198);
            this.btnTestGroq.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTestGroq.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnTestGroq.ForeColor = System.Drawing.Color.White;
            this.btnTestGroq.Location = new System.Drawing.Point(435, 92);
            this.btnTestGroq.Name = "btnTestGroq";
            this.btnTestGroq.Size = new System.Drawing.Size(80, 28);
            this.btnTestGroq.TabIndex = 2;
            this.btnTestGroq.Text = "Testen";
            this.btnTestGroq.UseVisualStyleBackColor = false;
            this.btnTestGroq.Click += new System.EventHandler(this.btnTestGroq_Click);
            
            // lblGoogleKey
            this.lblGoogleKey.AutoSize = true;
            this.lblGoogleKey.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblGoogleKey.Location = new System.Drawing.Point(20, 140);
            this.lblGoogleKey.Name = "lblGoogleKey";
            this.lblGoogleKey.Size = new System.Drawing.Size(125, 19);
            this.lblGoogleKey.TabIndex = 3;
            this.lblGoogleKey.Text = "Google AI API-Key:";
            
            // txtGoogleKey
            this.txtGoogleKey.Font = new System.Drawing.Font("Consolas", 9F);
            this.txtGoogleKey.Location = new System.Drawing.Point(20, 165);
            this.txtGoogleKey.Name = "txtGoogleKey";
            this.txtGoogleKey.Size = new System.Drawing.Size(400, 22);
            this.txtGoogleKey.TabIndex = 4;
            this.txtGoogleKey.UseSystemPasswordChar = true;
            
            // btnTestGoogle
            this.btnTestGoogle.BackColor = System.Drawing.Color.FromArgb(80, 184, 198);
            this.btnTestGoogle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTestGoogle.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnTestGoogle.ForeColor = System.Drawing.Color.White;
            this.btnTestGoogle.Location = new System.Drawing.Point(435, 162);
            this.btnTestGoogle.Name = "btnTestGoogle";
            this.btnTestGoogle.Size = new System.Drawing.Size(80, 28);
            this.btnTestGoogle.TabIndex = 5;
            this.btnTestGoogle.Text = "Testen";
            this.btnTestGoogle.UseVisualStyleBackColor = false;
            this.btnTestGoogle.Click += new System.EventHandler(this.btnTestGoogle_Click);
            
            // lblInfo
            this.lblInfo.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblInfo.ForeColor = System.Drawing.Color.Gray;
            this.lblInfo.Location = new System.Drawing.Point(20, 15);
            this.lblInfo.Name = "lblInfo";
            this.lblInfo.Size = new System.Drawing.Size(495, 40);
            this.lblInfo.TabIndex = 6;
            this.lblInfo.Text = "Geben Sie mindestens einen API-Key ein. Groq wird als primärer Provider verwendet, Google AI als Fallback.";
            
            // btnSave
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(33, 150, 243);
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(300, 220);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 35);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Speichern";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);
            
            // btnCancel
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(158, 158, 158);
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(415, 220);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 35);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Abbrechen";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            
            // APISettingsForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(534, 275);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.lblInfo);
            this.Controls.Add(this.btnTestGoogle);
            this.Controls.Add(this.txtGoogleKey);
            this.Controls.Add(this.lblGoogleKey);
            this.Controls.Add(this.btnTestGroq);
            this.Controls.Add(this.txtGroqKey);
            this.Controls.Add(this.lblGroqKey);
            this.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "APISettingsForm";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "API-Einstellungen";
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}
