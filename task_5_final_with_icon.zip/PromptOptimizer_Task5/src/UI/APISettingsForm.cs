using System;
using System.Windows.Forms;
using PromptOptimizer.Utils;
using PromptOptimizer.AI;

namespace PromptOptimizer
{
    public partial class APISettingsForm : Form
    {
        public APISettingsForm()
        {
            InitializeComponent();
            LoadCurrentKeys();
        }

        private void LoadCurrentKeys()
        {
            try
            {
                var keys = APIKeyManager.LoadKeys();
                txtGroqKey.Text = keys.GroqApiKey ?? string.Empty;
                txtGoogleKey.Text = keys.GoogleApiKey ?? string.Empty;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to load API keys", ex);
            }
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                string groqKey = txtGroqKey.Text.Trim();
                string googleKey = txtGoogleKey.Text.Trim();

                if (string.IsNullOrWhiteSpace(groqKey) && string.IsNullOrWhiteSpace(googleKey))
                {
                    MessageBox.Show(
                        "Bitte geben Sie mindestens einen API-Key ein.",
                        "Eingabe erforderlich",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    return;
                }

                APIKeyManager.SaveKeys(groqKey, googleKey);
                this.DialogResult = DialogResult.OK;
                this.Close();
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to save API keys", ex);
                MessageBox.Show(
                    $"Fehler beim Speichern: {ex.Message}",
                    "Fehler",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        private async void btnTestGroq_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtGroqKey.Text))
            {
                MessageBox.Show(
                    "Bitte geben Sie einen Groq API-Key ein.",
                    "Eingabe erforderlich",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            try
            {
                btnTestGroq.Enabled = false;
                Cursor = Cursors.WaitCursor;

                var connector = new GroqConnector(txtGroqKey.Text.Trim());
                bool success = await connector.TestConnectionAsync();

                if (success)
                {
                    MessageBox.Show(
                        "Groq API-Key ist gültig!",
                        "Test erfolgreich",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
                else
                {
                    MessageBox.Show(
                        "Groq API-Key ist ungültig oder die Verbindung ist fehlgeschlagen.",
                        "Test fehlgeschlagen",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Groq test failed", ex);
                MessageBox.Show(
                    $"Fehler beim Testen: {ex.Message}",
                    "Fehler",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            finally
            {
                btnTestGroq.Enabled = true;
                Cursor = Cursors.Default;
            }
        }

        private async void btnTestGoogle_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtGoogleKey.Text))
            {
                MessageBox.Show(
                    "Bitte geben Sie einen Google AI API-Key ein.",
                    "Eingabe erforderlich",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            try
            {
                btnTestGoogle.Enabled = false;
                Cursor = Cursors.WaitCursor;

                var connector = new GoogleAIConnector(txtGoogleKey.Text.Trim());
                bool success = await connector.TestConnectionAsync();

                if (success)
                {
                    MessageBox.Show(
                        "Google AI API-Key ist gültig!",
                        "Test erfolgreich",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Information
                    );
                }
                else
                {
                    MessageBox.Show(
                        "Google AI API-Key ist ungültig oder die Verbindung ist fehlgeschlagen.",
                        "Test fehlgeschlagen",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Error
                    );
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Google AI test failed", ex);
                MessageBox.Show(
                    $"Fehler beim Testen: {ex.Message}",
                    "Fehler",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            finally
            {
                btnTestGoogle.Enabled = true;
                Cursor = Cursors.Default;
            }
        }
    }
}
