using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;
using PromptOptimizer.Engine;
using PromptOptimizer.AI;
using PromptOptimizer.Database;
using PromptOptimizer.Utils;

namespace PromptOptimizer
{
    public partial class MainForm : Form
    {
        private PromptAnalyzer analyzer;
        private Engine.PromptOptimizer optimizer;
        private AIProvider aiProvider;
        private DatabaseManager database;

        public MainForm()
        {
            InitializeComponent();
            InitializeApplication();
            LoadIcon();
        }

        private void LoadIcon()
        {
            try
            {
                string iconPath = Path.Combine(
                    Path.GetDirectoryName(Application.ExecutablePath),
                    "prompt_optimizer_icon.ico"
                );

                if (File.Exists(iconPath))
                {
                    this.Icon = new Icon(iconPath);
                    Logger.Log("Icon loaded successfully");
                }
                else
                {
                    Logger.LogWarning($"Icon file not found at: {iconPath}");
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to load icon", ex);
            }
        }

        private void InitializeApplication()
        {
            try
            {
                analyzer = new PromptAnalyzer();
                optimizer = new Engine.PromptOptimizer();
                aiProvider = new AIProvider();
                database = new DatabaseManager();

                aiProvider.Initialize();
                UpdateStatusBar();

                Logger.Log("Application initialized successfully");
            }
            catch (Exception ex)
            {
                Logger.LogError("Application initialization failed", ex);
                MessageBox.Show(
                    $"Fehler beim Initialisieren: {ex.Message}",
                    "Initialisierungsfehler",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void UpdateStatusBar()
        {
            if (statusLabel != null)
            {
                statusLabel.Text = $"Provider: {aiProvider.CurrentProvider}";
            }
        }

        private async void btnOptimize_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtInput.Text))
            {
                MessageBox.Show(
                    "Bitte geben Sie einen Prompt ein.",
                    "Eingabe erforderlich",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            try
            {
                btnOptimize.Enabled = false;
                btnAnalyze.Enabled = false;
                Cursor = Cursors.WaitCursor;

                string originalPrompt = txtInput.Text;
                Logger.Log("Starting prompt optimization");

                // Analysiere Original
                var originalAnalysis = analyzer.Analyze(originalPrompt);
                txtAnalysis.Text = $"Original-Score: {originalAnalysis.OverallScore:F2}\n\n{originalAnalysis.Suggestions}";

                // Optimiere mit AI
                string optimizedPrompt;
                if (aiProvider.HasAnyProvider())
                {
                    optimizedPrompt = await aiProvider.OptimizePromptAsync(originalPrompt);
                }
                else
                {
                    MessageBox.Show(
                        "Keine API-Keys konfiguriert. Bitte konfigurieren Sie Ihre API-Keys in den Einstellungen.",
                        "API-Keys fehlen",
                        MessageBoxButtons.OK,
                        MessageBoxIcon.Warning
                    );
                    return;
                }

                txtOutput.Text = optimizedPrompt;

                // Analysiere optimierten Prompt
                var optimizedAnalysis = analyzer.Analyze(optimizedPrompt);
                txtAnalysis.AppendText($"\n\nOptimiert-Score: {optimizedAnalysis.OverallScore:F2}");
                txtAnalysis.AppendText($"\nVerbesserung: {(optimizedAnalysis.OverallScore - originalAnalysis.OverallScore):F2} Punkte");

                // Speichere Metriken
                var metrics = optimizer.CreateMetrics(originalPrompt, optimizedPrompt, aiProvider.CurrentProvider);
                database.SaveMetrics(metrics);

                UpdateStatusBar();
                Logger.Log("Optimization completed successfully");
            }
            catch (Exception ex)
            {
                Logger.LogError("Optimization failed", ex);
                MessageBox.Show(
                    $"Fehler bei der Optimierung: {ex.Message}",
                    "Optimierungsfehler",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
            finally
            {
                btnOptimize.Enabled = true;
                btnAnalyze.Enabled = true;
                Cursor = Cursors.Default;
            }
        }

        private void btnAnalyze_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtInput.Text))
            {
                MessageBox.Show(
                    "Bitte geben Sie einen Prompt ein.",
                    "Eingabe erforderlich",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Warning
                );
                return;
            }

            try
            {
                var analysis = analyzer.Analyze(txtInput.Text);

                txtAnalysis.Text = $"=== ANALYSE-ERGEBNISSE ===\n\n";
                txtAnalysis.AppendText($"Wörter: {analysis.WordCount}\n");
                txtAnalysis.AppendText($"Zeichen: {analysis.CharacterCount}\n");
                txtAnalysis.AppendText($"Sätze: {analysis.SentenceCount}\n\n");
                txtAnalysis.AppendText($"Klarheit: {analysis.ClarityScore:F2}%\n");
                txtAnalysis.AppendText($"Spezifität: {analysis.SpecificityScore:F2}%\n");
                txtAnalysis.AppendText($"Struktur: {analysis.StructureScore:F2}%\n\n");
                txtAnalysis.AppendText($"Gesamt-Score: {analysis.OverallScore:F2}%\n\n");
                txtAnalysis.AppendText($"=== VORSCHLÄGE ===\n\n{analysis.Suggestions}");

                Logger.Log($"Analysis completed. Score: {analysis.OverallScore:F2}");
            }
            catch (Exception ex)
            {
                Logger.LogError("Analysis failed", ex);
                MessageBox.Show(
                    $"Fehler bei der Analyse: {ex.Message}",
                    "Analysefehler",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void btnSettings_Click(object sender, EventArgs e)
        {
            try
            {
                using (var settingsForm = new APISettingsForm())
                {
                    if (settingsForm.ShowDialog() == DialogResult.OK)
                    {
                        // Reinitialisiere AI Provider mit neuen Keys
                        aiProvider.Initialize();
                        UpdateStatusBar();
                        Logger.Log("API settings updated");

                        MessageBox.Show(
                            "API-Einstellungen wurden erfolgreich gespeichert.",
                            "Einstellungen gespeichert",
                            MessageBoxButtons.OK,
                            MessageBoxIcon.Information
                        );
                    }
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to open settings", ex);
                MessageBox.Show(
                    $"Fehler beim Öffnen der Einstellungen: {ex.Message}",
                    "Fehler",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            txtInput.Clear();
            txtOutput.Clear();
            txtAnalysis.Clear();
            txtInput.Focus();
        }

        private void btnCopy_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrWhiteSpace(txtOutput.Text))
            {
                Clipboard.SetText(txtOutput.Text);
                MessageBox.Show(
                    "Optimierter Prompt wurde in die Zwischenablage kopiert.",
                    "Kopiert",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Information
                );
            }
        }
    }
}
