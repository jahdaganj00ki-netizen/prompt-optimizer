using System;
using System.Data.SQLite;
using System.IO;
using PromptOptimizer.Utils;
using PromptOptimizer.Engine;

namespace PromptOptimizer.Database
{
    public class DatabaseManager
    {
        private readonly string connectionString;

        public DatabaseManager()
        {
            string dbPath = Configuration.DatabasePath;
            connectionString = $"Data Source={dbPath};Version=3;";
            InitializeDatabase();
        }

        private void InitializeDatabase()
        {
            try
            {
                if (!File.Exists(Configuration.DatabasePath))
                {
                    SQLiteConnection.CreateFile(Configuration.DatabasePath);
                    Logger.Log("Database file created");
                }

                using (var connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();

                    string createTableQuery = @"
                        CREATE TABLE IF NOT EXISTS Prompts (
                            Id TEXT PRIMARY KEY,
                            Timestamp TEXT NOT NULL,
                            OriginalPrompt TEXT NOT NULL,
                            OptimizedPrompt TEXT NOT NULL,
                            OriginalScore REAL,
                            OptimizedScore REAL,
                            ImprovementPercentage REAL,
                            OriginalWordCount INTEGER,
                            OptimizedWordCount INTEGER,
                            Provider TEXT
                        )";

                    using (var command = new SQLiteCommand(createTableQuery, connection))
                    {
                        command.ExecuteNonQuery();
                    }

                    Logger.Log("Database initialized successfully");
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Database initialization failed", ex);
            }
        }

        public void SaveMetrics(Metrics metrics)
        {
            try
            {
                using (var connection = new SQLiteConnection(connectionString))
                {
                    connection.Open();

                    string insertQuery = @"
                        INSERT INTO Prompts (Id, Timestamp, OriginalPrompt, OptimizedPrompt, 
                                           OriginalScore, OptimizedScore, ImprovementPercentage,
                                           OriginalWordCount, OptimizedWordCount, Provider)
                        VALUES (@Id, @Timestamp, @OriginalPrompt, @OptimizedPrompt,
                               @OriginalScore, @OptimizedScore, @ImprovementPercentage,
                               @OriginalWordCount, @OptimizedWordCount, @Provider)";

                    using (var command = new SQLiteCommand(insertQuery, connection))
                    {
                        command.Parameters.AddWithValue("@Id", metrics.PromptId);
                        command.Parameters.AddWithValue("@Timestamp", metrics.Timestamp.ToString("yyyy-MM-dd HH:mm:ss"));
                        command.Parameters.AddWithValue("@OriginalPrompt", metrics.OriginalPrompt);
                        command.Parameters.AddWithValue("@OptimizedPrompt", metrics.OptimizedPrompt);
                        command.Parameters.AddWithValue("@OriginalScore", metrics.OriginalScore);
                        command.Parameters.AddWithValue("@OptimizedScore", metrics.OptimizedScore);
                        command.Parameters.AddWithValue("@ImprovementPercentage", metrics.ImprovementPercentage);
                        command.Parameters.AddWithValue("@OriginalWordCount", metrics.OriginalWordCount);
                        command.Parameters.AddWithValue("@OptimizedWordCount", metrics.OptimizedWordCount);
                        command.Parameters.AddWithValue("@Provider", metrics.Provider);

                        command.ExecuteNonQuery();
                    }

                    Logger.Log($"Metrics saved to database: {metrics.PromptId}");
                }
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to save metrics to database", ex);
            }
        }
    }
}
