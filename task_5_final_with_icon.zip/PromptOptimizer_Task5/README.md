# Prompt Optimizer

Eine professionelle Windows Forms-Anwendung zur Analyse und Optimierung von Prompts für KI-Modelle.

## Features

- **Lokale Prompt-Analyse**: Bewertung von Klarheit, Spezifität und Struktur
- **AI-gestützte Optimierung**: Nutzung von Groq (primär) oder Google AI (Fallback)
- **Dual-Provider-System**: Automatisches Fallback bei Ausfall eines Providers
- **Sichere API-Key-Verwaltung**: Verschlüsselte Speicherung in AppData
- **Metriken & Tracking**: SQLite-Datenbank für Optimierungshistorie
- **Moderne UI**: Windows 11-Stil mit professionellem Icon

## Technologie-Stack

- **.NET Framework 4.7.2**
- **Windows Forms** für die Benutzeroberfläche
- **Newtonsoft.Json** für JSON-Verarbeitung
- **System.Data.SQLite** für Datenbankoperationen
- **Groq API** (llama-3.3-70b-versatile)
- **Google AI API** (gemini-pro)

## Installation

### Voraussetzungen

- Visual Studio 2022 (oder höher)
- .NET Framework 4.7.2
- Windows 10/11

### Lokales Build

1. Projekt in Visual Studio öffnen
2. NuGet-Pakete wiederherstellen
3. Projekt kompilieren (F5)

### API-Keys konfigurieren

1. Anwendung starten
2. "API-Einstellungen" Button klicken
3. Groq und/oder Google AI API-Keys eingeben
4. Keys mit "Testen" Button validieren
5. "Speichern" klicken

## Verwendung

1. **Original-Prompt eingeben**: Text in linkes Feld eingeben
2. **Analysieren**: Lokale Analyse ohne API-Aufruf
3. **Optimieren**: AI-gestützte Optimierung mit Groq/Google AI
4. **Ergebnis kopieren**: Optimierten Prompt in Zwischenablage kopieren

## Projektstruktur

```
PromptOptimizer/
├── src/
│   ├── UI/                     # Windows Forms UI-Komponenten
│   │   ├── MainForm.cs
│   │   └── APISettingsForm.cs
│   ├── Engine/                 # Lokale Analyse-Engine
│   │   ├── PromptAnalyzer.cs
│   │   ├── PromptOptimizer.cs
│   │   └── Metrics.cs
│   ├── AI/                     # AI-Provider-Integrationen
│   │   ├── GroqConnector.cs
│   │   ├── GoogleAIConnector.cs
│   │   └── AIProvider.cs
│   ├── Database/               # SQLite-Datenbankmanagement
│   │   └── DatabaseManager.cs
│   └── Utils/                  # Hilfsfunktionen
│       ├── Logger.cs
│       ├── Configuration.cs
│       └── APIKeyManager.cs
├── assets/
│   └── prompt_optimizer_icon.ico
├── PromptOptimizer.csproj
├── App.config
└── Program.cs
```

## Sicherheit

- API-Keys werden **niemals** im Quellcode gespeichert
- Sichere Speicherung in `%APPDATA%\PromptOptimizer\api_keys.json`
- `.gitignore` schließt `api_keys.json` aus
- Passwort-maskierte Eingabefelder

## Lizenz

Dieses Projekt ist Teil der Prompt Optimizer Task-Serie.

## Autor

Entwickelt mit Manus AI
