using System;
using System.Windows.Forms;
using PromptOptimizer.Utils;

namespace PromptOptimizer
{
    static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            
            try
            {
                Logger.Log("Starting Prompt Optimizer");
                MainForm mainForm = new MainForm();
                Application.Run(mainForm);
            }
            catch (Exception ex)
            {
                Logger.LogError("Application error", ex);
                MessageBox.Show(
                    $"Fehler: {ex.Message}",
                    "Fehler beim Starten",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error
                );
            }
        }
    }
}
