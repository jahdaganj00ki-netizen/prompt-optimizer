using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace PromptOptimizer.Engine
{
    /// <summary>
    /// Generiert lokale Optimierungsvorschläge für Prompts.
    /// Alle Vorschläge basieren auf Regeln, keine API-Aufrufe.
    /// </summary>
    public class PromptOptimizer
    {
        /// <summary>
        /// Datenstruktur für einen Optimierungsvorschlag.
        /// </summary>
        public class OptimizationSuggestion
        {
            /// <summary>
            /// Die ursprüngliche Phrase aus dem Prompt.
            /// </summary>
            public string OriginalPhrase { get; set; }

            /// <summary>
            /// Der vorgeschlagene Ersatz.
            /// </summary>
            public string SuggestedPhrase { get; set; }

            /// <summary>
            /// Begründung für den Vorschlag.
            /// </summary>
            public string Reason { get; set; }

            /// <summary>
            /// Kategorie des Vorschlags (Clarity, Specificity, Completeness).
            /// </summary>
            public string Category { get; set; }

            public override string ToString()
            {
                return $"[{Category}] {OriginalPhrase} → {SuggestedPhrase}\n  Grund: {Reason}";
            }
        }

        /// <summary>
        /// Sammlung von Optimierungsregeln.
        /// </summary>
        public static class OptimizationRules
        {
            /// <summary>
            /// Regel 1: Ersetze vage Wörter durch spezifische Alternativen.
            /// </summary>
            public static readonly Dictionary<string, string> VagueWordReplacements = new Dictionary<string, string>
            {
                // Deutsch
                { "gut", "hochwertig/effektiv/robust" },
                { "schlecht", "fehlerhaft/ineffizient/unzuverlässig" },
                { "sache", "Komponente/Modul/Funktion" },
                { "ding", "Element/Objekt/Entität" },
                { "zeug", "Material/Ressource/Inhalt" },
                { "irgendwie", "spezifisch durch [Methode]" },
                { "irgendwas", "konkret [Beispiel]" },
                { "mehr oder weniger", "ungefähr [Zahl]%" },
                { "einigermaßen", "teilweise/zu [Prozentsatz]" },
                { "ziemlich", "etwa [Prozentsatz]" },
                { "sehr", "deutlich/erheblich/signifikant" },
                
                // English
                { "good", "high-quality/effective/robust" },
                { "bad", "faulty/inefficient/unreliable" },
                { "thing", "component/module/function" },
                { "stuff", "material/resource/content" },
                { "nice", "well-designed/user-friendly/elegant" },
                { "cool", "innovative/efficient/elegant" },
                { "awesome", "excellent/outstanding/exceptional" },
                { "somehow", "specifically via [method]" },
                { "something", "specifically [example]" },
                { "kind of", "approximately [percentage]" },
                { "sort of", "somewhat/partially" }
            };

            /// <summary>
            /// Regel 2: Generische Aussagen konkretisieren.
            /// </summary>
            public static readonly Dictionary<string, string> GenericStatementReplacements = new Dictionary<string, string>
            {
                { "etc.", "und weitere spezifische Elemente" },
                { "und so weiter", "und folgende konkrete Punkte" },
                { "usw.", "mit Details" },
                { "and so on", "and the following specific items" },
                { "et cetera", "and other specific elements" },
                { "...", "mit konkreten Details" }
            };

            /// <summary>
            /// Regel 3: Mehrdeutige Pronomen klären.
            /// </summary>
            public static bool HasAmbiguousPronoun(string text)
            {
                var patterns = new[] { @"\bdieses?\b", @"\bjenes?\b", @"\bsolches?\b", 
                                       @"\bthis\b", @"\bthat\b", @"\bit\b" };
                return patterns.Any(p => Regex.IsMatch(text, p, RegexOptions.IgnoreCase));
            }

            /// <summary>
            /// Regel 4: Abstrakte Konzepte mit Beispielen versehen.
            /// </summary>
            public static string AddExamplesHint(string category)
            {
                return $"Füge konkrete Beispiele hinzu (z.B. mit 'zum Beispiel' oder 'wie')";
            }

            /// <summary>
            /// Regel 5: Implizite Annahmen klären.
            /// </summary>
            public static string ClarifyAssumptions()
            {
                return "Mache implizite Annahmen explizit (z.B. 'Angenommen, dass...')";
            }

            /// <summary>
            /// Regel 6: Format/Struktur vorschlagen.
            /// </summary>
            public static string SuggestFormat()
            {
                return "Definiere das erwartete Output-Format (JSON, CSV, Markdown, etc.)";
            }

            /// <summary>
            /// Regel 7: Constraints und Limits vorschlagen.
            /// </summary>
            public static string SuggestConstraints()
            {
                return "Spezifiziere Constraints (Größe, Zeit, Ressourcen, Limits)";
            }

            /// <summary>
            /// Regel 8: Erfolgskriterien vorschlagen.
            /// </summary>
            public static string SuggestSuccessCriteria()
            {
                return "Definiere, wie Erfolg gemessen wird (Metriken, Kriterien)";
            }
        }

        /// <summary>
        /// Generiert lokale Optimierungsvorschläge basierend auf der Analyse.
        /// </summary>
        /// <param name="originalPrompt">Der ursprüngliche Prompt</param>
        /// <param name="analysis">Die Analyse-Ergebnisse</param>
        /// <returns>Liste von 5-8 Optimierungsvorschlägen</returns>
        public static List<OptimizationSuggestion> GetLocalSuggestions(
            string originalPrompt,
            PromptAnalyzer.AnalysisResult analysis)
        {
            var suggestions = new List<OptimizationSuggestion>();

            if (string.IsNullOrWhiteSpace(originalPrompt))
                return suggestions;

            // Regel 1: Ersetze vage Wörter
            if (analysis.ClarityScore < 6)
            {
                suggestions.AddRange(GetVagueWordSuggestions(originalPrompt));
            }

            // Regel 2: Generische Aussagen
            if (analysis.SpecificityScore < 6)
            {
                suggestions.AddRange(GetGenericStatementSuggestions(originalPrompt));
            }

            // Regel 3: Mehrdeutige Pronomen
            if (OptimizationRules.HasAmbiguousPronoun(originalPrompt))
            {
                suggestions.Add(new OptimizationSuggestion
                {
                    OriginalPhrase = "Mehrdeutige Pronomen (dieses, jenes, das, es)",
                    SuggestedPhrase = "Ersetze Pronomen durch konkrete Substantive",
                    Reason = "Pronomen ohne klare Referenzen erzeugen Mehrdeutigkeit",
                    Category = "Clarity"
                });
            }

            // Regel 4: Beispiele hinzufügen
            if (analysis.SpecificityScore < 7 && !HasExamples(originalPrompt))
            {
                suggestions.Add(new OptimizationSuggestion
                {
                    OriginalPhrase = "Abstrakte Konzepte ohne Beispiele",
                    SuggestedPhrase = "Füge konkrete Beispiele hinzu (z.B. 'zum Beispiel', 'wie')",
                    Reason = "Konkrete Beispiele erhöhen die Verständlichkeit erheblich",
                    Category = "Specificity"
                });
            }

            // Regel 5: Implizite Annahmen klären
            if (analysis.CompletenessScore < 6)
            {
                suggestions.Add(new OptimizationSuggestion
                {
                    OriginalPhrase = "Implizite Annahmen",
                    SuggestedPhrase = "Mache Annahmen explizit (z.B. 'Angenommen, dass...')",
                    Reason = "Explizite Annahmen vermeiden Missverständnisse",
                    Category = "Completeness"
                });
            }

            // Regel 6: Format/Struktur
            if (!HasFormatDefinition(originalPrompt) && analysis.SpecificityScore < 7)
            {
                suggestions.Add(new OptimizationSuggestion
                {
                    OriginalPhrase = "Kein definiertes Output-Format",
                    SuggestedPhrase = "Definiere das erwartete Format (JSON, CSV, Markdown, etc.)",
                    Reason = "Ein klares Format reduziert Interpretationsspielraum",
                    Category = "Specificity"
                });
            }

            // Regel 7: Constraints
            if (!HasConstraints(originalPrompt) && analysis.CompletenessScore < 7)
            {
                suggestions.Add(new OptimizationSuggestion
                {
                    OriginalPhrase = "Keine Constraints oder Limits",
                    SuggestedPhrase = "Spezifiziere Grenzen (Größe, Zeit, Ressourcen, Limits)",
                    Reason = "Constraints helfen, realistische Erwartungen zu setzen",
                    Category = "Completeness"
                });
            }

            // Regel 8: Erfolgskriterien
            if (!HasSuccessCriteria(originalPrompt) && analysis.CompletenessScore < 7)
            {
                suggestions.Add(new OptimizationSuggestion
                {
                    OriginalPhrase = "Keine Erfolgskriterien",
                    SuggestedPhrase = "Definiere Erfolgskriterien (Metriken, Qualitätsmaßstäbe)",
                    Reason = "Erfolgskriterien ermöglichen objektive Bewertung",
                    Category = "Completeness"
                });
            }

            // Begrenze auf 5-8 Vorschläge
            return suggestions.Take(8).ToList();
        }

        #region Helper Methods

        /// <summary>
        /// Generiert Vorschläge für vage Wörter.
        /// </summary>
        private static List<OptimizationSuggestion> GetVagueWordSuggestions(string prompt)
        {
            var suggestions = new List<OptimizationSuggestion>();
            string lowerPrompt = prompt.ToLower();

            foreach (var vagueWord in OptimizationRules.VagueWordReplacements.Keys)
            {
                if (Regex.IsMatch(lowerPrompt, @"\b" + Regex.Escape(vagueWord) + @"\b"))
                {
                    suggestions.Add(new OptimizationSuggestion
                    {
                        OriginalPhrase = vagueWord,
                        SuggestedPhrase = OptimizationRules.VagueWordReplacements[vagueWord],
                        Reason = $"'{vagueWord}' ist vage - verwende spezifischere Begriffe",
                        Category = "Clarity"
                    });

                    // Begrenze auf 3 Vorschläge für vage Wörter
                    if (suggestions.Count >= 3)
                        break;
                }
            }

            return suggestions;
        }

        /// <summary>
        /// Generiert Vorschläge für generische Aussagen.
        /// </summary>
        private static List<OptimizationSuggestion> GetGenericStatementSuggestions(string prompt)
        {
            var suggestions = new List<OptimizationSuggestion>();

            foreach (var genericStatement in OptimizationRules.GenericStatementReplacements.Keys)
            {
                if (prompt.Contains(genericStatement, StringComparison.OrdinalIgnoreCase))
                {
                    suggestions.Add(new OptimizationSuggestion
                    {
                        OriginalPhrase = genericStatement,
                        SuggestedPhrase = OptimizationRules.GenericStatementReplacements[genericStatement],
                        Reason = $"'{genericStatement}' ist zu generisch - sei präzise",
                        Category = "Specificity"
                    });

                    // Begrenze auf 2 Vorschläge für generische Aussagen
                    if (suggestions.Count >= 2)
                        break;
                }
            }

            return suggestions;
        }

        /// <summary>
        /// Prüft, ob der Prompt Beispiele enthält.
        /// </summary>
        private static bool HasExamples(string prompt)
        {
            var examplePatterns = new[] { 
                @"(z\.?b\.?|beispiel|zum beispiel|beispielsweise|e\.?g\.?|for example|such as|like)",
                @"(""[^""]+"")",
                @"('([^']+)')"
            };

            return examplePatterns.Any(pattern => 
                Regex.IsMatch(prompt, pattern, RegexOptions.IgnoreCase));
        }

        /// <summary>
        /// Prüft, ob ein Format definiert ist.
        /// </summary>
        private static bool HasFormatDefinition(string prompt)
        {
            var formatPatterns = new[] { 
                @"(format|struktur|layout|template|vorlage|schema)",
                @"(json|xml|csv|html|markdown|pdf|docx|xlsx)",
                @"(tabelle|liste|array|objekt|dict|map)"
            };

            return formatPatterns.Any(pattern => 
                Regex.IsMatch(prompt, pattern, RegexOptions.IgnoreCase));
        }

        /// <summary>
        /// Prüft, ob Constraints erwähnt sind.
        /// </summary>
        private static bool HasConstraints(string prompt)
        {
            var constraintPatterns = new[] { 
                @"(limit|limitierung|beschränkung|maximal|minimal|nicht mehr als|nicht weniger als)",
                @"(constraint|restriction|limitation|max|min|no more than|no less than|within)",
                @"(performance|speicher|speicherplatz|zeit|timeout|größe)"
            };

            return constraintPatterns.Any(pattern => 
                Regex.IsMatch(prompt, pattern, RegexOptions.IgnoreCase));
        }

        /// <summary>
        /// Prüft, ob Erfolgskriterien definiert sind.
        /// </summary>
        private static bool HasSuccessCriteria(string prompt)
        {
            var criteriaPatterns = new[] { 
                @"(erfolgskriterium|erfolgskriterien|kriterium|erfolg|erfolgreich)",
                @"(success criteria|success condition|measure|metric|kpi)",
                @"(richtig|korrekt|gültig|valid|correct|accurate)"
            };

            return criteriaPatterns.Any(pattern => 
                Regex.IsMatch(prompt, pattern, RegexOptions.IgnoreCase));
        }

        #endregion
    }
}
