using System;
using System.Collections.Generic;
using System.Linq;

namespace PromptOptimizer.Engine.Tests
{
    /// <summary>
    /// Unit Tests für PromptAnalyzer und PromptOptimizer.
    /// Testet die lokalen Scoring-Algorithmen.
    /// </summary>
    public class PromptAnalyzerTests
    {
        /// <summary>
        /// Test 1: Sehr vager Prompt sollte niedrige Scores haben.
        /// </summary>
        public static void TestVaguePrompt()
        {
            string vaguePrompt = "Make a website";
            var result = PromptAnalyzer.Analyze(vaguePrompt);

            Console.WriteLine("Test 1: Vager Prompt");
            Console.WriteLine($"  Input: '{vaguePrompt}'");
            Console.WriteLine($"  Clarity: {result.ClarityScore:F1}/10 (erwartet: <5)");
            Console.WriteLine($"  Specificity: {result.SpecificityScore:F1}/10 (erwartet: <5)");
            Console.WriteLine($"  Completeness: {result.CompletenessScore:F1}/10 (erwartet: <5)");
            Console.WriteLine($"  Overall: {result.OverallScore:F1}/10");
            Console.WriteLine($"  Rating: {PromptAnalyzer.GetQualityRating(result.OverallScore)}");
            Console.WriteLine($"  Issues: {string.Join("; ", result.IssuesList)}");
            Console.WriteLine();

            // Assertions
            if (result.ClarityScore >= 5 || result.SpecificityScore >= 5 || result.CompletenessScore >= 5)
                Console.WriteLine("  ⚠ WARNUNG: Scores sollten niedriger sein!");
            else
                Console.WriteLine("  ✓ PASS: Scores sind angemessen niedrig");
            Console.WriteLine();
        }

        /// <summary>
        /// Test 2: Spezifischer Prompt sollte höhere Scores haben.
        /// </summary>
        public static void TestSpecificPrompt()
        {
            string specificPrompt = "Create a responsive e-commerce website using React and Node.js. " +
                                   "The site should support product catalog, shopping cart, and payment processing. " +
                                   "Use JSON for API responses and PostgreSQL for the database. " +
                                   "Performance requirement: page load < 2 seconds. " +
                                   "Success criteria: 95% test coverage and zero critical bugs.";

            var result = PromptAnalyzer.Analyze(specificPrompt);

            Console.WriteLine("Test 2: Spezifischer Prompt");
            Console.WriteLine($"  Input: '{specificPrompt.Substring(0, 60)}...'");
            Console.WriteLine($"  Clarity: {result.ClarityScore:F1}/10 (erwartet: >7)");
            Console.WriteLine($"  Specificity: {result.SpecificityScore:F1}/10 (erwartet: >8)");
            Console.WriteLine($"  Completeness: {result.CompletenessScore:F1}/10 (erwartet: >7)");
            Console.WriteLine($"  Overall: {result.OverallScore:F1}/10");
            Console.WriteLine($"  Rating: {PromptAnalyzer.GetQualityRating(result.OverallScore)}");
            Console.WriteLine($"  Keywords: {string.Join(", ", result.Keywords)}");
            Console.WriteLine();

            // Assertions
            if (result.ClarityScore < 7 || result.SpecificityScore < 8 || result.CompletenessScore < 7)
                Console.WriteLine("  ⚠ WARNUNG: Scores sollten höher sein!");
            else
                Console.WriteLine("  ✓ PASS: Scores sind angemessen hoch");
            Console.WriteLine();
        }

        /// <summary>
        /// Test 3: Extrem vager Prompt.
        /// </summary>
        public static void TestExtremelyVaguePrompt()
        {
            string extremelyVague = "I need help";
            var result = PromptAnalyzer.Analyze(extremelyVague);

            Console.WriteLine("Test 3: Extrem vager Prompt");
            Console.WriteLine($"  Input: '{extremelyVague}'");
            Console.WriteLine($"  Clarity: {result.ClarityScore:F1}/10 (erwartet: <3)");
            Console.WriteLine($"  Specificity: {result.SpecificityScore:F1}/10 (erwartet: <3)");
            Console.WriteLine($"  Completeness: {result.CompletenessScore:F1}/10 (erwartet: <3)");
            Console.WriteLine($"  Overall: {result.OverallScore:F1}/10");
            Console.WriteLine($"  Rating: {PromptAnalyzer.GetQualityRating(result.OverallScore)}");
            Console.WriteLine($"  Issues: {string.Join("; ", result.IssuesList)}");
            Console.WriteLine();

            // Assertions
            if (result.OverallScore >= 3)
                Console.WriteLine("  ⚠ WARNUNG: Score sollte sehr niedrig sein!");
            else
                Console.WriteLine("  ✓ PASS: Score ist sehr niedrig, wie erwartet");
            Console.WriteLine();
        }

        /// <summary>
        /// Test 4: Keyword-Extraktion.
        /// </summary>
        public static void TestKeywordExtraction()
        {
            string prompt = "Entwickle eine Python-Anwendung für Machine Learning mit TensorFlow. " +
                           "Die Anwendung sollte Bilder klassifizieren und eine REST API bereitstellen.";

            var result = PromptAnalyzer.Analyze(prompt);

            Console.WriteLine("Test 4: Keyword-Extraktion");
            Console.WriteLine($"  Input: '{prompt.Substring(0, 60)}...'");
            Console.WriteLine($"  Keywords: {string.Join(", ", result.Keywords)}");
            Console.WriteLine();

            // Assertions
            var expectedKeywords = new[] { "python", "machine learning", "tensorflow", "bilder", "api" };
            var foundKeywords = result.Keywords.Where(k => expectedKeywords.Any(e => k.Contains(e))).ToList();

            if (foundKeywords.Count >= 3)
                Console.WriteLine($"  ✓ PASS: {foundKeywords.Count} erwartete Keywords gefunden");
            else
                Console.WriteLine($"  ⚠ WARNUNG: Nur {foundKeywords.Count} erwartete Keywords gefunden");
            Console.WriteLine();
        }

        /// <summary>
        /// Test 5: Optimierungsvorschläge.
        /// </summary>
        public static void TestOptimizationSuggestions()
        {
            string prompt = "Make a good website with stuff for users to do things.";
            var analysis = PromptAnalyzer.Analyze(prompt);
            var suggestions = PromptOptimizer.GetLocalSuggestions(prompt, analysis);

            Console.WriteLine("Test 5: Optimierungsvorschläge");
            Console.WriteLine($"  Input: '{prompt}'");
            Console.WriteLine($"  Anzahl Vorschläge: {suggestions.Count}");
            Console.WriteLine($"  Vorschläge:");

            foreach (var suggestion in suggestions)
            {
                Console.WriteLine($"    [{suggestion.Category}] {suggestion.OriginalPhrase}");
                Console.WriteLine($"      → {suggestion.SuggestedPhrase}");
                Console.WriteLine($"      Grund: {suggestion.Reason}");
            }
            Console.WriteLine();

            // Assertions
            if (suggestions.Count >= 3)
                Console.WriteLine("  ✓ PASS: Ausreichend Vorschläge generiert");
            else
                Console.WriteLine("  ⚠ WARNUNG: Zu wenige Vorschläge");
            Console.WriteLine();
        }

        /// <summary>
        /// Test 6: Prompt-Vergleich.
        /// </summary>
        public static void TestPromptComparison()
        {
            string prompt1 = "Make a website";
            string prompt2 = "Create a responsive e-commerce website using React with product catalog, " +
                            "shopping cart, and payment integration. Use JSON for APIs and PostgreSQL for storage.";

            double comparison = PromptAnalyzer.ComparePrompts(prompt1, prompt2);

            Console.WriteLine("Test 6: Prompt-Vergleich");
            Console.WriteLine($"  Prompt 1: '{prompt1}'");
            Console.WriteLine($"  Prompt 2: '{prompt2.Substring(0, 60)}...'");
            Console.WriteLine($"  Vergleich Score: {comparison:F2}");

            if (comparison > 0)
                Console.WriteLine("  ✓ PASS: Prompt 2 ist besser (wie erwartet)");
            else
                Console.WriteLine("  ⚠ WARNUNG: Prompt 2 sollte besser sein!");
            Console.WriteLine();
        }

        /// <summary>
        /// Test 7: Leer-Prompt-Handling.
        /// </summary>
        public static void TestEmptyPrompt()
        {
            string emptyPrompt = "";
            var result = PromptAnalyzer.Analyze(emptyPrompt);

            Console.WriteLine("Test 7: Leer-Prompt-Handling");
            Console.WriteLine($"  Input: (leer)");
            Console.WriteLine($"  Overall Score: {result.OverallScore:F1}/10 (erwartet: 0)");
            Console.WriteLine($"  Issues: {string.Join("; ", result.IssuesList)}");
            Console.WriteLine();

            if (result.OverallScore == 0.0)
                Console.WriteLine("  ✓ PASS: Leer-Prompt wird korrekt behandelt");
            else
                Console.WriteLine("  ⚠ WARNUNG: Score sollte 0 sein!");
            Console.WriteLine();
        }

        /// <summary>
        /// Test 8: Performance-Test.
        /// </summary>
        public static void TestPerformance()
        {
            string prompt = "Create a responsive e-commerce website using React and Node.js. " +
                           "The site should support product catalog, shopping cart, and payment processing. " +
                           "Use JSON for API responses and PostgreSQL for the database. " +
                           "Performance requirement: page load < 2 seconds. " +
                           "Success criteria: 95% test coverage and zero critical bugs.";

            var stopwatch = System.Diagnostics.Stopwatch.StartNew();

            for (int i = 0; i < 100; i++)
            {
                PromptAnalyzer.Analyze(prompt);
            }

            stopwatch.Stop();
            double avgTime = stopwatch.ElapsedMilliseconds / 100.0;

            Console.WriteLine("Test 8: Performance");
            Console.WriteLine($"  100 Analysen durchgeführt");
            Console.WriteLine($"  Durchschnittliche Zeit: {avgTime:F2}ms (erwartet: <1000ms)");
            Console.WriteLine();

            if (avgTime < 1000)
                Console.WriteLine("  ✓ PASS: Performance ist ausreichend");
            else
                Console.WriteLine("  ⚠ WARNUNG: Performance ist zu langsam!");
            Console.WriteLine();
        }

        /// <summary>
        /// Führt alle Tests aus.
        /// </summary>
        public static void RunAllTests()
        {
            Console.WriteLine("========================================");
            Console.WriteLine("PromptAnalyzer & PromptOptimizer Tests");
            Console.WriteLine("========================================");
            Console.WriteLine();

            try
            {
                TestVaguePrompt();
                TestSpecificPrompt();
                TestExtremelyVaguePrompt();
                TestKeywordExtraction();
                TestOptimizationSuggestions();
                TestPromptComparison();
                TestEmptyPrompt();
                TestPerformance();

                Console.WriteLine("========================================");
                Console.WriteLine("Alle Tests abgeschlossen!");
                Console.WriteLine("========================================");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Fehler während der Tests: {ex.Message}");
                Console.WriteLine(ex.StackTrace);
            }
        }
    }

    /// <summary>
    /// Einfaches Test-Runner-Programm.
    /// </summary>
    public class Program
    {
        public static void Main(string[] args)
        {
            PromptAnalyzerTests.RunAllTests();
        }
    }
}
