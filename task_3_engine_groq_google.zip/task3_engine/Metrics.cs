using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;

namespace PromptOptimizer.Engine
{
    /// <summary>
    /// Hilfsfunktionen für Score-Berechnungen und Prompt-Analyse.
    /// Alle Berechnungen sind lokal (keine API-Aufrufe).
    /// </summary>
    public static class Metrics
    {
        #region Score Calculation Methods

        /// <summary>
        /// Berechnet den Clarity Score (0-10).
        /// Basierend auf: Satzstruktur, spezifische Verben, vage Wörter, Pronomen, aktive Stimme.
        /// </summary>
        public static double CalculateClarityScore(string prompt)
        {
            if (string.IsNullOrWhiteSpace(prompt))
                return 0.0;

            double score = 5.0; // Basis-Score

            // Prüfe auf klare Subjekt-Verb-Objekt-Struktur
            if (HasClearSVOStructure(prompt))
                score += 2.0;

            // Zähle spezifische Action Verben
            int specificVerbs = CountSpecificVerbs(prompt);
            score += Math.Min(specificVerbs * 1.0, 3.0); // Max +3.0

            // Penalisiere vage Wörter
            int vagueWords = CountVagueWords(prompt);
            score -= Math.Min(vagueWords * 0.5, 2.5); // Max -2.5

            // Penalisiere Pronomen ohne klare Referenzen
            if (HasAmbiguousPronoun(prompt))
                score -= 1.0;

            // Belohne aktive Stimme
            if (IsPredominallyActiveVoice(prompt))
                score += 1.0;

            return Math.Max(0.0, Math.Min(10.0, score));
        }

        /// <summary>
        /// Berechnet den Specificity Score (0-10).
        /// Basierend auf: Konkrete Beispiele, Zahlen, Domain-Kontext, generische Aussagen, Format.
        /// </summary>
        public static double CalculateSpecificityScore(string prompt)
        {
            if (string.IsNullOrWhiteSpace(prompt))
                return 0.0;

            double score = 4.0; // Basis-Score

            // Belohne konkrete Beispiele
            if (HasConcreteExamples(prompt))
                score += 1.5;

            // Belohne spezifische Zahlen/Metriken
            int numberCount = CountNumbers(prompt);
            score += Math.Min(numberCount * 1.0, 2.0); // Max +2.0

            // Belohne spezifische Domain/Kontext
            if (HasSpecificDomain(prompt))
                score += 1.5;

            // Penalisiere generische Aussagen
            int genericStatements = CountGenericStatements(prompt);
            score -= Math.Min(genericStatements * 1.0, 2.0); // Max -2.0

            // Belohne explizit definiertes Format/Struktur
            if (HasExplicitFormat(prompt))
                score += 2.0;

            return Math.Max(0.0, Math.Min(10.0, score));
        }

        /// <summary>
        /// Berechnet den Completeness Score (0-10).
        /// Basierend auf: Ziel, Constraints, Input/Output, Erfolgskriterien, Scope, Kontext.
        /// </summary>
        public static double CalculateCompletenessScore(string prompt)
        {
            if (string.IsNullOrWhiteSpace(prompt))
                return 0.0;

            double score = 5.0; // Basis-Score

            // Belohne klares Ziel/Zweck
            if (HasClearPurpose(prompt))
                score += 1.5;

            // Belohne erwähnte Constraints/Limitierungen
            if (HasConstraints(prompt))
                score += 1.5;

            // Belohne spezifiziertes Input/Output Format
            if (HasInputOutputFormat(prompt))
                score += 1.0;

            // Belohne definierte Erfolgskriterien
            if (HasSuccessCriteria(prompt))
                score += 1.5;

            // Belohne klaren Scope/Grenzen
            if (HasClearScope(prompt))
                score += 1.5;

            // Belohne Kontext/Hintergrund
            if (HasContext(prompt))
                score += 1.0;

            return Math.Max(0.0, Math.Min(10.0, score));
        }

        #endregion

        #region Keyword Extraction

        /// <summary>
        /// Extrahiert die wichtigsten Keywords aus einem Prompt.
        /// Filtert Stop-Wörter und sortiert nach Häufigkeit und Länge.
        /// </summary>
        public static List<string> ExtractKeywords(string prompt, int count = 8)
        {
            if (string.IsNullOrWhiteSpace(prompt))
                return new List<string>();

            // Normalisiere Text
            string normalizedText = prompt.ToLower();
            
            // Entferne Sonderzeichen, behalte Leerzeichen und Bindestriche
            normalizedText = Regex.Replace(normalizedText, @"[^\w\s\-]", " ");
            
            // Teile in Wörter auf
            string[] words = normalizedText.Split(new[] { ' ', '\t', '\n', '\r' }, 
                StringSplitOptions.RemoveEmptyEntries);

            // Filtere Stop-Wörter
            var stopWords = GetStopWords();
            var filteredWords = words
                .Where(w => !stopWords.Contains(w) && w.Length > 2)
                .ToList();

            // Berechne Häufigkeit
            var wordFrequency = new Dictionary<string, int>();
            foreach (var word in filteredWords)
            {
                if (wordFrequency.ContainsKey(word))
                    wordFrequency[word]++;
                else
                    wordFrequency[word] = 1;
            }

            // Sortiere nach Häufigkeit * Länge (bevorzugt längere Wörter)
            var topKeywords = wordFrequency
                .OrderByDescending(kvp => kvp.Value * Math.Log(kvp.Key.Length + 1))
                .Take(count)
                .Select(kvp => kvp.Key)
                .ToList();

            return topKeywords;
        }

        #endregion

        #region Issue Identification

        /// <summary>
        /// Identifiziert spezifische Probleme im Prompt basierend auf Analyse-Ergebnissen.
        /// </summary>
        public static List<string> IdentifyIssues(string prompt, AnalysisResult analysis)
        {
            var issues = new List<string>();

            if (analysis.ClarityScore < 6)
            {
                if (CountVagueWords(prompt) > 2)
                    issues.Add("Zu viele vage Wörter (z.B. 'gut', 'schlecht', 'Sache') - verwende spezifischere Begriffe");
                
                if (HasAmbiguousPronoun(prompt))
                    issues.Add("Mehrdeutige Pronomen (z.B. 'das', 'es', 'dies') ohne klare Referenzen");
                
                if (!HasClearSVOStructure(prompt))
                    issues.Add("Fehlende klare Subjekt-Verb-Objekt-Struktur - strukturiere Sätze deutlicher");
            }

            if (analysis.SpecificityScore < 6)
            {
                if (!HasConcreteExamples(prompt))
                    issues.Add("Keine konkreten Beispiele - füge spezifische Fälle hinzu");
                
                if (CountNumbers(prompt) == 0)
                    issues.Add("Keine Zahlen oder Metriken - quantifiziere Anforderungen");
                
                if (CountGenericStatements(prompt) > 1)
                    issues.Add("Generische Aussagen ('etc.', 'und so weiter') - sei präzise");
            }

            if (analysis.CompletenessScore < 6)
            {
                if (!HasClearPurpose(prompt))
                    issues.Add("Zweck/Ziel nicht klar - definiere, was erreicht werden soll");
                
                if (!HasInputOutputFormat(prompt))
                    issues.Add("Input/Output-Format nicht spezifiziert - beschreibe erwartete Formate");
                
                if (!HasSuccessCriteria(prompt))
                    issues.Add("Erfolgskriterien fehlen - definiere, wie Erfolg gemessen wird");
                
                if (!HasConstraints(prompt))
                    issues.Add("Einschränkungen/Limitierungen nicht erwähnt - spezifiziere Grenzen");
            }

            return issues;
        }

        #endregion

        #region Helper Methods - Word Lists

        /// <summary>
        /// Gibt Liste von vagen Wörtern zurück.
        /// </summary>
        private static List<string> GetVagueWords()
        {
            return new List<string>
            {
                "gut", "schlecht", "sache", "ding", "zeug", "irgendwie", "irgendwas",
                "mehr oder weniger", "einigermaßen", "ziemlich", "recht", "sehr",
                "nice", "cool", "awesome", "good", "bad", "thing", "stuff", "something",
                "somehow", "somewhat", "kind of", "sort of", "basically", "essentially",
                "apparently", "supposedly", "possibly", "maybe", "perhaps"
            };
        }

        /// <summary>
        /// Gibt Liste von Stop-Wörtern zurück (häufige, wenig aussagekräftige Wörter).
        /// </summary>
        private static List<string> GetStopWords()
        {
            return new List<string>
            {
                // Deutsch
                "der", "die", "das", "den", "dem", "des", "ein", "eine", "einem", "einen",
                "einer", "eines", "und", "oder", "aber", "doch", "sondern", "weil", "da",
                "wenn", "falls", "als", "wie", "wo", "wann", "warum", "was", "wer", "wem",
                "wen", "wessen", "ist", "sind", "bin", "bist", "seid", "war", "waren",
                "sein", "zu", "von", "mit", "in", "auf", "an", "für", "bei", "durch",
                "um", "nach", "vor", "über", "unter", "zwischen", "neben", "gegen",
                "ohne", "außer", "seit", "während", "trotz", "wegen", "statt", "anstatt",
                "ich", "du", "er", "sie", "es", "wir", "ihr", "sie", "mich", "dich",
                "uns", "euch", "mir", "dir", "ihm", "ihr", "ihnen", "sich", "mein",
                "dein", "sein", "ihr", "unser", "euer", "dieser", "jener", "solcher",
                "welcher", "jeder", "alle", "einige", "mehrere", "wenige", "viele",
                "einige", "andere", "gleiche", "verschiedene", "neue", "alte", "große",
                "kleine", "ganze", "halbe", "erste", "letzte", "nächste", "vorige",
                
                // English
                "the", "a", "an", "and", "or", "but", "in", "on", "at", "to", "for",
                "of", "with", "by", "from", "up", "about", "into", "through", "during",
                "before", "after", "above", "below", "between", "under", "again",
                "further", "then", "once", "here", "there", "when", "where", "why",
                "how", "all", "both", "each", "few", "more", "most", "other", "some",
                "such", "no", "nor", "not", "only", "own", "same", "so", "than",
                "too", "very", "can", "just", "should", "now", "is", "are", "be",
                "been", "being", "have", "has", "had", "do", "does", "did", "will",
                "would", "could", "ought", "i", "you", "he", "she", "it", "we", "they"
            };
        }

        /// <summary>
        /// Gibt Liste von spezifischen Indikatoren zurück (Wörter, die auf Spezifität hindeuten).
        /// </summary>
        private static List<string> GetSpecificIndicators()
        {
            return new List<string>
            {
                "erstellen", "generieren", "analysieren", "berechnen", "verarbeiten",
                "implementieren", "entwickeln", "optimieren", "verbessern", "testen",
                "validieren", "überprüfen", "formatieren", "konvertieren", "extrahieren",
                "filtern", "sortieren", "gruppieren", "aggregieren", "zusammenfassen",
                "create", "generate", "analyze", "calculate", "process", "implement",
                "develop", "optimize", "improve", "test", "validate", "verify",
                "format", "convert", "extract", "filter", "sort", "group", "aggregate"
            };
        }

        #endregion

        #region Helper Methods - Detection Functions

        /// <summary>
        /// Prüft, ob der Prompt eine klare Subjekt-Verb-Objekt-Struktur hat.
        /// </summary>
        private static bool HasClearSVOStructure(string prompt)
        {
            // Vereinfachte Heuristik: Suche nach Verben und Substantiven
            var actionVerbs = new[] { "erstelle", "generiere", "analysiere", "berechne", "verarbeite",
                "create", "generate", "analyze", "calculate", "process", "make", "build", "write" };
            
            string lowerPrompt = prompt.ToLower();
            return actionVerbs.Any(verb => lowerPrompt.Contains(verb));
        }

        /// <summary>
        /// Zählt spezifische Action-Verben im Prompt.
        /// </summary>
        private static int CountSpecificVerbs(string prompt)
        {
            var specificVerbs = GetSpecificIndicators();
            string lowerPrompt = prompt.ToLower();
            
            return specificVerbs.Count(verb => lowerPrompt.Contains(verb));
        }

        /// <summary>
        /// Zählt vage Wörter im Prompt.
        /// </summary>
        private static int CountVagueWords(string prompt)
        {
            var vagueWords = GetVagueWords();
            string lowerPrompt = prompt.ToLower();
            
            return vagueWords.Count(word => 
                Regex.IsMatch(lowerPrompt, @"\b" + Regex.Escape(word) + @"\b"));
        }

        /// <summary>
        /// Prüft, ob mehrdeutige Pronomen ohne klare Referenzen vorhanden sind.
        /// </summary>
        private static bool HasAmbiguousPronoun(string prompt)
        {
            var ambiguousPronounPatterns = new[] { 
                @"\bdieses?\b", @"\bjenes?\b", @"\bsolches?\b", 
                @"\bthis\b", @"\bthat\b", @"\bit\b" 
            };
            
            return ambiguousPronounPatterns.Any(pattern => 
                Regex.IsMatch(prompt, pattern, RegexOptions.IgnoreCase));
        }

        /// <summary>
        /// Prüft, ob der Prompt überwiegend aktive Stimme verwendet.
        /// </summary>
        private static bool IsPredominallyActiveVoice(string prompt)
        {
            // Vereinfachte Heuristik: Zähle "wird/werden" (Passiv) vs. aktive Verben
            int passiveIndicators = Regex.Matches(prompt, @"\b(wird|werden|wurde|wären|sei|seien)\b", 
                RegexOptions.IgnoreCase).Count;
            int activeVerbs = Regex.Matches(prompt, @"\b(erstelle|generiere|analysiere|berechne|verarbeite|create|generate|analyze|calculate|process)\b", 
                RegexOptions.IgnoreCase).Count;
            
            return activeVerbs > passiveIndicators;
        }

        /// <summary>
        /// Prüft, ob konkrete Beispiele vorhanden sind.
        /// </summary>
        private static bool HasConcreteExamples(string prompt)
        {
            // Suche nach Indikatoren für Beispiele
            var examplePatterns = new[] { 
                @"(z\.?b\.?|beispiel|zum beispiel|beispielsweise|e\.?g\.?|for example|such as|like)",
                @"(""[^""]+"")", // Zitate
                @"('([^']+)')" // Einfache Anführungszeichen
            };
            
            return examplePatterns.Any(pattern => 
                Regex.IsMatch(prompt, pattern, RegexOptions.IgnoreCase));
        }

        /// <summary>
        /// Zählt Zahlen/Metriken im Prompt.
        /// </summary>
        private static int CountNumbers(string prompt)
        {
            return Regex.Matches(prompt, @"\d+").Count;
        }

        /// <summary>
        /// Prüft, ob spezifische Domain/Kontext erwähnt wird.
        /// </summary>
        private static bool HasSpecificDomain(string prompt)
        {
            var domainKeywords = new[] { 
                "react", "python", "javascript", "c#", "sql", "html", "css",
                "machine learning", "ai", "database", "api", "web", "mobile",
                "desktop", "windows", "linux", "cloud", "aws", "azure",
                "e-commerce", "cms", "crm", "erp", "healthcare", "finance"
            };
            
            string lowerPrompt = prompt.ToLower();
            return domainKeywords.Any(keyword => lowerPrompt.Contains(keyword));
        }

        /// <summary>
        /// Zählt generische Aussagen im Prompt.
        /// </summary>
        private static int CountGenericStatements(string prompt)
        {
            var genericPatterns = new[] { 
                @"(etc\.?|und so weiter|usw\.?|und so on|et cetera|\.\.\.)"
            };
            
            return genericPatterns.Sum(pattern => 
                Regex.Matches(prompt, pattern, RegexOptions.IgnoreCase).Count);
        }

        /// <summary>
        /// Prüft, ob Format/Struktur explizit definiert ist.
        /// </summary>
        private static bool HasExplicitFormat(string prompt)
        {
            var formatPatterns = new[] { 
                @"(format|struktur|struktur|layout|template|vorlage|schema)",
                @"(json|xml|csv|html|markdown|pdf|docx|xlsx)",
                @"(tabelle|liste|array|objekt|dict|map)"
            };
            
            return formatPatterns.Any(pattern => 
                Regex.IsMatch(prompt, pattern, RegexOptions.IgnoreCase));
        }

        /// <summary>
        /// Prüft, ob Zweck/Ziel klar definiert ist.
        /// </summary>
        private static bool HasClearPurpose(string prompt)
        {
            var purposePatterns = new[] { 
                @"(ziel|zweck|soll|muss|sollte|ziel ist|zweck ist)",
                @"(goal|purpose|objective|aim|should|must|need to|want to)"
            };
            
            return purposePatterns.Any(pattern => 
                Regex.IsMatch(prompt, pattern, RegexOptions.IgnoreCase));
        }

        /// <summary>
        /// Prüft, ob Constraints/Limitierungen erwähnt sind.
        /// </summary>
        private static bool HasConstraints(string prompt)
        {
            var constraintPatterns = new[] { 
                @"(limit|limitierung|beschränkung|maximal|minimal|nicht mehr als|nicht weniger als)",
                @"(constraint|restriction|limitation|max|min|no more than|no less than|within)",
                @"(performance|speicher|speicherplatz|zeit|timeout|größe)"
            };
            
            return constraintPatterns.Any(pattern => 
                Regex.IsMatch(prompt, pattern, RegexOptions.IgnoreCase));
        }

        /// <summary>
        /// Prüft, ob Input/Output-Format spezifiziert ist.
        /// </summary>
        private static bool HasInputOutputFormat(string prompt)
        {
            var ioPatterns = new[] { 
                @"(eingabe|ausgang|input|output|eingang|ausgang|format|struktur)",
                @"(erwartet|erhält|nimmt an|gibt zurück|returns|takes|accepts)",
                @"(json|xml|csv|array|liste|objekt|string|number|boolean)"
            };
            
            return ioPatterns.Any(pattern => 
                Regex.IsMatch(prompt, pattern, RegexOptions.IgnoreCase));
        }

        /// <summary>
        /// Prüft, ob Erfolgskriterien definiert sind.
        /// </summary>
        private static bool HasSuccessCriteria(string prompt)
        {
            var criteriaPatterns = new[] { 
                @"(erfolgskriterium|erfolgskriterien|kriterium|erfolg|erfolgreich)",
                @"(success criteria|success condition|measure|metric|kpi)",
                @"(richtig|korrekt|gültig|valid|correct|accurate)"
            };
            
            return criteriaPatterns.Any(pattern => 
                Regex.IsMatch(prompt, pattern, RegexOptions.IgnoreCase));
        }

        /// <summary>
        /// Prüft, ob Scope/Grenzen klar sind.
        /// </summary>
        private static bool HasClearScope(string prompt)
        {
            var scopePatterns = new[] { 
                @"(umfang|bereich|scope|grenzen|grenze|ausschluss|ausschließlich)",
                @"(nur|ausschließlich|nicht|außer|mit ausnahme|except|excluding|including)",
                @"(fokus|konzentriert auf|focused on|limited to)"
            };
            
            return scopePatterns.Any(pattern => 
                Regex.IsMatch(prompt, pattern, RegexOptions.IgnoreCase));
        }

        /// <summary>
        /// Prüft, ob Kontext/Hintergrund vorhanden ist.
        /// </summary>
        private static bool HasContext(string prompt)
        {
            // Prüfe auf Länge und Detailgrad
            if (prompt.Length < 50)
                return false;

            var contextPatterns = new[] { 
                @"(hintergrund|kontext|situation|szenario|use case|anwendungsfall)",
                @"(weil|da|grund|ursache|because|reason|since|given that)"
            };
            
            return contextPatterns.Any(pattern => 
                Regex.IsMatch(prompt, pattern, RegexOptions.IgnoreCase));
        }

        #endregion
    }

    /// <summary>
    /// Datenstruktur für Analyse-Ergebnisse.
    /// </summary>
    public class AnalysisResult
    {
        public double ClarityScore { get; set; }      // 0-10
        public double SpecificityScore { get; set; }  // 0-10
        public double CompletenessScore { get; set; } // 0-10
        public List<string> Keywords { get; set; }
        public List<string> IssuesList { get; set; }
        public double OverallScore { get; set; }      // Durchschnitt der obigen Scores

        public AnalysisResult()
        {
            Keywords = new List<string>();
            IssuesList = new List<string>();
        }
    }
}
