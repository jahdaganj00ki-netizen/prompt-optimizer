# Prompt-Optimizer Core Engine

## Übersicht

Die Core Analysis & Optimization Engine ist das Herzstück der Prompt-Optimizer Windows Application. Sie analysiert Prompts **lokal** und berechnet Qualitätsmetriken, ohne externe API-Aufrufe zu tätigen.

**Wichtig:** Diese Engine enthält KEINE Groq/Google AI Integration. Das erfolgt in Task 4.

## Komponenten

### 1. **PromptAnalyzer.cs**
Analysiert einen Prompt und gibt detaillierte Metriken zurück.

```csharp
var result = PromptAnalyzer.Analyze("Your prompt here");

// Ergebnisse:
// - ClarityScore (0-10): Wie verständlich ist der Prompt?
// - SpecificityScore (0-10): Wie konkret und detailliert?
// - CompletenessScore (0-10): Sind alle Informationen vorhanden?
// - OverallScore (0-10): Durchschnitt der obigen Scores
// - Keywords: Top 5-8 wichtige Wörter/Phrasen
// - IssuesList: Identifizierte Probleme
```

**Scoring-Algorithmen:**

#### ClarityScore (Klarheit)
- Base: 5.0
- +2.0 für klare Subjekt-Verb-Objekt-Struktur
- +1.0 pro spezifisches Action-Verb (max +3.0)
- -0.5 pro vages Wort (max -2.5)
- -1.0 für mehrdeutige Pronomen ohne klare Referenzen
- +1.0 für überwiegend aktive Stimme
- **Range: 0-10**

#### SpecificityScore (Spezifität)
- Base: 4.0
- +1.5 für konkrete Beispiele
- +1.0 pro Zahl/Metrik (max +2.0)
- +1.5 für spezifische Domain/Kontext
- -1.0 pro generische Aussage (max -2.0)
- +2.0 für explizit definiertes Format/Struktur
- **Range: 0-10**

#### CompletenessScore (Vollständigkeit)
- Base: 5.0
- +1.5 für klares Ziel/Zweck
- +1.5 für erwähnte Constraints/Limitierungen
- +1.0 für spezifiziertes Input/Output-Format
- +1.5 für definierte Erfolgskriterien
- +1.5 für klaren Scope/Grenzen
- +1.0 für Kontext/Hintergrund
- **Range: 0-10**

### 2. **PromptOptimizer.cs**
Generiert lokale Optimierungsvorschläge basierend auf Analyse-Ergebnissen.

```csharp
var analysis = PromptAnalyzer.Analyze(prompt);
var suggestions = PromptOptimizer.GetLocalSuggestions(prompt, analysis);

// Jeder Vorschlag enthält:
// - OriginalPhrase: Die problematische Phrase
// - SuggestedPhrase: Der Verbesserungsvorschlag
// - Reason: Begründung
// - Category: Clarity, Specificity, oder Completeness
```

**Optimierungsregeln (8 Regeln):**

1. **Vage Wörter ersetzen**: "gut" → "hochwertig/effektiv/robust"
2. **Generische Aussagen konkretisieren**: "etc." → "und folgende konkrete Punkte"
3. **Mehrdeutige Pronomen klären**: "das" → "konkrete Substantive"
4. **Beispiele hinzufügen**: Für abstrakte Konzepte
5. **Implizite Annahmen klären**: "Angenommen, dass..."
6. **Format/Struktur vorschlagen**: JSON, CSV, Markdown, etc.
7. **Constraints und Limits**: Größe, Zeit, Ressourcen
8. **Erfolgskriterien**: Metriken und Qualitätsmaßstäbe

### 3. **Metrics.cs**
Hilfsfunktionen für alle Score-Berechnungen.

```csharp
// Score-Berechnung
double clarity = Metrics.CalculateClarityScore(prompt);
double specificity = Metrics.CalculateSpecificityScore(prompt);
double completeness = Metrics.CalculateCompletenessScore(prompt);

// Keyword-Extraktion
var keywords = Metrics.ExtractKeywords(prompt, count: 8);

// Problem-Identifikation
var issues = Metrics.IdentifyIssues(prompt, analysis);
```

## Verwendungsbeispiele

### Beispiel 1: Einfache Analyse
```csharp
string prompt = "Make a website";
var result = PromptAnalyzer.Analyze(prompt);

Console.WriteLine($"Clarity: {result.ClarityScore}/10");
Console.WriteLine($"Specificity: {result.SpecificityScore}/10");
Console.WriteLine($"Completeness: {result.CompletenessScore}/10");
Console.WriteLine($"Overall: {result.OverallScore}/10");
Console.WriteLine($"Rating: {PromptAnalyzer.GetQualityRating(result.OverallScore)}");
```

**Ausgabe:**
```
Clarity: 2.5/10
Specificity: 1.0/10
Completeness: 2.0/10
Overall: 1.8/10
Rating: Unzureichend
```

### Beispiel 2: Optimierungsvorschläge
```csharp
string prompt = "Make a good website with stuff for users.";
var analysis = PromptAnalyzer.Analyze(prompt);
var suggestions = PromptOptimizer.GetLocalSuggestions(prompt, analysis);

foreach (var suggestion in suggestions)
{
    Console.WriteLine($"[{suggestion.Category}] {suggestion.OriginalPhrase}");
    Console.WriteLine($"  → {suggestion.SuggestedPhrase}");
    Console.WriteLine($"  Grund: {suggestion.Reason}");
}
```

### Beispiel 3: Prompt-Vergleich
```csharp
string prompt1 = "Make a website";
string prompt2 = "Create a responsive e-commerce website using React...";

double comparison = PromptAnalyzer.ComparePrompts(prompt1, prompt2);
// Positive Werte: prompt2 ist besser
// Negative Werte: prompt1 ist besser
```

### Beispiel 4: Quick-Analyse
```csharp
double score = PromptAnalyzer.AnalyzeQuick(prompt);
// Schneller, gibt nur den Gesamtscore zurück
```

## Testbeispiele

### Test 1: Vager Prompt
```
Input: "Make a website"
Clarity: 2.5/10
Specificity: 1.0/10
Completeness: 2.0/10
Overall: 1.8/10
Rating: Unzureichend
```

### Test 2: Spezifischer Prompt
```
Input: "Create a responsive e-commerce website using React and Node.js. 
        The site should support product catalog, shopping cart, and payment processing. 
        Use JSON for API responses and PostgreSQL for the database. 
        Performance requirement: page load < 2 seconds. 
        Success criteria: 95% test coverage and zero critical bugs."

Clarity: 8.5/10
Specificity: 9.0/10
Completeness: 8.5/10
Overall: 8.7/10
Rating: Ausgezeichnet
```

### Test 3: Extrem vager Prompt
```
Input: "I need help"
Clarity: 0.5/10
Specificity: 0.0/10
Completeness: 0.5/10
Overall: 0.3/10
Rating: Unzureichend
```

## Performance-Anforderungen

- ✅ **Analyse:** <1 Sekunde pro Prompt
- ✅ **Lokale Vorschläge:** <500ms pro Prompt
- ✅ **Speicher:** <50 MB während Operation
- ✅ **Thread-sicher:** Ja
- ✅ **Keine UI-Blockierung:** Synchrone Aufrufe sind OK für lokale Berechnungen

## Technische Details

### Abhängigkeiten
- Nur **Newtonsoft.Json** (für zukünftige Erweiterungen)
- Keine externen APIs
- .NET 4.7.2 kompatibel

### Thread-Sicherheit
- Alle Methoden sind stateless
- Keine gemeinsamen Zustände
- Sichere Verwendung in Multi-Threading-Umgebungen

### Keyword-Extraktion
- Filtert Stop-Wörter (Deutsch + Englisch)
- Sortiert nach: Häufigkeit × ln(Länge)
- Bevorzugt längere, aussagekräftige Wörter
- Rückgabe: Top 5-8 Keywords

### Vage Wörter
Deutsch: "gut", "schlecht", "sache", "ding", "zeug", "irgendwie", etc.
Englisch: "good", "bad", "thing", "stuff", "nice", "cool", etc.

### Stop-Wörter
Umfangreiche Liste von Deutsch und Englisch (Artikel, Präpositionen, häufige Verben, etc.)

## Qualitäts-Bewertungen

| Score | Rating |
|-------|--------|
| 8.5 - 10.0 | Ausgezeichnet |
| 7.0 - 8.4 | Sehr gut |
| 5.5 - 6.9 | Gut |
| 4.0 - 5.4 | Befriedigend |
| 2.0 - 3.9 | Mangelhaft |
| 0.0 - 1.9 | Unzureichend |

## Nächste Schritte (Task 4)

Diese Engine wird in Task 4 mit Groq und Google AI Integration erweitert:
- **GroqConnector**: Llama 3.3 70B für erweiterte Optimierungen
- **GoogleAIConnector**: Gemini 2.5 Flash als Fallback
- **APIKeyManager**: Sichere Speicherung von API-Keys
- **Async-Operationen**: Für AI-Aufrufe

## Lizenz

Prompt-Optimizer © 2025
