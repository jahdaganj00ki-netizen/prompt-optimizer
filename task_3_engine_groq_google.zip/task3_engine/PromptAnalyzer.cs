using System;
using System.Collections.Generic;
using System.Linq;

namespace PromptOptimizer.Engine
{
    /// <summary>
    /// Analysiert Prompts lokal und berechnet Qualitätsmetriken.
    /// Keine API-Aufrufe - reine lokale Berechnung.
    /// </summary>
    public class PromptAnalyzer
    {
        /// <summary>
        /// Datenstruktur für Analyse-Ergebnisse.
        /// </summary>
        public class AnalysisResult
        {
            /// <summary>
            /// Klarheitsscore (0-10): Wie verständlich ist der Prompt?
            /// Basierend auf: Satzstruktur, vage Wörter, spezifische Verben, Pronomen, aktive Stimme.
            /// </summary>
            public double ClarityScore { get; set; }

            /// <summary>
            /// Spezifitätsscore (0-10): Wie konkret und detailliert ist der Prompt?
            /// Basierend auf: Beispiele, Zahlen, Domain-Kontext, generische Aussagen, Format.
            /// </summary>
            public double SpecificityScore { get; set; }

            /// <summary>
            /// Vollständigkeitsscore (0-10): Sind alle notwendigen Informationen vorhanden?
            /// Basierend auf: Ziel, Constraints, Input/Output, Erfolgskriterien, Scope, Kontext.
            /// </summary>
            public double CompletenessScore { get; set; }

            /// <summary>
            /// Extrahierte Keywords aus dem Prompt (Top 5-8).
            /// </summary>
            public List<string> Keywords { get; set; }

            /// <summary>
            /// Identifizierte Probleme und Verbesserungspotenziale.
            /// </summary>
            public List<string> IssuesList { get; set; }

            /// <summary>
            /// Gesamtscore: Durchschnitt von Clarity, Specificity und Completeness (0-10).
            /// </summary>
            public double OverallScore { get; set; }

            public AnalysisResult()
            {
                Keywords = new List<string>();
                IssuesList = new List<string>();
            }

            /// <summary>
            /// Gibt eine lesbare Zusammenfassung der Analyse zurück.
            /// </summary>
            public override string ToString()
            {
                return $"Analyse-Ergebnis:\n" +
                       $"  Klarheit: {ClarityScore:F1}/10\n" +
                       $"  Spezifität: {SpecificityScore:F1}/10\n" +
                       $"  Vollständigkeit: {CompletenessScore:F1}/10\n" +
                       $"  Gesamt: {OverallScore:F1}/10\n" +
                       $"  Keywords: {string.Join(", ", Keywords)}\n" +
                       $"  Probleme: {(IssuesList.Count > 0 ? string.Join("; ", IssuesList) : "Keine")}";
            }
        }

        /// <summary>
        /// Analysiert einen Prompt und gibt detaillierte Metriken zurück.
        /// </summary>
        /// <param name="prompt">Der zu analysierende Prompt</param>
        /// <returns>AnalysisResult mit allen Scores und Informationen</returns>
        public static AnalysisResult Analyze(string prompt)
        {
            if (string.IsNullOrWhiteSpace(prompt))
            {
                return new AnalysisResult
                {
                    ClarityScore = 0.0,
                    SpecificityScore = 0.0,
                    CompletenessScore = 0.0,
                    OverallScore = 0.0,
                    Keywords = new List<string>(),
                    IssuesList = new List<string> { "Prompt ist leer oder enthält nur Whitespace" }
                };
            }

            var result = new AnalysisResult();

            // Berechne individuelle Scores
            result.ClarityScore = Metrics.CalculateClarityScore(prompt);
            result.SpecificityScore = Metrics.CalculateSpecificityScore(prompt);
            result.CompletenessScore = Metrics.CalculateCompletenessScore(prompt);

            // Berechne Gesamtscore als Durchschnitt
            result.OverallScore = (result.ClarityScore + result.SpecificityScore + result.CompletenessScore) / 3.0;

            // Extrahiere Keywords
            result.Keywords = Metrics.ExtractKeywords(prompt, 8);

            // Identifiziere Probleme
            result.IssuesList = Metrics.IdentifyIssues(prompt, result);

            return result;
        }

        /// <summary>
        /// Analysiert einen Prompt und gibt nur den Gesamtscore zurück.
        /// Schnellere Variante, wenn nur eine einzelne Metrik benötigt wird.
        /// </summary>
        public static double AnalyzeQuick(string prompt)
        {
            if (string.IsNullOrWhiteSpace(prompt))
                return 0.0;

            double clarity = Metrics.CalculateClarityScore(prompt);
            double specificity = Metrics.CalculateSpecificityScore(prompt);
            double completeness = Metrics.CalculateCompletenessScore(prompt);

            return (clarity + specificity + completeness) / 3.0;
        }

        /// <summary>
        /// Vergleicht zwei Prompts und gibt an, welcher besser ist.
        /// </summary>
        /// <param name="prompt1">Erster Prompt</param>
        /// <param name="prompt2">Zweiter Prompt</param>
        /// <returns>
        /// Positiv: prompt2 ist besser
        /// Negativ: prompt1 ist besser
        /// 0: Beide sind gleich gut
        /// </returns>
        public static double ComparePrompts(string prompt1, string prompt2)
        {
            double score1 = AnalyzeQuick(prompt1);
            double score2 = AnalyzeQuick(prompt2);
            return score2 - score1;
        }

        /// <summary>
        /// Gibt eine Bewertung basierend auf dem Gesamtscore zurück.
        /// </summary>
        public static string GetQualityRating(double overallScore)
        {
            if (overallScore >= 8.5)
                return "Ausgezeichnet";
            else if (overallScore >= 7.0)
                return "Sehr gut";
            else if (overallScore >= 5.5)
                return "Gut";
            else if (overallScore >= 4.0)
                return "Befriedigend";
            else if (overallScore >= 2.0)
                return "Mangelhaft";
            else
                return "Unzureichend";
        }
    }
}
