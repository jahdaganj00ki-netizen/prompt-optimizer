using System;
using System.IO;
using System.Text;

namespace PromptOptimizer.Utils
{
    /// <summary>
    /// Logger class for application logging to file and console.
    /// Provides static methods for logging messages at different levels.
    /// </summary>
    public static class Logger
    {
        private static readonly object _lockObject = new object();
        private static string? _logPath;
        private static bool _isInitialized = false;

        /// <summary>
        /// Initialize the logger with the specified log file path.
        /// </summary>
        public static void Initialize(string logPath)
        {
            lock (_lockObject)
            {
                _logPath = logPath;
                
                // Create logs directory if it doesn't exist
                string? logDirectory = Path.GetDirectoryName(logPath);
                if (!string.IsNullOrEmpty(logDirectory) && !Directory.Exists(logDirectory))
                {
                    Directory.CreateDirectory(logDirectory);
                }
                
                _isInitialized = true;
                Log("Logger initialized");
            }
        }

        /// <summary>
        /// Log an informational message.
        /// </summary>
        public static void Log(string message)
        {
            WriteLog("INFO", message);
        }

        /// <summary>
        /// Log a warning message.
        /// </summary>
        public static void LogWarning(string message)
        {
            WriteLog("WARNING", message);
        }

        /// <summary>
        /// Log an error message.
        /// </summary>
        public static void LogError(string message, Exception? ex = null)
        {
            string fullMessage = ex != null 
                ? $"{message}\n{ex.GetType().Name}: {ex.Message}\n{ex.StackTrace}"
                : message;
            
            WriteLog("ERROR", fullMessage);
        }

        /// <summary>
        /// Internal method to write log entries.
        /// </summary>
        private static void WriteLog(string level, string message)
        {
            lock (_lockObject)
            {
                string timestamp = DateTime.Now.ToString("yyyy-MM-dd HH:mm:ss.fff");
                string logEntry = $"[{timestamp}] [{level}] {message}";

                // Console output for debugging
                Console.WriteLine(logEntry);

                // File logging
                if (_isInitialized && !string.IsNullOrEmpty(_logPath))
                {
                    try
                    {
                        File.AppendAllText(_logPath, logEntry + Environment.NewLine, Encoding.UTF8);
                    }
                    catch
                    {
                        // Silently fail if file logging is not possible
                        Console.WriteLine($"[WARNING] Failed to write to log file: {_logPath}");
                    }
                }
            }
        }
    }
}
