using System;
using System.IO;
using System.Text;
using Newtonsoft.Json;

namespace PromptOptimizer.Utils
{
    /// <summary>
    /// APIKeyManager handles secure storage and retrieval of API keys.
    /// Keys are stored in: C:\Users\[User]\AppData\Roaming\PromptOptimizer\api_keys.json
    /// 
    /// Note: This is a placeholder implementation. In production, consider using
    /// Windows Data Protection API (DPAPI) for encryption.
    /// </summary>
    public static class APIKeyManager
    {
        private static readonly string _appDataPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "PromptOptimizer");
        
        private static readonly string _keyFilePath = Path.Combine(_appDataPath, "api_keys.json");

        /// <summary>
        /// API keys container for JSON serialization.
        /// </summary>
        private class APIKeysContainer
        {
            [JsonProperty("groq_api_key")]
            public string? GroqApiKey { get; set; }

            [JsonProperty("google_ai_api_key")]
            public string? GoogleAIApiKey { get; set; }

            [JsonProperty("last_updated")]
            public DateTime LastUpdated { get; set; }
        }

        /// <summary>
        /// Initialize the API key storage directory.
        /// </summary>
        public static void Initialize()
        {
            try
            {
                if (!Directory.Exists(_appDataPath))
                {
                    Directory.CreateDirectory(_appDataPath);
                    Logger.Log($"Created API key storage directory: {_appDataPath}");
                }
            }
            catch (Exception ex)
            {
                Logger.LogError($"Failed to initialize API key storage: {ex.Message}", ex);
            }
        }

        /// <summary>
        /// Save API keys to secure storage.
        /// </summary>
        public static bool SaveKeys(string? groqApiKey, string? googleAIApiKey)
        {
            try
            {
                Initialize();

                var container = new APIKeysContainer
                {
                    GroqApiKey = groqApiKey,
                    GoogleAIApiKey = googleAIApiKey,
                    LastUpdated = DateTime.Now
                };

                string json = JsonConvert.SerializeObject(container, Formatting.Indented);
                File.WriteAllText(_keyFilePath, json, Encoding.UTF8);
                
                Logger.Log("API keys saved successfully");
                return true;
            }
            catch (Exception ex)
            {
                Logger.LogError($"Failed to save API keys: {ex.Message}", ex);
                return false;
            }
        }

        /// <summary>
        /// Load API keys from secure storage.
        /// </summary>
        public static (string? groqKey, string? googleAIKey) LoadKeys()
        {
            try
            {
                if (!File.Exists(_keyFilePath))
                {
                    Logger.LogWarning("API key file not found");
                    return (null, null);
                }

                string json = File.ReadAllText(_keyFilePath, Encoding.UTF8);
                var container = JsonConvert.DeserializeObject<APIKeysContainer>(json);

                if (container != null)
                {
                    Logger.Log("API keys loaded successfully");
                    return (container.GroqApiKey, container.GoogleAIApiKey);
                }

                return (null, null);
            }
            catch (Exception ex)
            {
                Logger.LogError($"Failed to load API keys: {ex.Message}", ex);
                return (null, null);
            }
        }

        /// <summary>
        /// Validate if an API key is not empty.
        /// </summary>
        public static bool ValidateKey(string? apiKey)
        {
            return !string.IsNullOrWhiteSpace(apiKey) && apiKey.Length > 10;
        }

        /// <summary>
        /// Clear all stored API keys.
        /// </summary>
        public static bool ClearKeys()
        {
            try
            {
                if (File.Exists(_keyFilePath))
                {
                    File.Delete(_keyFilePath);
                    Logger.Log("API keys cleared");
                    return true;
                }
                return true;
            }
            catch (Exception ex)
            {
                Logger.LogError($"Failed to clear API keys: {ex.Message}", ex);
                return false;
            }
        }

        /// <summary>
        /// Get the path where API keys are stored.
        /// </summary>
        public static string GetKeyFilePath()
        {
            return _keyFilePath;
        }
    }
}
