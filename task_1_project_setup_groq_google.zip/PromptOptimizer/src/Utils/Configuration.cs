using System;
using System.Configuration;
using System.IO;

namespace PromptOptimizer.Utils
{
    /// <summary>
    /// Configuration class for managing application settings from App.config.
    /// Provides static properties for accessing configuration values.
    /// </summary>
    public static class Configuration
    {
        private static bool _initialized = false;

        // Configuration properties
        public static string? LogLevel { get; private set; }
        public static string? LogPath { get; private set; }
        public static string? DatabasePath { get; private set; }
        public static string? GroqApiEndpoint { get; private set; }
        public static string? GoogleAIApiEndpoint { get; private set; }
        public static int APITimeout { get; private set; }
        public static string? AppVersion { get; private set; }
        public static string? AppName { get; private set; }

        /// <summary>
        /// Initialize configuration from App.config.
        /// </summary>
        public static void Initialize()
        {
            if (_initialized)
                return;

            try
            {
                // Load from App.config
                LogLevel = ConfigurationManager.AppSettings["LogLevel"] ?? "Info";
                LogPath = ConfigurationManager.AppSettings["LogPath"] ?? "logs/app.log";
                DatabasePath = ConfigurationManager.AppSettings["DatabasePath"] ?? "PromptOptimizer.db";
                GroqApiEndpoint = ConfigurationManager.AppSettings["GroqApiEndpoint"] ?? "https://api.groq.com/openai/v1";
                GoogleAIApiEndpoint = ConfigurationManager.AppSettings["GoogleAIApiEndpoint"] ?? "https://generativelanguage.googleapis.com/v1beta";
                APITimeout = int.TryParse(ConfigurationManager.AppSettings["APITimeout"], out int timeout) ? timeout : 30;
                AppVersion = ConfigurationManager.AppSettings["AppVersion"] ?? "1.0.0";
                AppName = ConfigurationManager.AppSettings["AppName"] ?? "Prompt Optimizer";

                // Ensure log directory exists
                string? logDirectory = Path.GetDirectoryName(LogPath);
                if (!string.IsNullOrEmpty(logDirectory) && !Directory.Exists(logDirectory))
                {
                    Directory.CreateDirectory(logDirectory);
                }

                // Initialize logger
                Logger.Initialize(LogPath);
                Logger.Log("Configuration initialized successfully");

                _initialized = true;
            }
            catch (Exception ex)
            {
                Logger.LogError("Failed to initialize configuration", ex);
                throw;
            }
        }

        /// <summary>
        /// Get a configuration value by key with a default value.
        /// </summary>
        public static string GetAppSetting(string key, string defaultValue = "")
        {
            return ConfigurationManager.AppSettings[key] ?? defaultValue;
        }

        /// <summary>
        /// Get a connection string by name.
        /// </summary>
        public static string? GetConnectionString(string name)
        {
            return ConfigurationManager.ConnectionStrings[name]?.ConnectionString;
        }
    }
}
