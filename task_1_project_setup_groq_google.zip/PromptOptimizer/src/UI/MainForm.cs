using System;
using System.Windows.Forms;

namespace PromptOptimizer.UI
{
    /// <summary>
    /// MainForm - Main user interface for the Prompt Optimizer application.
    /// 
    /// Placeholder for implementation.
    /// Will include:
    /// - Prompt input area
    /// - Analysis results display
    /// - Optimization suggestions
    /// - API Settings button
    /// </summary>
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.ClientSize = new System.Drawing.Size(800, 600);
            this.Name = "MainForm";
            this.Text = "Prompt Optimizer";
            this.StartPosition = FormStartPosition.CenterScreen;
        }
    }
}
