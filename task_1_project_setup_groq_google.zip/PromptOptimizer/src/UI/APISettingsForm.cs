using System;
using System.Windows.Forms;

namespace PromptOptimizer.UI
{
    /// <summary>
    /// APISettingsForm - Dialog for entering and testing API keys.
    /// 
    /// Placeholder for implementation.
    /// Will include:
    /// - Groq API key input field
    /// - Google AI API key input field
    /// - Test connection buttons
    /// - Save and Cancel buttons
    /// </summary>
    public class APISettingsForm : Form
    {
        public APISettingsForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.ClientSize = new System.Drawing.Size(500, 300);
            this.Name = "APISettingsForm";
            this.Text = "API Settings";
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
        }
    }
}
