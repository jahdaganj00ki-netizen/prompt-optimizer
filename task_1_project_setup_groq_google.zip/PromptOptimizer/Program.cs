using System;
using System.Windows.Forms;
using PromptOptimizer.Utils;

namespace PromptOptimizer
{
    /// <summary>
    /// Main entry point for the Prompt Optimizer Windows Forms application.
    /// </summary>
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            try
            {
                Application.EnableVisualStyles();
                Application.SetCompatibleTextRenderingDefault(false);
                
                // Initialize logger
                Logger.Log("Application starting...");
                
                // Initialize configuration
                Configuration.Initialize();
                Logger.Log($"Configuration loaded. Log Level: {Configuration.LogLevel}");
                
                // Run the main form
                Application.Run(new UI.MainForm());
            }
            catch (Exception ex)
            {
                Logger.LogError($"Fatal error in Main: {ex.Message}", ex);
                MessageBox.Show(
                    $"An error occurred while starting the application:\n\n{ex.Message}",
                    "Application Error",
                    MessageBoxButtons.OK,
                    MessageBoxIcon.Error);
            }
        }
    }
}
