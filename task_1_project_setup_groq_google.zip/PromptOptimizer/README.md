# Prompt Optimizer - Windows Forms Application

## Übersicht

Prompt Optimizer ist eine Windows Forms-Anwendung (.NET 4.7.2) zur Analyse und Optimierung von KI-Prompts. Die Anwendung nutzt die Groq API als primären Provider und die Google AI API als Fallback-Lösung.

## Architektur

### Projektstruktur

```
PromptOptimizer/
├── src/
│   ├── UI/                    # Benutzeroberfläche (WinForms)
│   │   ├── MainForm.cs
│   │   ├── MainForm.Designer.cs
│   │   └── APISettingsForm.cs
│   ├── Engine/                # Analyse- und Optimierungslogik
│   │   ├── PromptAnalyzer.cs
│   │   ├── PromptOptimizer.cs
│   │   └── Metrics.cs
│   ├── AI/                    # AI-Provider Integration
│   │   ├── GroqConnector.cs
│   │   ├── GoogleAIConnector.cs
│   │   └── AIProvider.cs
│   ├── Database/              # Datenbankoperationen
│   │   └── DatabaseManager.cs
│   └── Utils/                 # Hilfsfunktionen
│       ├── Logger.cs
│       ├── APIKeyManager.cs
│       └── Configuration.cs
├── tests/
│   └── UnitTests.cs
├── assets/
├── logs/
├── PromptOptimizer.csproj
├── App.config
├── packages.config
└── Program.cs
```

## Technologie-Stack

- **Framework**: .NET Framework 4.7.2
- **UI**: Windows Forms
- **Datenbank**: SQLite mit Entity Framework 6.4.4
- **AI-Provider**: 
  - Primär: Groq (llama-3.3-70b-versatile)
  - Fallback: Google AI (gemini-2.5-flash)
- **JSON**: Newtonsoft.Json 13.0.3
- **Logging**: log4net 2.0.14

## Anforderungen

- Windows 7 oder höher
- .NET Framework 4.7.2
- Visual Studio 2022 (für Entwicklung)

## Installation

1. Projekt in Visual Studio 2022 öffnen
2. NuGet-Pakete wiederherstellen (`Restore NuGet Packages`)
3. Projekt kompilieren (Build)

## Konfiguration

### App.config

Die Anwendung wird über `App.config` konfiguriert:

```xml
<appSettings>
  <add key="LogLevel" value="Info" />
  <add key="LogPath" value="logs/app.log" />
  <add key="DatabasePath" value="PromptOptimizer.db" />
  <add key="GroqApiEndpoint" value="https://api.groq.com/openai/v1" />
  <add key="GoogleAIApiEndpoint" value="https://generativelanguage.googleapis.com/v1beta" />
  <add key="APITimeout" value="30" />
</appSettings>
```

### API-Schlüssel

API-Schlüssel werden sicher in `C:\Users\[User]\AppData\Roaming\PromptOptimizer\api_keys.json` gespeichert.

**Wichtig**: Schlüssel werden NICHT in Konfigurationsdateien gespeichert.

## Komponenten

### UI (Benutzeroberfläche)

- **MainForm**: Hauptfenster der Anwendung
- **APISettingsForm**: Dialog zur Eingabe und Validierung von API-Schlüsseln

### Engine (Analyse und Optimierung)

- **PromptAnalyzer**: Analysiert Prompts auf Klarheit, Spezifität und Vollständigkeit
- **PromptOptimizer**: Generiert Optimierungsvorschläge
- **Metrics**: Berechnungsalgorithmen für Bewertungen

### AI (KI-Integration)

- **GroqConnector**: Verbindung zur Groq API (primär)
- **GoogleAIConnector**: Verbindung zur Google AI API (Fallback)
- **AIProvider**: Verwaltet Provider-Auswahl und Fallback-Logik

### Database (Datenverwaltung)

- **DatabaseManager**: SQLite-Operationen und Entity Framework Integration

### Utils (Hilfsfunktionen)

- **Logger**: Datei- und Konsolenprotokollierung
- **APIKeyManager**: Sichere Speicherung von API-Schlüsseln
- **Configuration**: Konfigurationsverwaltung aus App.config

## Verwendung

1. Anwendung starten
2. API-Schlüssel in den Einstellungen eingeben (Groq und/oder Google AI)
3. Prompt eingeben
4. Analyse und Optimierungsvorschläge anzeigen

## Entwicklung

### Nächste Schritte (Task 2-4)

- Task 2: Implementierung der UI-Komponenten
- Task 3: Implementierung der AI-Provider und API-Integration
- Task 4: Datenbankintegration und sichere Schlüsselverwaltung

### Logging

Die Anwendung protokolliert alle Aktivitäten in `logs/app.log`. API-Schlüssel werden niemals protokolliert.

## Lizenz

Proprietary - Prompt Optimizer

## Kontakt

Für Fragen oder Probleme wenden Sie sich bitte an das Entwicklungsteam.
