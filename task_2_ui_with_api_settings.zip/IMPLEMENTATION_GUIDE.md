# Implementierungsleitfaden - Prompt Optimizer UI

Dieser Leitfaden beschreibt die Implementierung der WinForms UI und des API-Konfigurationsdialogs.

## Übersicht der Komponenten

### 1. MainForm.cs

**Zweck:** Hauptbenutzeroberfläche für Prompt-Analyse und -Optimierung

**Wichtige Eigenschaften:**
- `InputPrompt` - Getter/Setter für Eingabe-TextBox
- `OutputPrompt` - Getter/Setter für Ausgabe-TextBox
- `WordCount` - Read-only Property für Wortanzahl

**Wichtige Methoden:**
- `SetAnalysisResults(AnalysisResult result)` - Zeigt Analyse-Ergebnisse
- `SetOptimizationResults(string optimization)` - Zeigt Optimierungs-Ergebnisse
- `ClearUI()` - Löscht alle Felder
- `ShowError(string message)` - Zeigt Fehlermeldung
- `ShowSuccess(string message)` - Zeigt Erfolgsmeldung

**Event-Handler Implementierung:**

```csharp
// Analyse durchführen
private void btnAnalyze_Click(object sender, EventArgs e)
{
    // 1. Eingabe validieren
    // 2. Status aktualisieren
    // 3. AnalysisEngine aufrufen
    // 4. Ergebnisse anzeigen
}

// Optimierung durchführen
private void btnOptimize_Click(object sender, EventArgs e)
{
    // 1. Eingabe validieren
    // 2. Bevorzugten Provider prüfen
    // 3. GroqConnector oder GoogleAIConnector aufrufen
    // 4. Ergebnisse anzeigen
}

// Tastaturkürzel verarbeiten
private void MainForm_KeyDown(object sender, KeyEventArgs e)
{
    if (e.Control)
    {
        switch (e.KeyCode)
        {
            case Keys.L: btnAnalyze_Click(null, null); break;
            case Keys.O: btnOptimize_Click(null, null); break;
            case Keys.C: btnCopyOutput_Click(null, null); break;
            case Keys.K: btnAPISettings_Click(null, null); break;
        }
    }
}
```

### 2. MainForm.Designer.cs

**Zweck:** Auto-generierter Code für Steuerelemente

**Wichtige Steuerelemente:**
- `TableLayoutPanel` - Hauptlayout-Container
- `TextBox txtInputPrompt` - Eingabe-Prompt
- `TextBox txtOutputPrompt` - Ausgabe-Prompt
- `TabControl tabControlResults` - Tabs für Metrics/Suggestions
- `StatusStrip statusStrip` - Status-Bar unten
- `Button btnAnalyze`, `btnOptimize`, `btnClear`, `btnAPISettings` - Toolbar-Buttons

**Layout-Struktur:**
```
Row 0: Header Label (50px)
Row 1: Toolbar Panel (45px)
Row 2: Input Label (25px)
Row 3: Input TextBox (100px)
Row 4: Word Count Label (20px)
Row 5: Tab Control (40% of remaining)
Row 6: Output Label (25px)
Row 7: Output TextBox (100px)
Row 8: Copy Button (35px)
```

### 3. APISettingsForm.cs

**Zweck:** Modaler Dialog für API-Konfiguration

**Wichtige Eigenschaften:**
- `GroqApiKey` - Getter/Setter für Groq API-Schlüssel
- `GoogleApiKey` - Getter/Setter für Google API-Schlüssel
- `PreferredProvider` - Getter/Setter für bevorzugten Provider

**Wichtige Methoden:**
- `ValidateGroqKeyAsync()` - Validiert Groq API-Schlüssel
- `ValidateGoogleKeyAsync()` - Validiert Google API-Schlüssel
- `OpenUrl(string url)` - Öffnet URL im Browser

**Validierungslogik:**

```csharp
public async Task ValidateGroqKeyAsync()
{
    try
    {
        // Hier würde echter API-Aufruf erfolgen:
        // bool isValid = await GroqConnector.ValidateKeyAsync(GroqApiKey);
        
        // Demo-Validierung
        bool isValid = GroqApiKey.StartsWith("gsk_");
        
        _groqKeyValid = isValid;
        lblGroqStatus.Text = isValid ? "✓ Valid" : "✗ Invalid";
        lblGroqStatus.ForeColor = isValid ? Color.Green : Color.Red;
    }
    catch (Exception ex)
    {
        MessageBox.Show($"Error: {ex.Message}");
    }
}
```

### 4. APISettingsForm.Designer.cs

**Zweck:** Auto-generierter Code für Dialog-Steuerelemente

**Wichtige Steuerelemente:**
- Groq Section: TextBox, Test-Button, Status-Label
- Google Section: TextBox, Test-Button, Status-Label
- Provider Section: ComboBox für Provider-Auswahl
- Dialog Buttons: Save, Cancel, Documentation

## Integrationsschritte

### Schritt 1: AnalysisEngine Integration

```csharp
// In MainForm.cs - btnAnalyze_Click()
private void btnAnalyze_Click(object sender, EventArgs e)
{
    UpdateStatus("Analyzing prompt...");
    
    // Rufe AnalysisEngine auf
    var analyzer = new PromptAnalyzer();
    var result = analyzer.Analyze(InputPrompt);
    
    // Zeige Ergebnisse
    SetAnalysisResults(result);
    
    UpdateStatus("Analysis complete");
}
```

### Schritt 2: AI Optimization Integration

```csharp
// In MainForm.cs - btnOptimize_Click()
private void btnOptimize_Click(object sender, EventArgs e)
{
    UpdateStatus($"Optimizing with {_preferredProvider}...");
    
    // Wähle Connector basierend auf Provider
    if (_preferredProvider == "Groq")
    {
        var groqConnector = new GroqConnector();
        var optimized = groqConnector.OptimizePrompt(InputPrompt);
        SetOptimizationResults(optimized);
    }
    else
    {
        var googleConnector = new GoogleAIConnector();
        var optimized = googleConnector.OptimizePrompt(InputPrompt);
        SetOptimizationResults(optimized);
    }
    
    UpdateStatus("Optimization complete");
}
```

### Schritt 3: API Key Management Integration

```csharp
// In APISettingsForm.cs - btnSave_Click()
private void btnSave_Click(object sender, EventArgs e)
{
    // Speichere API-Schlüssel
    var keyManager = new APIKeyManager();
    keyManager.SaveKeys(GroqApiKey, GoogleApiKey, PreferredProvider);
    
    this.DialogResult = DialogResult.OK;
    this.Close();
}

// In APISettingsForm.cs - APISettingsForm_Load()
private void APISettingsForm_Load(object sender, EventArgs e)
{
    // Lade gespeicherte Schlüssel
    var keyManager = new APIKeyManager();
    var keys = keyManager.LoadKeys();
    
    if (keys != null)
    {
        GroqApiKey = keys.GroqKey;
        GoogleApiKey = keys.GoogleKey;
        PreferredProvider = keys.PreferredProvider;
    }
}
```

## Best Practices

### 1. Fehlerbehandlung

```csharp
try
{
    // Führe Operation durch
}
catch (Exception ex)
{
    ShowError($"Operation failed: {ex.Message}");
    UpdateStatus("Error occurred");
}
```

### 2. Status-Updates

```csharp
// Immer Status aktualisieren
UpdateStatus("Processing...");
// ... Operation ...
UpdateStatus("Complete");
```

### 3. Validierung

```csharp
// Immer Eingabe validieren
if (string.IsNullOrWhiteSpace(InputPrompt))
{
    ShowError("Please enter a prompt");
    return;
}
```

### 4. Async Operations

```csharp
// Für lange laufende Operationen
private async void btnOptimize_Click(object sender, EventArgs e)
{
    UpdateStatus("Processing...");
    var result = await OptimizeAsync(InputPrompt);
    SetOptimizationResults(result);
    UpdateStatus("Complete");
}

private async Task<string> OptimizeAsync(string prompt)
{
    return await Task.Run(() => 
    {
        // Länger laufende Operation
        return "Optimized prompt";
    });
}
```

## Testing

### Unit Tests für UI-Logik

```csharp
[TestClass]
public class MainFormTests
{
    [TestMethod]
    public void TestWordCount()
    {
        var form = new MainForm();
        form.InputPrompt = "This is a test prompt";
        Assert.AreEqual(5, form.WordCount);
    }
    
    [TestMethod]
    public void TestClearUI()
    {
        var form = new MainForm();
        form.InputPrompt = "Test";
        form.ClearUI();
        Assert.AreEqual("", form.InputPrompt);
    }
}
```

## Häufige Probleme und Lösungen

### Problem 1: API-Schlüssel werden nicht gespeichert

**Lösung:** Stelle sicher, dass APIKeyManager korrekt implementiert ist:
```csharp
public class APIKeyManager
{
    public void SaveKeys(string groqKey, string googleKey, string provider)
    {
        // Speichere in AppData
        var appDataPath = Path.Combine(
            Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData),
            "PromptOptimizer"
        );
        // ... Speicherlogik ...
    }
}
```

### Problem 2: Dialog wird nicht modal angezeigt

**Lösung:** Verwende `ShowDialog()` statt `Show()`:
```csharp
APISettingsForm dialog = new APISettingsForm();
if (dialog.ShowDialog(this) == DialogResult.OK)
{
    // Verarbeite Ergebnis
}
```

### Problem 3: Tastaturkürzel funktionieren nicht

**Lösung:** Stelle sicher, dass `KeyPreview = true` ist:
```csharp
private void MainForm_Load(object sender, EventArgs e)
{
    this.KeyPreview = true;  // Wichtig!
    this.KeyDown += MainForm_KeyDown;
}
```

## Performance-Tipps

1. **Verwende Async/Await** für lange laufende Operationen
2. **Nutze Caching** für häufig verwendete Daten
3. **Minimiere UI-Updates** während Verarbeitung
4. **Verwende Lazy Loading** für große Datenmengen

## Sicherheitsaspekte

1. **Maskiere API-Schlüssel** in TextBoxen mit `PasswordChar`
2. **Speichere Schlüssel verschlüsselt** in AppData
3. **Validiere Eingaben** vor der Verarbeitung
4. **Verwende HTTPS** für API-Aufrufe
5. **Implementiere Timeout** für API-Aufrufe

## Nächste Schritte

1. Implementiere echte API-Connectoren
2. Füge Datenbankintegration hinzu
3. Implementiere Logging
4. Erstelle Unit Tests
5. Füge Benutzereinstellungen hinzu
6. Implementiere Mehrsprachigkeit
