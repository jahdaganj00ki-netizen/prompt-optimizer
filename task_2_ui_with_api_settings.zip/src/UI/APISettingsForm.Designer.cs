namespace PromptOptimizer.UI
{
    partial class APISettingsForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            // Groq Controls
            this.lblGroqTitle = new System.Windows.Forms.Label();
            this.lblGroqKey = new System.Windows.Forms.Label();
            this.txtGroqKey = new System.Windows.Forms.TextBox();
            this.btnGetGroqKey = new System.Windows.Forms.LinkLabel();
            this.btnTestGroq = new System.Windows.Forms.Button();
            this.lblGroqStatus = new System.Windows.Forms.Label();
            this.lblGroqModel = new System.Windows.Forms.Label();
            this.lblGroqLimit = new System.Windows.Forms.Label();

            // Google Controls
            this.lblGoogleTitle = new System.Windows.Forms.Label();
            this.lblGoogleKey = new System.Windows.Forms.Label();
            this.txtGoogleKey = new System.Windows.Forms.TextBox();
            this.btnGetGoogleKey = new System.Windows.Forms.LinkLabel();
            this.btnTestGoogle = new System.Windows.Forms.Button();
            this.lblGoogleStatus = new System.Windows.Forms.Label();
            this.lblGoogleModel = new System.Windows.Forms.Label();
            this.lblGoogleLimit = new System.Windows.Forms.Label();

            // Provider Controls
            this.lblProvider = new System.Windows.Forms.Label();
            this.cbProvider = new System.Windows.Forms.ComboBox();
            this.lblNote = new System.Windows.Forms.Label();

            // Dialog Buttons
            this.btnSave = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnDocumentation = new System.Windows.Forms.Button();

            this.SuspendLayout();

            // ========== GROQ SECTION ==========

            // Groq Title
            this.lblGroqTitle.AutoSize = true;
            this.lblGroqTitle.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblGroqTitle.ForeColor = System.Drawing.Color.FromArgb(44, 62, 80);
            this.lblGroqTitle.Location = new System.Drawing.Point(15, 15);
            this.lblGroqTitle.Text = "Groq API Configuration:";

            // Groq API Key Label
            this.lblGroqKey.AutoSize = true;
            this.lblGroqKey.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblGroqKey.Location = new System.Drawing.Point(15, 40);
            this.lblGroqKey.Text = "API Key:";

            // Groq API Key TextBox
            this.txtGroqKey.BackColor = System.Drawing.Color.White;
            this.txtGroqKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGroqKey.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtGroqKey.Location = new System.Drawing.Point(15, 60);
            this.txtGroqKey.Name = "txtGroqKey";
            this.txtGroqKey.PasswordChar = '*';
            this.txtGroqKey.Size = new System.Drawing.Size(350, 25);
            this.txtGroqKey.TabIndex = 0;

            // Get Groq Key Link
            this.btnGetGroqKey.AutoSize = true;
            this.btnGetGroqKey.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnGetGroqKey.LinkColor = System.Drawing.Color.FromArgb(33, 150, 243);
            this.btnGetGroqKey.Location = new System.Drawing.Point(370, 63);
            this.btnGetGroqKey.Text = "🔗 Get";
            this.btnGetGroqKey.TabIndex = 1;
            this.btnGetGroqKey.Click += new System.EventHandler(this.btnGetGroqKey_Click);

            // Test Groq Button
            this.btnTestGroq.BackColor = System.Drawing.Color.FromArgb(33, 150, 243);
            this.btnTestGroq.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTestGroq.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnTestGroq.ForeColor = System.Drawing.Color.White;
            this.btnTestGroq.Location = new System.Drawing.Point(15, 90);
            this.btnTestGroq.Name = "btnTestGroq";
            this.btnTestGroq.Size = new System.Drawing.Size(120, 30);
            this.btnTestGroq.TabIndex = 2;
            this.btnTestGroq.Text = "Test Groq Key";
            this.btnTestGroq.UseVisualStyleBackColor = false;
            this.btnTestGroq.Click += new System.EventHandler(this.btnTestGroq_Click);

            // Groq Status Label
            this.lblGroqStatus.AutoSize = true;
            this.lblGroqStatus.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblGroqStatus.ForeColor = System.Drawing.Color.FromArgb(100, 100, 100);
            this.lblGroqStatus.Location = new System.Drawing.Point(145, 95);
            this.lblGroqStatus.Text = "Status: Not tested";

            // Groq Model Info
            this.lblGroqModel.AutoSize = true;
            this.lblGroqModel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblGroqModel.ForeColor = System.Drawing.Color.FromArgb(100, 100, 100);
            this.lblGroqModel.Location = new System.Drawing.Point(15, 125);
            this.lblGroqModel.Text = "Model: llama-3.3-70b-versatile";

            // Groq Limit Info
            this.lblGroqLimit.AutoSize = true;
            this.lblGroqLimit.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblGroqLimit.ForeColor = System.Drawing.Color.FromArgb(100, 100, 100);
            this.lblGroqLimit.Location = new System.Drawing.Point(15, 140);
            this.lblGroqLimit.Text = "Limit: 14,400 tokens/day";

            // ========== GOOGLE SECTION ==========

            // Google Title
            this.lblGoogleTitle.AutoSize = true;
            this.lblGoogleTitle.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblGoogleTitle.ForeColor = System.Drawing.Color.FromArgb(44, 62, 80);
            this.lblGoogleTitle.Location = new System.Drawing.Point(15, 165);
            this.lblGoogleTitle.Text = "Google AI Configuration:";

            // Google API Key Label
            this.lblGoogleKey.AutoSize = true;
            this.lblGoogleKey.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblGoogleKey.Location = new System.Drawing.Point(15, 190);
            this.lblGoogleKey.Text = "API Key:";

            // Google API Key TextBox
            this.txtGoogleKey.BackColor = System.Drawing.Color.White;
            this.txtGoogleKey.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtGoogleKey.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtGoogleKey.Location = new System.Drawing.Point(15, 210);
            this.txtGoogleKey.Name = "txtGoogleKey";
            this.txtGoogleKey.PasswordChar = '*';
            this.txtGoogleKey.Size = new System.Drawing.Size(350, 25);
            this.txtGoogleKey.TabIndex = 3;

            // Get Google Key Link
            this.btnGetGoogleKey.AutoSize = true;
            this.btnGetGoogleKey.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnGetGoogleKey.LinkColor = System.Drawing.Color.FromArgb(33, 150, 243);
            this.btnGetGoogleKey.Location = new System.Drawing.Point(370, 213);
            this.btnGetGoogleKey.Text = "🔗 Get";
            this.btnGetGoogleKey.TabIndex = 4;
            this.btnGetGoogleKey.Click += new System.EventHandler(this.btnGetGoogleKey_Click);

            // Test Google Button
            this.btnTestGoogle.BackColor = System.Drawing.Color.FromArgb(33, 150, 243);
            this.btnTestGoogle.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnTestGoogle.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnTestGoogle.ForeColor = System.Drawing.Color.White;
            this.btnTestGoogle.Location = new System.Drawing.Point(15, 240);
            this.btnTestGoogle.Name = "btnTestGoogle";
            this.btnTestGoogle.Size = new System.Drawing.Size(120, 30);
            this.btnTestGoogle.TabIndex = 5;
            this.btnTestGoogle.Text = "Test Google Key";
            this.btnTestGoogle.UseVisualStyleBackColor = false;
            this.btnTestGoogle.Click += new System.EventHandler(this.btnTestGoogle_Click);

            // Google Status Label
            this.lblGoogleStatus.AutoSize = true;
            this.lblGoogleStatus.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblGoogleStatus.ForeColor = System.Drawing.Color.FromArgb(100, 100, 100);
            this.lblGoogleStatus.Location = new System.Drawing.Point(145, 245);
            this.lblGoogleStatus.Text = "Status: Not tested";

            // Google Model Info
            this.lblGoogleModel.AutoSize = true;
            this.lblGoogleModel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblGoogleModel.ForeColor = System.Drawing.Color.FromArgb(100, 100, 100);
            this.lblGoogleModel.Location = new System.Drawing.Point(15, 275);
            this.lblGoogleModel.Text = "Model: gemini-2.5-flash";

            // Google Limit Info
            this.lblGoogleLimit.AutoSize = true;
            this.lblGoogleLimit.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblGoogleLimit.ForeColor = System.Drawing.Color.FromArgb(100, 100, 100);
            this.lblGoogleLimit.Location = new System.Drawing.Point(15, 290);
            this.lblGoogleLimit.Text = "Limit: 32,000 tokens/day";

            // ========== PROVIDER SECTION ==========

            // Provider Label
            this.lblProvider.AutoSize = true;
            this.lblProvider.Font = new System.Drawing.Font("Segoe UI", 10F, System.Drawing.FontStyle.Bold);
            this.lblProvider.Location = new System.Drawing.Point(15, 315);
            this.lblProvider.Text = "Preferred Provider:";

            // Provider ComboBox
            this.cbProvider.BackColor = System.Drawing.Color.White;
            this.cbProvider.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.cbProvider.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.cbProvider.FormattingEnabled = true;
            this.cbProvider.Location = new System.Drawing.Point(15, 335);
            this.cbProvider.Name = "cbProvider";
            this.cbProvider.Size = new System.Drawing.Size(150, 25);
            this.cbProvider.TabIndex = 6;

            // Note Label
            this.lblNote.AutoSize = true;
            this.lblNote.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblNote.ForeColor = System.Drawing.Color.FromArgb(100, 100, 100);
            this.lblNote.Location = new System.Drawing.Point(15, 360);
            this.lblNote.Text = "(Google used as fallback)";

            // ========== BUTTONS ==========

            // Save Button
            this.btnSave.BackColor = System.Drawing.Color.FromArgb(76, 175, 80);
            this.btnSave.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnSave.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnSave.ForeColor = System.Drawing.Color.White;
            this.btnSave.Location = new System.Drawing.Point(280, 360);
            this.btnSave.Name = "btnSave";
            this.btnSave.Size = new System.Drawing.Size(100, 30);
            this.btnSave.TabIndex = 7;
            this.btnSave.Text = "Save";
            this.btnSave.UseVisualStyleBackColor = false;
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            // Cancel Button
            this.btnCancel.BackColor = System.Drawing.Color.FromArgb(238, 238, 238);
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnCancel.ForeColor = System.Drawing.Color.FromArgb(51, 51, 51);
            this.btnCancel.Location = new System.Drawing.Point(390, 360);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 30);
            this.btnCancel.TabIndex = 8;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);

            // Documentation Button
            this.btnDocumentation.BackColor = System.Drawing.Color.FromArgb(33, 150, 243);
            this.btnDocumentation.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDocumentation.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnDocumentation.ForeColor = System.Drawing.Color.White;
            this.btnDocumentation.Location = new System.Drawing.Point(500, 360);
            this.btnDocumentation.Name = "btnDocumentation";
            this.btnDocumentation.Size = new System.Drawing.Size(85, 30);
            this.btnDocumentation.TabIndex = 9;
            this.btnDocumentation.Text = "Documentation";
            this.btnDocumentation.UseVisualStyleBackColor = false;
            this.btnDocumentation.Click += new System.EventHandler(this.btnDocumentation_Click);

            // APISettingsForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(245, 245, 245);
            this.ClientSize = new System.Drawing.Size(600, 400);
            this.Controls.Add(this.lblGroqTitle);
            this.Controls.Add(this.lblGroqKey);
            this.Controls.Add(this.txtGroqKey);
            this.Controls.Add(this.btnGetGroqKey);
            this.Controls.Add(this.btnTestGroq);
            this.Controls.Add(this.lblGroqStatus);
            this.Controls.Add(this.lblGroqModel);
            this.Controls.Add(this.lblGroqLimit);
            this.Controls.Add(this.lblGoogleTitle);
            this.Controls.Add(this.lblGoogleKey);
            this.Controls.Add(this.txtGoogleKey);
            this.Controls.Add(this.btnGetGoogleKey);
            this.Controls.Add(this.btnTestGoogle);
            this.Controls.Add(this.lblGoogleStatus);
            this.Controls.Add(this.lblGoogleModel);
            this.Controls.Add(this.lblGoogleLimit);
            this.Controls.Add(this.lblProvider);
            this.Controls.Add(this.cbProvider);
            this.Controls.Add(this.lblNote);
            this.Controls.Add(this.btnSave);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnDocumentation);
            this.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Name = "APISettingsForm";
            this.Text = "API Configuration";
            this.Load += new System.EventHandler(this.APISettingsForm_Load);
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        // Control declarations
        private System.Windows.Forms.Label lblGroqTitle;
        private System.Windows.Forms.Label lblGroqKey;
        private System.Windows.Forms.TextBox txtGroqKey;
        private System.Windows.Forms.LinkLabel btnGetGroqKey;
        private System.Windows.Forms.Button btnTestGroq;
        private System.Windows.Forms.Label lblGroqStatus;
        private System.Windows.Forms.Label lblGroqModel;
        private System.Windows.Forms.Label lblGroqLimit;

        private System.Windows.Forms.Label lblGoogleTitle;
        private System.Windows.Forms.Label lblGoogleKey;
        private System.Windows.Forms.TextBox txtGoogleKey;
        private System.Windows.Forms.LinkLabel btnGetGoogleKey;
        private System.Windows.Forms.Button btnTestGoogle;
        private System.Windows.Forms.Label lblGoogleStatus;
        private System.Windows.Forms.Label lblGoogleModel;
        private System.Windows.Forms.Label lblGoogleLimit;

        private System.Windows.Forms.Label lblProvider;
        private System.Windows.Forms.ComboBox cbProvider;
        private System.Windows.Forms.Label lblNote;

        private System.Windows.Forms.Button btnSave;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnDocumentation;
    }
}
