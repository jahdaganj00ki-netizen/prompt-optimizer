using System;
using System.Windows.Forms;
using System.Drawing;

namespace PromptOptimizer.UI
{
    /// <summary>
    /// MainForm - Hauptformular für Prompt Optimizer
    /// Enthält UI-Logik für Prompt-Analyse und -Optimierung
    /// </summary>
    public partial class MainForm : Form
    {
        private string _preferredProvider = "Groq";

        public MainForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Wird beim Laden des Formulars aufgerufen
        /// Initialisiert die UI und prüft API-Schlüssel
        /// </summary>
        private void MainForm_Load(object sender, EventArgs e)
        {
            // Fenster-Einstellungen
            this.Text = "Prompt Optimizer - AI-powered Prompt Enhancement";
            this.Size = new Size(900, 600);
            this.MinimumSize = new Size(800, 500);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.ResizeMode = FormWindowState.Normal;

            // Status-Bar initialisieren
            UpdateStatus("Ready");
            UpdateProviderStatus();

            // Tastaturkürzel registrieren
            this.KeyPreview = true;
            this.KeyDown += MainForm_KeyDown;
        }

        /// <summary>
        /// Öffnet den API-Einstellungsdialog
        /// </summary>
        private void btnAPISettings_Click(object sender, EventArgs e)
        {
            APISettingsForm apiDialog = new APISettingsForm();
            if (apiDialog.ShowDialog(this) == DialogResult.OK)
            {
                _preferredProvider = apiDialog.PreferredProvider;
                UpdateProviderStatus();
                UpdateStatus("API settings updated successfully");
            }
        }

        /// <summary>
        /// Analysiert den eingegebenen Prompt
        /// </summary>
        private void btnAnalyze_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(InputPrompt))
            {
                ShowError("Please enter a prompt to analyze");
                return;
            }

            UpdateStatus("Analyzing prompt...");
            
            // Hier würde die Verbindung zur Analysis Engine erfolgen
            // Beispiel-Ergebnisse für Demo:
            SetAnalysisResults(new AnalysisResult
            {
                Clarity = 7.2,
                Specificity = 5.8,
                Completeness = 8.1,
                Keywords = new[] { "analysis", "optimization", "AI", "prompt" }
            });

            UpdateStatus("Analysis complete");
        }

        /// <summary>
        /// Optimiert den Prompt mit AI (Groq oder Google)
        /// </summary>
        private void btnOptimize_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(InputPrompt))
            {
                ShowError("Please enter a prompt to optimize");
                return;
            }

            UpdateStatus($"Optimizing with {_preferredProvider}...");
            
            // Hier würde die Verbindung zur AI Engine erfolgen
            // Beispiel-Optimierung für Demo:
            string optimizedPrompt = $"[Optimized by {_preferredProvider}]\n\n" +
                                    "Please provide a detailed, structured response that includes:\n" +
                                    "1. Clear objectives\n" +
                                    "2. Specific requirements\n" +
                                    "3. Expected output format\n\n" +
                                    "Original: " + InputPrompt;

            SetOptimizationResults(optimizedPrompt);
            UpdateStatus("Optimization complete");
        }

        /// <summary>
        /// Löscht alle Felder
        /// </summary>
        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearUI();
            UpdateStatus("All fields cleared");
        }

        /// <summary>
        /// Kopiert den optimierten Prompt in die Zwischenablage
        /// </summary>
        private void btnCopyOutput_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(OutputPrompt))
            {
                ShowError("No optimized prompt to copy");
                return;
            }

            try
            {
                Clipboard.SetText(OutputPrompt);
                ShowSuccess("Optimized prompt copied to clipboard");
            }
            catch (Exception ex)
            {
                ShowError($"Error copying to clipboard: {ex.Message}");
            }
        }

        /// <summary>
        /// Aktualisiert die Wortanzahl beim Tippen
        /// </summary>
        private void txtInputPrompt_TextChanged(object sender, EventArgs e)
        {
            UpdateWordCount();
        }

        /// <summary>
        /// Behandelt Tastaturkürzel
        /// </summary>
        private void MainForm_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.Control)
            {
                switch (e.KeyCode)
                {
                    case Keys.L: // Ctrl+L = Analyze
                        btnAnalyze_Click(null, null);
                        e.Handled = true;
                        break;
                    case Keys.O: // Ctrl+O = Optimize
                        btnOptimize_Click(null, null);
                        e.Handled = true;
                        break;
                    case Keys.C: // Ctrl+C = Copy (wenn nicht in TextBox)
                        if (!(ActiveControl is TextBox))
                        {
                            btnCopyOutput_Click(null, null);
                            e.Handled = true;
                        }
                        break;
                    case Keys.K: // Ctrl+K = API Settings
                        btnAPISettings_Click(null, null);
                        e.Handled = true;
                        break;
                }
            }
        }

        /// <summary>
        /// Aktualisiert die Wortanzahl-Anzeige
        /// </summary>
        private void UpdateWordCount()
        {
            int wordCount = string.IsNullOrWhiteSpace(InputPrompt) ? 0 : 
                           InputPrompt.Split(new[] { ' ', '\t', '\n', '\r' }, 
                           StringSplitOptions.RemoveEmptyEntries).Length;
            
            if (lblWordCount != null)
            {
                lblWordCount.Text = $"Word Count: {wordCount}";
            }
        }

        /// <summary>
        /// Aktualisiert die Status-Bar mit Provider-Information
        /// </summary>
        private void UpdateProviderStatus()
        {
            if (lblProvider != null)
            {
                lblProvider.Text = $"AI Provider: {_preferredProvider}";
            }
        }

        // ============ PUBLIC PROPERTIES & METHODS ============

        /// <summary>
        /// Eingabe-Prompt Property
        /// </summary>
        public string InputPrompt
        {
            get { return txtInputPrompt?.Text ?? string.Empty; }
            set { if (txtInputPrompt != null) txtInputPrompt.Text = value; }
        }

        /// <summary>
        /// Ausgabe-Prompt Property
        /// </summary>
        public string OutputPrompt
        {
            get { return txtOutputPrompt?.Text ?? string.Empty; }
            set { if (txtOutputPrompt != null) txtOutputPrompt.Text = value; }
        }

        /// <summary>
        /// Wortanzahl Property (Read-only)
        /// </summary>
        public int WordCount
        {
            get
            {
                return string.IsNullOrWhiteSpace(InputPrompt) ? 0 :
                       InputPrompt.Split(new[] { ' ', '\t', '\n', '\r' }, 
                       StringSplitOptions.RemoveEmptyEntries).Length;
            }
        }

        /// <summary>
        /// Setzt die Analyse-Ergebnisse in der UI
        /// </summary>
        public void SetAnalysisResults(AnalysisResult result)
        {
            if (result == null) return;

            // Metrics Tab aktualisieren
            if (txtClarity != null) txtClarity.Text = $"{result.Clarity:F1}/10";
            if (txtSpecificity != null) txtSpecificity.Text = $"{result.Specificity:F1}/10";
            if (txtCompleteness != null) txtCompleteness.Text = $"{result.Completeness:F1}/10";
            
            if (lstKeywords != null)
            {
                lstKeywords.Items.Clear();
                if (result.Keywords != null)
                {
                    foreach (var keyword in result.Keywords)
                    {
                        lstKeywords.Items.Add(keyword);
                    }
                }
            }
        }

        /// <summary>
        /// Setzt die Optimierungs-Ergebnisse in der UI
        /// </summary>
        public void SetOptimizationResults(string optimization)
        {
            OutputPrompt = optimization;
            if (txtSuggestions != null)
            {
                txtSuggestions.Text = "Optimization suggestions:\n" +
                                     "• Added structure and clarity\n" +
                                     "• Specified expected output format\n" +
                                     "• Enhanced context and requirements";
            }
        }

        /// <summary>
        /// Löscht alle UI-Felder
        /// </summary>
        public void ClearUI()
        {
            InputPrompt = string.Empty;
            OutputPrompt = string.Empty;
            if (txtClarity != null) txtClarity.Text = "0/10";
            if (txtSpecificity != null) txtSpecificity.Text = "0/10";
            if (txtCompleteness != null) txtCompleteness.Text = "0/10";
            if (lstKeywords != null) lstKeywords.Items.Clear();
            if (txtSuggestions != null) txtSuggestions.Text = string.Empty;
            UpdateWordCount();
        }

        /// <summary>
        /// Aktualisiert die Status-Bar
        /// </summary>
        public void SetStatus(string message)
        {
            UpdateStatus(message);
        }

        /// <summary>
        /// Zeigt eine Fehlermeldung
        /// </summary>
        public void ShowError(string message)
        {
            MessageBox.Show(this, message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            UpdateStatus("Error: " + message);
        }

        /// <summary>
        /// Zeigt eine Erfolgsmeldung
        /// </summary>
        public void ShowSuccess(string message)
        {
            UpdateStatus("✓ " + message);
        }

        /// <summary>
        /// Interne Methode zum Aktualisieren der Status-Bar
        /// </summary>
        private void UpdateStatus(string message)
        {
            if (lblStatus != null)
            {
                lblStatus.Text = message;
            }
        }
    }

    /// <summary>
    /// Hilfsklasse für Analyse-Ergebnisse
    /// </summary>
    public class AnalysisResult
    {
        public double Clarity { get; set; }
        public double Specificity { get; set; }
        public double Completeness { get; set; }
        public string[] Keywords { get; set; }
    }
}
