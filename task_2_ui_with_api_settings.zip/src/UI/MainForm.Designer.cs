namespace PromptOptimizer.UI
{
    partial class MainForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            
            // Main Controls
            this.tableLayoutPanel = new System.Windows.Forms.TableLayoutPanel();
            this.lblHeader = new System.Windows.Forms.Label();
            this.panelToolbar = new System.Windows.Forms.Panel();
            this.btnAPISettings = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnOptimize = new System.Windows.Forms.Button();
            this.btnAnalyze = new System.Windows.Forms.Button();
            
            // Input Section
            this.lblInputPrompt = new System.Windows.Forms.Label();
            this.txtInputPrompt = new System.Windows.Forms.TextBox();
            this.lblWordCount = new System.Windows.Forms.Label();
            
            // Analysis Results Section
            this.tabControlResults = new System.Windows.Forms.TabControl();
            this.tabMetrics = new System.Windows.Forms.TabPage();
            this.lstKeywords = new System.Windows.Forms.ListBox();
            this.lblKeywords = new System.Windows.Forms.Label();
            this.txtCompleteness = new System.Windows.Forms.TextBox();
            this.lblCompleteness = new System.Windows.Forms.Label();
            this.txtSpecificity = new System.Windows.Forms.TextBox();
            this.lblSpecificity = new System.Windows.Forms.Label();
            this.txtClarity = new System.Windows.Forms.TextBox();
            this.lblClarity = new System.Windows.Forms.Label();
            this.tabSuggestions = new System.Windows.Forms.TabPage();
            this.txtSuggestions = new System.Windows.Forms.TextBox();
            
            // Output Section
            this.lblOutputPrompt = new System.Windows.Forms.Label();
            this.txtOutputPrompt = new System.Windows.Forms.TextBox();
            this.btnCopyOutput = new System.Windows.Forms.Button();
            
            // Status Bar
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.lblStatus = new System.Windows.Forms.ToolStripStatusLabel();
            this.lblProvider = new System.Windows.Forms.ToolStripStatusLabel();

            // TableLayoutPanel
            this.tableLayoutPanel.ColumnCount = 1;
            this.tableLayoutPanel.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 100F));
            this.tableLayoutPanel.Controls.Add(this.lblHeader, 0, 0);
            this.tableLayoutPanel.Controls.Add(this.panelToolbar, 0, 1);
            this.tableLayoutPanel.Controls.Add(this.lblInputPrompt, 0, 2);
            this.tableLayoutPanel.Controls.Add(this.txtInputPrompt, 0, 3);
            this.tableLayoutPanel.Controls.Add(this.lblWordCount, 0, 4);
            this.tableLayoutPanel.Controls.Add(this.tabControlResults, 0, 5);
            this.tableLayoutPanel.Controls.Add(this.lblOutputPrompt, 0, 6);
            this.tableLayoutPanel.Controls.Add(this.txtOutputPrompt, 0, 7);
            this.tableLayoutPanel.Controls.Add(this.btnCopyOutput, 0, 8);
            this.tableLayoutPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tableLayoutPanel.RowCount = 9;
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 50F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 45F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 20F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 40F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 25F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 100F));
            this.tableLayoutPanel.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel.Padding = new System.Windows.Forms.Padding(10);

            // Header Label
            this.lblHeader.AutoSize = true;
            this.lblHeader.Font = new System.Drawing.Font("Segoe UI", 14F, System.Drawing.FontStyle.Bold);
            this.lblHeader.ForeColor = System.Drawing.Color.FromArgb(44, 62, 80);
            this.lblHeader.Text = "🎯 Prompt Optimizer";
            this.lblHeader.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            // Toolbar Panel
            this.panelToolbar.Controls.Add(this.btnAnalyze);
            this.panelToolbar.Controls.Add(this.btnOptimize);
            this.panelToolbar.Controls.Add(this.btnClear);
            this.panelToolbar.Controls.Add(this.btnAPISettings);
            this.panelToolbar.Dock = System.Windows.Forms.DockStyle.Fill;

            // Buttons
            this.btnAnalyze.BackColor = System.Drawing.Color.FromArgb(33, 150, 243);
            this.btnAnalyze.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAnalyze.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnAnalyze.ForeColor = System.Drawing.Color.White;
            this.btnAnalyze.Location = new System.Drawing.Point(10, 8);
            this.btnAnalyze.Name = "btnAnalyze";
            this.btnAnalyze.Size = new System.Drawing.Size(120, 30);
            this.btnAnalyze.TabIndex = 0;
            this.btnAnalyze.Text = "Analyze";
            this.btnAnalyze.UseVisualStyleBackColor = false;
            this.btnAnalyze.Click += new System.EventHandler(this.btnAnalyze_Click);

            this.btnOptimize.BackColor = System.Drawing.Color.FromArgb(33, 150, 243);
            this.btnOptimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnOptimize.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnOptimize.ForeColor = System.Drawing.Color.White;
            this.btnOptimize.Location = new System.Drawing.Point(140, 8);
            this.btnOptimize.Name = "btnOptimize";
            this.btnOptimize.Size = new System.Drawing.Size(140, 30);
            this.btnOptimize.TabIndex = 1;
            this.btnOptimize.Text = "Generate Optimization";
            this.btnOptimize.UseVisualStyleBackColor = false;
            this.btnOptimize.Click += new System.EventHandler(this.btnOptimize_Click);

            this.btnClear.BackColor = System.Drawing.Color.FromArgb(238, 238, 238);
            this.btnClear.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnClear.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnClear.ForeColor = System.Drawing.Color.FromArgb(51, 51, 51);
            this.btnClear.Location = new System.Drawing.Point(290, 8);
            this.btnClear.Name = "btnClear";
            this.btnClear.Size = new System.Drawing.Size(100, 30);
            this.btnClear.TabIndex = 2;
            this.btnClear.Text = "Clear All";
            this.btnClear.UseVisualStyleBackColor = false;
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);

            this.btnAPISettings.BackColor = System.Drawing.Color.FromArgb(238, 238, 238);
            this.btnAPISettings.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAPISettings.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnAPISettings.ForeColor = System.Drawing.Color.FromArgb(51, 51, 51);
            this.btnAPISettings.Location = new System.Drawing.Point(400, 8);
            this.btnAPISettings.Name = "btnAPISettings";
            this.btnAPISettings.Size = new System.Drawing.Size(120, 30);
            this.btnAPISettings.TabIndex = 3;
            this.btnAPISettings.Text = "⚙️ API Settings";
            this.btnAPISettings.UseVisualStyleBackColor = false;
            this.btnAPISettings.Click += new System.EventHandler(this.btnAPISettings_Click);

            // Input Prompt Label
            this.lblInputPrompt.AutoSize = true;
            this.lblInputPrompt.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblInputPrompt.ForeColor = System.Drawing.Color.FromArgb(51, 51, 51);
            this.lblInputPrompt.Text = "Original Prompt:";

            // Input TextBox
            this.txtInputPrompt.BackColor = System.Drawing.Color.White;
            this.txtInputPrompt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtInputPrompt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtInputPrompt.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtInputPrompt.ForeColor = System.Drawing.Color.FromArgb(51, 51, 51);
            this.txtInputPrompt.Multiline = true;
            this.txtInputPrompt.Name = "txtInputPrompt";
            this.txtInputPrompt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtInputPrompt.TabIndex = 4;
            this.txtInputPrompt.TextChanged += new System.EventHandler(this.txtInputPrompt_TextChanged);

            // Word Count Label
            this.lblWordCount.AutoSize = true;
            this.lblWordCount.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.lblWordCount.ForeColor = System.Drawing.Color.FromArgb(100, 100, 100);
            this.lblWordCount.Text = "Word Count: 0";

            // Tab Control
            this.tabControlResults.Controls.Add(this.tabMetrics);
            this.tabControlResults.Controls.Add(this.tabSuggestions);
            this.tabControlResults.Dock = System.Windows.Forms.DockStyle.Fill;
            this.tabControlResults.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.tabControlResults.Name = "tabControlResults";
            this.tabControlResults.SelectedIndex = 0;
            this.tabControlResults.TabIndex = 5;

            // Metrics Tab
            this.tabMetrics.BackColor = System.Drawing.Color.FromArgb(245, 245, 245);
            this.tabMetrics.Controls.Add(this.lblClarity);
            this.tabMetrics.Controls.Add(this.txtClarity);
            this.tabMetrics.Controls.Add(this.lblSpecificity);
            this.tabMetrics.Controls.Add(this.txtSpecificity);
            this.tabMetrics.Controls.Add(this.lblCompleteness);
            this.tabMetrics.Controls.Add(this.txtCompleteness);
            this.tabMetrics.Controls.Add(this.lblKeywords);
            this.tabMetrics.Controls.Add(this.lstKeywords);
            this.tabMetrics.Name = "tabMetrics";
            this.tabMetrics.Padding = new System.Windows.Forms.Padding(10);
            this.tabMetrics.Text = "Metrics";

            this.lblClarity.AutoSize = true;
            this.lblClarity.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblClarity.Location = new System.Drawing.Point(10, 10);
            this.lblClarity.Text = "Clarity:";

            this.txtClarity.BackColor = System.Drawing.Color.White;
            this.txtClarity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtClarity.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtClarity.Location = new System.Drawing.Point(100, 10);
            this.txtClarity.Name = "txtClarity";
            this.txtClarity.ReadOnly = true;
            this.txtClarity.Size = new System.Drawing.Size(150, 25);
            this.txtClarity.TabIndex = 0;
            this.txtClarity.Text = "0/10";

            this.lblSpecificity.AutoSize = true;
            this.lblSpecificity.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblSpecificity.Location = new System.Drawing.Point(10, 45);
            this.lblSpecificity.Text = "Specificity:";

            this.txtSpecificity.BackColor = System.Drawing.Color.White;
            this.txtSpecificity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSpecificity.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtSpecificity.Location = new System.Drawing.Point(100, 45);
            this.txtSpecificity.Name = "txtSpecificity";
            this.txtSpecificity.ReadOnly = true;
            this.txtSpecificity.Size = new System.Drawing.Size(150, 25);
            this.txtSpecificity.TabIndex = 1;
            this.txtSpecificity.Text = "0/10";

            this.lblCompleteness.AutoSize = true;
            this.lblCompleteness.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblCompleteness.Location = new System.Drawing.Point(10, 80);
            this.lblCompleteness.Text = "Completeness:";

            this.txtCompleteness.BackColor = System.Drawing.Color.White;
            this.txtCompleteness.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtCompleteness.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtCompleteness.Location = new System.Drawing.Point(100, 80);
            this.txtCompleteness.Name = "txtCompleteness";
            this.txtCompleteness.ReadOnly = true;
            this.txtCompleteness.Size = new System.Drawing.Size(150, 25);
            this.txtCompleteness.TabIndex = 2;
            this.txtCompleteness.Text = "0/10";

            this.lblKeywords.AutoSize = true;
            this.lblKeywords.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lblKeywords.Location = new System.Drawing.Point(10, 115);
            this.lblKeywords.Text = "Keywords:";

            this.lstKeywords.BackColor = System.Drawing.Color.White;
            this.lstKeywords.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lstKeywords.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.lstKeywords.FormattingEnabled = true;
            this.lstKeywords.Location = new System.Drawing.Point(10, 135);
            this.lstKeywords.Name = "lstKeywords";
            this.lstKeywords.Size = new System.Drawing.Size(240, 100);
            this.lstKeywords.TabIndex = 3;

            // Suggestions Tab
            this.tabSuggestions.BackColor = System.Drawing.Color.FromArgb(245, 245, 245);
            this.tabSuggestions.Controls.Add(this.txtSuggestions);
            this.tabSuggestions.Name = "tabSuggestions";
            this.tabSuggestions.Padding = new System.Windows.Forms.Padding(10);
            this.tabSuggestions.Text = "Suggestions";

            this.txtSuggestions.BackColor = System.Drawing.Color.White;
            this.txtSuggestions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtSuggestions.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtSuggestions.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtSuggestions.ForeColor = System.Drawing.Color.FromArgb(51, 51, 51);
            this.txtSuggestions.Multiline = true;
            this.txtSuggestions.Name = "txtSuggestions";
            this.txtSuggestions.ReadOnly = true;
            this.txtSuggestions.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtSuggestions.TabIndex = 0;

            // Output Prompt Label
            this.lblOutputPrompt.AutoSize = true;
            this.lblOutputPrompt.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Bold);
            this.lblOutputPrompt.ForeColor = System.Drawing.Color.FromArgb(51, 51, 51);
            this.lblOutputPrompt.Text = "Optimized Prompt:";

            // Output TextBox
            this.txtOutputPrompt.BackColor = System.Drawing.Color.White;
            this.txtOutputPrompt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.txtOutputPrompt.Dock = System.Windows.Forms.DockStyle.Fill;
            this.txtOutputPrompt.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.txtOutputPrompt.ForeColor = System.Drawing.Color.FromArgb(51, 51, 51);
            this.txtOutputPrompt.Multiline = true;
            this.txtOutputPrompt.Name = "txtOutputPrompt";
            this.txtOutputPrompt.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtOutputPrompt.TabIndex = 6;

            // Copy Button
            this.btnCopyOutput.BackColor = System.Drawing.Color.White;
            this.btnCopyOutput.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCopyOutput.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.btnCopyOutput.ForeColor = System.Drawing.Color.FromArgb(51, 51, 51);
            this.btnCopyOutput.Location = new System.Drawing.Point(10, 10);
            this.btnCopyOutput.Name = "btnCopyOutput";
            this.btnCopyOutput.Size = new System.Drawing.Size(150, 30);
            this.btnCopyOutput.TabIndex = 7;
            this.btnCopyOutput.Text = "Copy to Clipboard";
            this.btnCopyOutput.UseVisualStyleBackColor = false;
            this.btnCopyOutput.Click += new System.EventHandler(this.btnCopyOutput_Click);

            // Status Strip
            this.statusStrip.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
                this.lblStatus,
                this.lblProvider});
            this.statusStrip.Location = new System.Drawing.Point(0, 575);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(900, 25);
            this.statusStrip.TabIndex = 8;

            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(700, 20);
            this.lblStatus.Spring = true;
            this.lblStatus.Text = "Ready";
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;

            this.lblProvider.Name = "lblProvider";
            this.lblProvider.Size = new System.Drawing.Size(200, 20);
            this.lblProvider.Text = "AI Provider: Groq";
            this.lblProvider.TextAlign = System.Drawing.ContentAlignment.MiddleRight;

            // MainForm
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(245, 245, 245);
            this.ClientSize = new System.Drawing.Size(900, 600);
            this.Controls.Add(this.tableLayoutPanel);
            this.Controls.Add(this.statusStrip);
            this.Font = new System.Drawing.Font("Segoe UI", 10F);
            this.Name = "MainForm";
            this.Text = "Prompt Optimizer";
            this.Load += new System.EventHandler(this.MainForm_Load);
            this.tableLayoutPanel.ResumeLayout(false);
            this.tableLayoutPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();
        }

        // Control declarations
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel;
        private System.Windows.Forms.Label lblHeader;
        private System.Windows.Forms.Panel panelToolbar;
        private System.Windows.Forms.Button btnAnalyze;
        private System.Windows.Forms.Button btnOptimize;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnAPISettings;
        private System.Windows.Forms.Label lblInputPrompt;
        private System.Windows.Forms.TextBox txtInputPrompt;
        private System.Windows.Forms.Label lblWordCount;
        private System.Windows.Forms.TabControl tabControlResults;
        private System.Windows.Forms.TabPage tabMetrics;
        private System.Windows.Forms.TabPage tabSuggestions;
        private System.Windows.Forms.Label lblClarity;
        private System.Windows.Forms.TextBox txtClarity;
        private System.Windows.Forms.Label lblSpecificity;
        private System.Windows.Forms.TextBox txtSpecificity;
        private System.Windows.Forms.Label lblCompleteness;
        private System.Windows.Forms.TextBox txtCompleteness;
        private System.Windows.Forms.Label lblKeywords;
        private System.Windows.Forms.ListBox lstKeywords;
        private System.Windows.Forms.TextBox txtSuggestions;
        private System.Windows.Forms.Label lblOutputPrompt;
        private System.Windows.Forms.TextBox txtOutputPrompt;
        private System.Windows.Forms.Button btnCopyOutput;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ToolStripStatusLabel lblStatus;
        private System.Windows.Forms.ToolStripStatusLabel lblProvider;
    }
}
