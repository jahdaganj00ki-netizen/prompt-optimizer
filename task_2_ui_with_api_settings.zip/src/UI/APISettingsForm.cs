using System;
using System.Windows.Forms;
using System.Threading.Tasks;
using System.Diagnostics;

namespace PromptOptimizer.UI
{
    /// <summary>
    /// APISettingsForm - Modaler Dialog für API-Konfiguration
    /// Ermöglicht Eingabe und Test von Groq + Google AI API-Schlüsseln
    /// </summary>
    public partial class APISettingsForm : Form
    {
        private bool _groqKeyValid = false;
        private bool _googleKeyValid = false;

        public APISettingsForm()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Wird beim Laden des Dialogs aufgerufen
        /// </summary>
        private void APISettingsForm_Load(object sender, EventArgs e)
        {
            this.Text = "API Configuration - Groq & Google AI";
            this.Size = new System.Drawing.Size(600, 400);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;

            // ComboBox initialisieren
            if (cbProvider != null)
            {
                cbProvider.Items.Add("Groq");
                cbProvider.Items.Add("Google");
                cbProvider.SelectedIndex = 0;
            }
        }

        /// <summary>
        /// Öffnet den Browser zur Groq API-Schlüssel-Beschaffung
        /// </summary>
        private void btnGetGroqKey_Click(object sender, EventArgs e)
        {
            OpenUrl("https://console.groq.com");
        }

        /// <summary>
        /// Öffnet den Browser zur Google AI API-Schlüssel-Beschaffung
        /// </summary>
        private void btnGetGoogleKey_Click(object sender, EventArgs e)
        {
            OpenUrl("https://aistudio.google.com");
        }

        /// <summary>
        /// Testet den Groq API-Schlüssel
        /// </summary>
        private void btnTestGroq_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(GroqApiKey))
            {
                MessageBox.Show(this, "Please enter a Groq API key first", "Validation Error", 
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ValidateGroqKeyAsync();
        }

        /// <summary>
        /// Testet den Google AI API-Schlüssel
        /// </summary>
        private void btnTestGoogle_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(GoogleApiKey))
            {
                MessageBox.Show(this, "Please enter a Google API key first", "Validation Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            ValidateGoogleKeyAsync();
        }

        /// <summary>
        /// Speichert die API-Einstellungen
        /// </summary>
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(GroqApiKey) && string.IsNullOrWhiteSpace(GoogleApiKey))
            {
                MessageBox.Show(this, "Please enter at least one API key", "Validation Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Hier würde die Speicherung via APIKeyManager erfolgen
            // Beispiel: APIKeyManager.SaveKeysAsync(GroqApiKey, GoogleApiKey, PreferredProvider);

            MessageBox.Show(this, "API settings saved successfully", "Success",
                           MessageBoxButtons.OK, MessageBoxIcon.Information);

            this.DialogResult = DialogResult.OK;
            this.Close();
        }

        /// <summary>
        /// Schließt den Dialog ohne zu speichern
        /// </summary>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.DialogResult = DialogResult.Cancel;
            this.Close();
        }

        /// <summary>
        /// Öffnet die Dokumentation
        /// </summary>
        private void btnDocumentation_Click(object sender, EventArgs e)
        {
            MessageBox.Show(this, 
                "API Configuration Documentation:\n\n" +
                "Groq:\n" +
                "- Model: llama-3.3-70b-versatile\n" +
                "- Free limit: 14,400 tokens/day\n" +
                "- Get key at: https://console.groq.com\n\n" +
                "Google AI:\n" +
                "- Model: gemini-2.5-flash\n" +
                "- Free limit: 32,000 tokens/day\n" +
                "- Get key at: https://aistudio.google.com",
                "Documentation",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        /// <summary>
        /// Validiert den Groq API-Schlüssel asynchron
        /// </summary>
        public async Task ValidateGroqKeyAsync()
        {
            try
            {
                // Hier würde die echte Validierung via GroqConnector erfolgen
                // Beispiel: bool isValid = await GroqConnector.ValidateKeyAsync(GroqApiKey);

                // Demo-Validierung
                bool isValid = !string.IsNullOrWhiteSpace(GroqApiKey) && GroqApiKey.StartsWith("gsk_");

                _groqKeyValid = isValid;
                
                if (lblGroqStatus != null)
                {
                    lblGroqStatus.Text = isValid ? "✓ Valid" : "✗ Invalid";
                    lblGroqStatus.ForeColor = isValid ? 
                        System.Drawing.Color.FromArgb(76, 175, 80) : 
                        System.Drawing.Color.FromArgb(244, 67, 54);
                }

                string message = isValid ? "Groq API key is valid!" : "Groq API key is invalid";
                MessageBox.Show(this, message, isValid ? "Success" : "Error",
                               MessageBoxButtons.OK, 
                               isValid ? MessageBoxIcon.Information : MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Error validating Groq key: {ex.Message}", "Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Validiert den Google AI API-Schlüssel asynchron
        /// </summary>
        public async Task ValidateGoogleKeyAsync()
        {
            try
            {
                // Hier würde die echte Validierung via GoogleAIConnector erfolgen
                // Beispiel: bool isValid = await GoogleAIConnector.ValidateKeyAsync(GoogleApiKey);

                // Demo-Validierung
                bool isValid = !string.IsNullOrWhiteSpace(GoogleApiKey) && GoogleApiKey.StartsWith("AIza_");

                _googleKeyValid = isValid;

                if (lblGoogleStatus != null)
                {
                    lblGoogleStatus.Text = isValid ? "✓ Valid" : "✗ Invalid";
                    lblGoogleStatus.ForeColor = isValid ?
                        System.Drawing.Color.FromArgb(76, 175, 80) :
                        System.Drawing.Color.FromArgb(244, 67, 54);
                }

                string message = isValid ? "Google API key is valid!" : "Google API key is invalid";
                MessageBox.Show(this, message, isValid ? "Success" : "Error",
                               MessageBoxButtons.OK,
                               isValid ? MessageBoxIcon.Information : MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Error validating Google key: {ex.Message}", "Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        /// <summary>
        /// Öffnet eine URL im Standard-Browser
        /// </summary>
        private void OpenUrl(string url)
        {
            try
            {
                ProcessStartInfo psi = new ProcessStartInfo
                {
                    FileName = url,
                    UseShellExecute = true
                };
                Process.Start(psi);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, $"Error opening URL: {ex.Message}", "Error",
                               MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        // ============ PUBLIC PROPERTIES ============

        /// <summary>
        /// Groq API-Schlüssel Property
        /// </summary>
        public string GroqApiKey
        {
            get { return txtGroqKey?.Text ?? string.Empty; }
            set { if (txtGroqKey != null) txtGroqKey.Text = value; }
        }

        /// <summary>
        /// Google AI API-Schlüssel Property
        /// </summary>
        public string GoogleApiKey
        {
            get { return txtGoogleKey?.Text ?? string.Empty; }
            set { if (txtGoogleKey != null) txtGoogleKey.Text = value; }
        }

        /// <summary>
        /// Bevorzugter Provider Property
        /// </summary>
        public string PreferredProvider
        {
            get { return cbProvider?.SelectedItem?.ToString() ?? "Groq"; }
            set 
            { 
                if (cbProvider != null && value != null)
                {
                    cbProvider.SelectedItem = value;
                }
            }
        }
    }
}
