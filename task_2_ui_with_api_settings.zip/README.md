# Prompt Optimizer - WinForms UI & API Settings

Professionelle Windows Forms-Anwendung für die Prompt-Optimierung mit integriertem API-Konfigurationsdialog.

## Übersicht

Diese Implementierung enthält:

- **MainForm.cs** - Hauptbenutzeroberfläche mit Prompt-Analyse und -Optimierung
- **APISettingsForm.cs** - Modaler Dialog für Groq + Google AI API-Konfiguration
- **Designer-Dateien** - Auto-generierter WinForms-Code
- **Vollständige Event-Handler** - Alle Benutzerinteraktionen implementiert

## Anforderungen

- .NET Framework 4.7.2
- Visual Studio 2019 oder höher
- Windows 7 oder höher

## Projektstruktur

```
prompt_optimizer_ui/
├── src/
│   └── UI/
│       ├── MainForm.cs
│       ├── MainForm.Designer.cs
│       ├── MainForm.resx
│       ├── APISettingsForm.cs
│       ├── APISettingsForm.Designer.cs
│       ├── APISettingsForm.resx
│       └── Program.cs
├── PromptOptimizer.UI.csproj
├── app.config
└── README.md
```

## Funktionen

### MainForm (Hauptformular)

**Größe:** 900x600 Pixel (resizable, Minimum: 800x500)

**Komponenten:**
- **Header:** Titel mit Status-Anzeige
- **Toolbar:** Buttons für Analyze, Optimize, Clear, API Settings
- **Input-Bereich:** TextBox für Prompt-Eingabe mit Wortanzahl
- **Analyse-Tabs:** 
  - Metrics: Clarity, Specificity, Completeness, Keywords
  - Suggestions: Optimierungsvorschläge
- **Output-Bereich:** TextBox für optimierten Prompt
- **Status-Bar:** Aktuelle Aktion und Provider-Information

**Event-Handler:**
- `btnAnalyze_Click()` - Analysiert den eingegebenen Prompt
- `btnOptimize_Click()` - Optimiert mit Groq oder Google AI
- `btnClear_Click()` - Löscht alle Felder
- `btnCopyOutput_Click()` - Kopiert Output in Zwischenablage
- `btnAPISettings_Click()` - Öffnet API-Konfigurationsdialog
- `txtInputPrompt_TextChanged()` - Aktualisiert Wortanzahl
- Tastaturkürzel: Ctrl+L (Analyze), Ctrl+O (Optimize), Ctrl+C (Copy), Ctrl+K (API Settings)

### APISettingsForm (API-Konfigurationsdialog)

**Größe:** 600x400 Pixel (nicht resizable, modal)

**Komponenten:**

**Groq Sektion:**
- API Key TextBox (maskiert)
- Link zu https://console.groq.com
- Test-Button mit Validierung
- Status-Anzeige (✓ Valid / ✗ Invalid)
- Model-Info: llama-3.3-70b-versatile
- Limit-Info: 14,400 tokens/day

**Google AI Sektion:**
- API Key TextBox (maskiert)
- Link zu https://aistudio.google.com
- Test-Button mit Validierung
- Status-Anzeige (✓ Valid / ✗ Invalid)
- Model-Info: gemini-2.5-flash
- Limit-Info: 32,000 tokens/day

**Provider Sektion:**
- ComboBox zur Auswahl des bevorzugten Providers
- Hinweis: Google wird als Fallback verwendet

**Dialog-Buttons:**
- Save - Speichert die Einstellungen
- Cancel - Schließt ohne zu speichern
- Documentation - Zeigt Hilfe an

**Event-Handler:**
- `btnGetGroqKey_Click()` - Öffnet Browser zu Groq Console
- `btnGetGoogleKey_Click()` - Öffnet Browser zu Google AI Studio
- `btnTestGroq_Click()` - Validiert Groq API-Schlüssel
- `btnTestGoogle_Click()` - Validiert Google API-Schlüssel
- `btnSave_Click()` - Speichert Einstellungen
- `btnCancel_Click()` - Schließt Dialog
- `btnDocumentation_Click()` - Zeigt Dokumentation

## Styling

### Farben
| Element | Farbe | Hex |
|---------|-------|-----|
| Background | Light Gray | #F5F5F5 |
| Primary Buttons | Teal | #2196F3 |
| Secondary Buttons | Light Gray | #EEEEEE |
| Text | Dark Gray | #333333 |
| Input Fields | White | #FFFFFF |
| Headers | Dark | #2C3E50 |
| Valid Status | Green | #4CAF50 |
| Invalid Status | Red | #F44336 |

### Fonts
- **Familie:** Segoe UI (Standard Windows Font)
- **Body Text:** 10pt
- **Headers:** 12pt Bold
- **Labels:** 11pt

### Spacing
- Padding zwischen Elementen: 8-10px
- Border Radius: 4px (Button-Ecken)

## Responsiveness

- Alle Steuerelemente verwenden Anchor/Dock-Eigenschaften
- TextBoxes passen sich der Fenstergröße an
- Buttons behalten ihre Größe und Position
- Minimum-Fenstergröße: 800x500
- Dialog ist nicht resizable und zentriert auf Parent-Fenster

## Accessibility

- Alle Buttons haben aussagekräftige Namen
- Korrekte Tab-Reihenfolge (logischer Ablauf)
- Tastaturkürzel implementiert
- Screen-Reader-freundliche Labels

## Tastaturkürzel

| Kürzel | Funktion |
|--------|----------|
| Ctrl+L | Analyze Prompt |
| Ctrl+O | Generate Optimization |
| Ctrl+C | Copy to Clipboard |
| Ctrl+K | API Settings |

## Verwendung

### Kompilierung

```bash
# Mit Visual Studio
# 1. Öffne PromptOptimizer.UI.csproj
# 2. Klicke auf "Build" > "Build Solution"
# 3. Starte die Anwendung mit F5

# Mit MSBuild (Command Line)
msbuild PromptOptimizer.UI.csproj /p:Configuration=Release
```

### Ausführung

```bash
# Nach erfolgreicher Kompilierung
bin\Release\PromptOptimizer.UI.exe
```

## Integrationen

Diese UI ist vorbereitet für die Integration mit:

- **PromptAnalyzer** - Für Clarity, Specificity, Completeness-Berechnung
- **PromptOptimizer** - Für Optimierungsvorschläge
- **GroqConnector** - Für Groq API-Aufrufe
- **GoogleAIConnector** - Für Google AI API-Aufrufe
- **APIKeyManager** - Für sichere Speicherung von API-Schlüsseln

## Code-Standards

- **Separation of Concerns:** Keine Business-Logik in UI-Code
- **Aussagekräftige Namen:** Alle Steuerelemente haben beschreibende Namen
- **Kommentare:** Komplexe UI-Logik ist dokumentiert
- **Standard WinForms Patterns:** Nur bewährte Muster verwendet
- **.NET 4.7.2 Kompatibilität:** Nur kompatible Syntax

## Sicherheit

- API-Schlüssel werden mit `PasswordChar = '*'` maskiert
- Schlüssel werden nicht im Klartext angezeigt nach dem Speichern
- Dialog ist modal (blockiert Hauptfenster bis zum Schließen)
- Validierung vor dem Speichern erforderlich

## Zukünftige Erweiterungen

- Integration mit echten API-Connectoren
- Persistente Speicherung von API-Schlüsseln
- Erweiterte Fehlerbehandlung
- Logging und Debugging-Funktionen
- Benutzereinstellungen und Präferenzen
- Mehrsprachige Unterstützung

## Lizenz

Proprietary - Prompt Optimizer Project

## Support

Für Fragen oder Probleme, bitte kontaktieren Sie das Entwicklungsteam.
