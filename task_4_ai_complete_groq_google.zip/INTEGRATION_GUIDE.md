# Prompt Optimizer - Groq + Google AI Integration Guide

## Overview

This integration layer connects the Prompt Optimizer Windows application to two cloud-based AI providers:
- **Primary**: Groq (llama-3.3-70b-versatile) - Fast, free tier with 14,400 tokens/day
- **Fallback**: Google AI (gemini-2.5-flash) - Reliable, free tier with 32,000 tokens/day

## Components

### 1. APIKeyManager.cs
**Purpose**: Secure local storage of API keys

**Features**:
- Stores keys in `C:\Users\[User]\AppData\Roaming\PromptOptimizer\api_keys.json`
- Never logs or displays API keys
- Async/await pattern for non-blocking operations
- Graceful error handling

**Key Methods**:
```csharp
// Load keys from storage
APIKeys keys = await APIKeyManager.LoadKeysAsync();

// Save keys securely
await APIKeyManager.SaveKeysAsync(keys);

// Check if keys are configured
bool hasKeys = await APIKeyManager.HasKeysConfiguredAsync();

// Get preferred provider
string provider = await APIKeyManager.GetPreferredProviderAsync();
```

### 2. GroqConnector.cs
**Purpose**: REST API wrapper for Groq communication

**Features**:
- Connects to `https://api.groq.com/openai/v1/chat/completions`
- Uses llama-3.3-70b-versatile model
- 10-second timeout per request
- Validates key format (must start with "gsk_")
- Comprehensive error handling

**Key Methods**:
```csharp
// Validate API key
bool isValid = await GroqConnector.ValidateKeyAsync(apiKey);

// Optimize prompt
string improved = await GroqConnector.EnhancePromptAsync(apiKey, originalPrompt);

// Check API availability
bool available = await GroqConnector.IsAvailableAsync();
```

### 3. GoogleAIConnector.cs
**Purpose**: REST API wrapper for Google AI communication

**Features**:
- Connects to `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent`
- Uses gemini-2.5-flash model
- 10-second timeout per request
- Validates key format (must start with "AIza")
- Comprehensive error handling

**Key Methods**:
```csharp
// Validate API key
bool isValid = await GoogleAIConnector.ValidateKeyAsync(apiKey);

// Optimize prompt
string improved = await GoogleAIConnector.EnhancePromptAsync(apiKey, originalPrompt);

// Check API availability
bool available = await GoogleAIConnector.IsAvailableAsync();
```

### 4. AIProvider.cs
**Purpose**: High-level orchestrator with primary/fallback logic

**Features**:
- Automatic failover from Groq to Google AI
- Prefers configured provider
- Validates both keys before use
- Returns user-friendly error messages (German + English)

**Key Methods**:
```csharp
// Optimize prompt with automatic failover
string result = await AIProvider.OptimizePromptAsync(originalPrompt);

// Get active provider status
string provider = await AIProvider.GetActiveProviderAsync(); // "Groq", "Google", "Not Configured"

// Validate keys before saving
var (isValid, message) = await AIProvider.ValidateKeysAsync(groqKey, googleKey);
```

### 5. APILogger.cs
**Purpose**: Log all API interactions without exposing sensitive data

**Features**:
- Logs to `C:\Users\[User]\AppData\Roaming\PromptOptimizer\logs\api.log`
- Never logs API keys or full prompts
- Logs request/response metadata (timestamp, provider, length, duration)
- Logs errors and retry attempts

**Log Entry Examples**:
```
[2024-01-18 14:30:45] REQUEST - Provider: Groq, Prompt Length: 150 chars
[2024-01-18 14:30:47] RESPONSE - Provider: Groq, Response Length: 200 chars, Duration: 2150ms
[2024-01-18 14:31:00] ERROR - Provider: Groq, Error Type: Timeout, Retry: Fallback to Google
```

## Integration with MainForm.cs

### Add API Settings Button
```csharp
// In MainForm designer or constructor
Button btnAPISettings = new Button();
btnAPISettings.Text = "API Settings";
btnAPISettings.Click += BtnAPISettings_Click;
this.Controls.Add(btnAPISettings);
```

### Handle Optimize Button Click
```csharp
private async void BtnOptimize_Click(object sender, EventArgs e)
{
    try
    {
        lblStatus.Text = "Optimizing...";
        string inputPrompt = txtInputPrompt.Text;
        
        // Call AI Provider
        string result = await AIProvider.OptimizePromptAsync(inputPrompt);
        
        if (result.StartsWith("ERROR:"))
        {
            MessageBox.Show(result, "Optimization Failed", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        else
        {
            txtOutputPrompt.Text = result;
            
            // Update provider display
            string activeProvider = await AIProvider.GetActiveProviderAsync();
            lblProvider.Text = $"Provider: {activeProvider}";
            
            lblStatus.Text = "Optimization complete";
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        lblStatus.Text = "Error";
    }
}
```

### Handle API Settings Button Click
```csharp
private void BtnAPISettings_Click(object sender, EventArgs e)
{
    // Open API Settings dialog (from Task 2)
    APISettingsForm settingsForm = new APISettingsForm();
    settingsForm.ShowDialog();
    
    // Update provider display after settings change
    UpdateProviderDisplay();
}

private async void UpdateProviderDisplay()
{
    string activeProvider = await AIProvider.GetActiveProviderAsync();
    lblProvider.Text = $"Provider: {activeProvider}";
}
```

## Getting API Keys

### Groq API Key
1. Visit https://console.groq.com
2. Sign up (free)
3. Create API key
4. Key format: `gsk_...`
5. Free tier: 14,400 tokens/day

### Google AI API Key
1. Visit https://aistudio.google.com
2. Sign in with Google account
3. Create API key
4. Key format: `AIza...`
5. Free tier: 32,000 tokens/day

## Error Handling

### Error Messages (German)
- **"Groq API Key ungültig"** - Key format incorrect or API unreachable
- **"Google AI API Key ungültig"** - Key format incorrect or API unreachable
- **"Groq nicht erreichbar. Fallback zu Google..."** - Primary provider failed, using fallback
- **"Google AI nicht erreichbar. Fallback zu Groq..."** - Primary provider failed, using fallback
- **"Keine API Keys konfiguriert"** - No keys stored, user must configure in API Settings
- **"Alle Optimierungsanbieter fehlgeschlagen"** - Both providers failed, check internet and keys

### Timeout Handling
- Request timeout: 10 seconds per API call
- On timeout: Automatically tries fallback provider
- If both timeout: Returns error message

### Network Error Handling
- Connection failures caught and logged
- Automatic fallback to secondary provider
- User-friendly error messages

## Security Considerations

### Key Storage
- Keys stored locally only in AppData\Roaming
- JSON format with standard encryption (Windows DPAPI optional)
- Never transmitted except to official APIs
- Never backed up to cloud
- User can delete by deleting `api_keys.json`

### Key Protection
- Never logged in debug output
- Never displayed in UI after saving
- Never transmitted over unencrypted connections
- Never stored in application config or registry

### Best Practices
- Regenerate keys if compromised
- Use separate keys for development/production
- Monitor API usage in provider dashboards
- Rotate keys periodically

## Performance Considerations

### Async/Await Pattern
- All network calls are non-blocking
- UI remains responsive during optimization
- Support for CancellationToken for cancellable requests

### HTTP Client Reuse
- Static HttpClient per provider
- Connection pooling for efficiency
- Timeout: 10 seconds per request

### Retry Logic
- Automatic failover from primary to fallback
- Retry once on timeout before giving up
- No infinite retry loops

## Testing

### Manual Testing Steps
1. **Test Key Validation**
   ```csharp
   bool valid = await GroqConnector.ValidateKeyAsync("gsk_...");
   bool valid = await GoogleAIConnector.ValidateKeyAsync("AIza...");
   ```

2. **Test Prompt Optimization**
   ```csharp
   string improved = await AIProvider.OptimizePromptAsync("Make me a prompt");
   ```

3. **Test Failover**
   - Set invalid Groq key, valid Google key
   - Verify fallback to Google works
   - Check logs for failover message

4. **Test Error Handling**
   - Disconnect internet, verify error message
   - Use invalid key format, verify validation fails
   - Test timeout with slow network

### Log File Review
- Location: `C:\Users\[User]\AppData\Roaming\PromptOptimizer\logs\api.log`
- Review request/response times
- Check for errors and retry attempts
- Verify no keys are logged

## Troubleshooting

### "Invalid API key format"
- Groq keys must start with `gsk_`
- Google keys must start with `AIza`
- Check for typos or extra spaces

### "Cannot reach [Provider]"
- Check internet connection
- Verify firewall allows HTTPS (port 443)
- Check provider status page
- Try fallback provider

### "Timeout (>10 seconds)"
- Check internet speed
- Try again (may be temporary)
- Fallback provider will be attempted
- Check provider status

### "All optimization providers failed"
- Verify both API keys are valid
- Check internet connection
- Verify keys in API Settings dialog
- Check logs for detailed error messages

## File Structure

```
src/AI/
├── APIKeyManager.cs          # Secure key storage
├── GroqConnector.cs          # Groq API wrapper
├── GoogleAIConnector.cs      # Google AI API wrapper
├── AIProvider.cs             # Orchestrator with failover
└── APILogger.cs              # API interaction logging

AppData/Roaming/PromptOptimizer/
├── api_keys.json             # Stored API keys
└── logs/
    └── api.log               # API interaction log
```

## Dependencies

### NuGet Packages Required
- `Newtonsoft.Json` (for JSON serialization)
- `log4net` (optional, for advanced logging)

### .NET Framework
- .NET 4.7.2 or higher
- Async/await support required

## Future Enhancements

- [ ] Support for additional AI providers (OpenAI, Anthropic)
- [ ] Caching of optimization results
- [ ] Batch prompt optimization
- [ ] Custom system prompts for optimization
- [ ] Provider performance metrics
- [ ] Scheduled key rotation
- [ ] Encryption of stored keys (DPAPI)

## Support

For issues or questions:
1. Check the troubleshooting section
2. Review API provider documentation
3. Check logs at `AppData\Roaming\PromptOptimizer\logs\api.log`
4. Verify API keys at provider dashboards
