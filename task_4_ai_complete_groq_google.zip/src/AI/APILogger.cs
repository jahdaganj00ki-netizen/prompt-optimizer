using System;
using System.IO;
using System.Threading.Tasks;

namespace PromptOptimizer.AI
{
    /// <summary>
    /// Logs all API interactions without exposing sensitive data (keys, full prompts).
    /// Log file: logs/api.log
    /// </summary>
    public class APILogger
    {
        private static readonly string LogDirectory = 
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), 
                        "PromptOptimizer", "logs");
        private static readonly string LogFilePath = 
            Path.Combine(LogDirectory, "api.log");

        static APILogger()
        {
            EnsureLogDirectoryExists();
        }

        /// <summary>
        /// Ensure log directory exists
        /// </summary>
        private static void EnsureLogDirectoryExists()
        {
            try
            {
                if (!Directory.Exists(LogDirectory))
                {
                    Directory.CreateDirectory(LogDirectory);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error creating log directory: {ex.Message}");
            }
        }

        /// <summary>
        /// Log API request (without exposing keys or full prompts)
        /// </summary>
        public static async Task LogRequestAsync(string provider, int promptLength)
        {
            try
            {
                string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] REQUEST - Provider: {provider}, Prompt Length: {promptLength} chars";
                await AppendToLogAsync(logEntry);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error logging request: {ex.Message}");
            }
        }

        /// <summary>
        /// Log API response
        /// </summary>
        public static async Task LogResponseAsync(string provider, int responseLength, long durationMs)
        {
            try
            {
                string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] RESPONSE - Provider: {provider}, Response Length: {responseLength} chars, Duration: {durationMs}ms";
                await AppendToLogAsync(logEntry);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error logging response: {ex.Message}");
            }
        }

        /// <summary>
        /// Log API error
        /// </summary>
        public static async Task LogErrorAsync(string provider, string errorType, string retryAttempt = "")
        {
            try
            {
                string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] ERROR - Provider: {provider}, Error Type: {errorType}{(string.IsNullOrEmpty(retryAttempt) ? "" : $", Retry: {retryAttempt}")}";
                await AppendToLogAsync(logEntry);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error logging error: {ex.Message}");
            }
        }

        /// <summary>
        /// Log key validation
        /// </summary>
        public static async Task LogKeyValidationAsync(string provider, bool isValid)
        {
            try
            {
                string logEntry = $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] KEY_VALIDATION - Provider: {provider}, Valid: {isValid}";
                await AppendToLogAsync(logEntry);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error logging key validation: {ex.Message}");
            }
        }

        /// <summary>
        /// Append entry to log file
        /// </summary>
        private static async Task AppendToLogAsync(string logEntry)
        {
            try
            {
                EnsureLogDirectoryExists();
                await File.AppendAllTextAsync(LogFilePath, logEntry + Environment.NewLine);
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error writing to log file: {ex.Message}");
            }
        }

        /// <summary>
        /// Get log file path
        /// </summary>
        public static string GetLogFilePath()
        {
            return LogFilePath;
        }

        /// <summary>
        /// Clear log file
        /// </summary>
        public static async Task ClearLogAsync()
        {
            try
            {
                if (File.Exists(LogFilePath))
                {
                    File.Delete(LogFilePath);
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error clearing log: {ex.Message}");
            }
        }
    }
}
