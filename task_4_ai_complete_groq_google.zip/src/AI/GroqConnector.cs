using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace PromptOptimizer.AI
{
    /// <summary>
    /// REST API wrapper for Groq API communication.
    /// Connects to Groq using llama-3.3-70b-versatile model.
    /// </summary>
    public class GroqConnector
    {
        private static readonly string BASE_URL = "https://api.groq.com";
        private static readonly string API_ENDPOINT = "/openai/v1/chat/completions";
        private static readonly string MODEL = "llama-3.3-70b-versatile";
        private static readonly int TIMEOUT_SECONDS = 10;

        private static HttpClient _httpClient;

        static GroqConnector()
        {
            _httpClient = new HttpClient();
            _httpClient.Timeout = TimeSpan.FromSeconds(TIMEOUT_SECONDS);
        }

        /// <summary>
        /// Response structure from Groq API
        /// </summary>
        public class GroqResponse
        {
            [JsonProperty("choices")]
            public List<Choice> choices { get; set; }

            public class Choice
            {
                [JsonProperty("message")]
                public Message message { get; set; }
            }

            public class Message
            {
                [JsonProperty("content")]
                public string content { get; set; }
            }
        }

        /// <summary>
        /// Validate Groq API key format and connectivity.
        /// Returns true if key is valid and API is reachable.
        /// </summary>
        public static async Task<bool> ValidateKeyAsync(string apiKey)
        {
            if (string.IsNullOrEmpty(apiKey))
            {
                return false;
            }

            try
            {
                // Check if key starts with "gsk_"
                if (!apiKey.StartsWith("gsk_"))
                {
                    System.Diagnostics.Debug.WriteLine("Invalid Groq API key format (must start with 'gsk_')");
                    return false;
                }

                // Try a simple test call
                using (var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5)))
                {
                    var request = new HttpRequestMessage(HttpMethod.Post, BASE_URL + API_ENDPOINT);
                    request.Headers.Add("Authorization", $"Bearer {apiKey}");
                    request.Content = new StringContent(
                        JsonConvert.SerializeObject(new
                        {
                            model = MODEL,
                            messages = new[] { new { role = "user", content = "test" } },
                            max_tokens = 10
                        }),
                        System.Text.Encoding.UTF8,
                        "application/json"
                    );

                    var response = await _httpClient.SendAsync(request, cts.Token);
                    return response.IsSuccessStatusCode;
                }
            }
            catch (OperationCanceledException)
            {
                System.Diagnostics.Debug.WriteLine("Groq API validation timeout");
                return false;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Groq API validation error: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Enhance/optimize a prompt using Groq API.
        /// Returns the improved prompt or error message.
        /// </summary>
        public static async Task<string> EnhancePromptAsync(
            string apiKey,
            string originalPrompt,
            CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrEmpty(apiKey))
            {
                throw new ArgumentNullException(nameof(apiKey), "Groq API key is required");
            }

            if (string.IsNullOrEmpty(originalPrompt))
            {
                throw new ArgumentNullException(nameof(originalPrompt), "Original prompt is required");
            }

            try
            {
                using (var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken))
                {
                    cts.CancelAfter(TimeSpan.FromSeconds(TIMEOUT_SECONDS));

                    var systemPrompt = @"You are a prompt optimization expert. Improve the given prompt by:
1. Making it more specific and clear
2. Adding relevant context if needed
3. Improving structure and clarity
4. Ensuring it's actionable and measurable
5. Keeping the core intent intact

Return ONLY the improved prompt, no explanations.";

                    var requestBody = new
                    {
                        model = MODEL,
                        messages = new object[]
                        {
                            new { role = "system", content = systemPrompt },
                            new { role = "user", content = originalPrompt }
                        },
                        max_tokens = 500,
                        temperature = 0.7
                    };

                    var request = new HttpRequestMessage(HttpMethod.Post, BASE_URL + API_ENDPOINT);
                    request.Headers.Add("Authorization", $"Bearer {apiKey}");
                    request.Content = new StringContent(
                        JsonConvert.SerializeObject(requestBody),
                        System.Text.Encoding.UTF8,
                        "application/json"
                    );

                    var response = await _httpClient.SendAsync(request, cts.Token);

                    if (!response.IsSuccessStatusCode)
                    {
                        string errorContent = await response.Content.ReadAsStringAsync();
                        System.Diagnostics.Debug.WriteLine($"Groq API error: {response.StatusCode} - {errorContent}");
                        throw new Exception($"Groq API returned {response.StatusCode}");
                    }

                    string responseContent = await response.Content.ReadAsStringAsync();
                    var groqResponse = JsonConvert.DeserializeObject<GroqResponse>(responseContent);

                    if (groqResponse?.choices == null || groqResponse.choices.Count == 0)
                    {
                        throw new Exception("Invalid response from Groq API");
                    }

                    string improvedPrompt = groqResponse.choices[0].message.content.Trim();
                    System.Diagnostics.Debug.WriteLine($"Groq optimization successful (input: {originalPrompt.Length} chars, output: {improvedPrompt.Length} chars)");
                    return improvedPrompt;
                }
            }
            catch (OperationCanceledException)
            {
                System.Diagnostics.Debug.WriteLine("Groq API request timeout (>10 seconds)");
                throw new Exception("Groq API request timeout. Please try again.");
            }
            catch (HttpRequestException ex)
            {
                System.Diagnostics.Debug.WriteLine($"Groq API connection error: {ex.Message}");
                throw new Exception("Cannot reach Groq API. Check your internet connection.");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Groq API error: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Test if Groq API is reachable.
        /// </summary>
        public static async Task<bool> IsAvailableAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                using (var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken))
                {
                    cts.CancelAfter(TimeSpan.FromSeconds(5));

                    var request = new HttpRequestMessage(HttpMethod.Get, BASE_URL + "/openai/v1/models");
                    var response = await _httpClient.SendAsync(request, cts.Token);
                    return response.IsSuccessStatusCode;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}
