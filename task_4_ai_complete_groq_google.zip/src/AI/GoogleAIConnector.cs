using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace PromptOptimizer.AI
{
    /// <summary>
    /// REST API wrapper for Google AI (Gemini) API communication.
    /// Connects to Google AI using gemini-2.5-flash model.
    /// </summary>
    public class GoogleAIConnector
    {
        private static readonly string BASE_URL = 
            "https://generativelanguage.googleapis.com";
        private static readonly string API_ENDPOINT = 
            "/v1beta/models/gemini-2.5-flash:generateContent";
        private static readonly string MODEL = "gemini-2.5-flash";
        private static readonly int TIMEOUT_SECONDS = 10;

        private static HttpClient _httpClient;

        static GoogleAIConnector()
        {
            _httpClient = new HttpClient();
            _httpClient.Timeout = TimeSpan.FromSeconds(TIMEOUT_SECONDS);
        }

        /// <summary>
        /// Response structure from Google AI API
        /// </summary>
        public class GoogleResponse
        {
            [JsonProperty("candidates")]
            public List<Content> candidates { get; set; }

            public class Content
            {
                [JsonProperty("content")]
                public Parts content { get; set; }

                public class Parts
                {
                    [JsonProperty("parts")]
                    public List<Part> parts { get; set; }

                    public class Part
                    {
                        [JsonProperty("text")]
                        public string text { get; set; }
                    }
                }
            }
        }

        /// <summary>
        /// Validate Google AI API key format and connectivity.
        /// Returns true if key is valid and API is reachable.
        /// </summary>
        public static async Task<bool> ValidateKeyAsync(string apiKey)
        {
            if (string.IsNullOrEmpty(apiKey))
            {
                return false;
            }

            try
            {
                // Check if key starts with "AIza"
                if (!apiKey.StartsWith("AIza"))
                {
                    System.Diagnostics.Debug.WriteLine("Invalid Google AI API key format (must start with 'AIza')");
                    return false;
                }

                // Try a simple test call
                using (var cts = new CancellationTokenSource(TimeSpan.FromSeconds(5)))
                {
                    string url = $"{BASE_URL}{API_ENDPOINT}?key={apiKey}";
                    
                    var requestBody = new
                    {
                        contents = new object[]
                        {
                            new { parts = new[] { new { text = "test" } } }
                        },
                        generationConfig = new { maxOutputTokens = 10 }
                    };

                    var request = new HttpRequestMessage(HttpMethod.Post, url);
                    request.Content = new StringContent(
                        JsonConvert.SerializeObject(requestBody),
                        System.Text.Encoding.UTF8,
                        "application/json"
                    );

                    var response = await _httpClient.SendAsync(request, cts.Token);
                    return response.IsSuccessStatusCode;
                }
            }
            catch (OperationCanceledException)
            {
                System.Diagnostics.Debug.WriteLine("Google AI API validation timeout");
                return false;
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Google AI API validation error: {ex.Message}");
                return false;
            }
        }

        /// <summary>
        /// Enhance/optimize a prompt using Google AI API.
        /// Returns the improved prompt or error message.
        /// </summary>
        public static async Task<string> EnhancePromptAsync(
            string apiKey,
            string originalPrompt,
            CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrEmpty(apiKey))
            {
                throw new ArgumentNullException(nameof(apiKey), "Google AI API key is required");
            }

            if (string.IsNullOrEmpty(originalPrompt))
            {
                throw new ArgumentNullException(nameof(originalPrompt), "Original prompt is required");
            }

            try
            {
                using (var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken))
                {
                    cts.CancelAfter(TimeSpan.FromSeconds(TIMEOUT_SECONDS));

                    string systemPrompt = @"You are a prompt optimization expert. Improve the given prompt by:
1. Making it more specific and clear
2. Adding relevant context if needed
3. Improving structure and clarity
4. Ensuring it's actionable and measurable
5. Keeping the core intent intact

Return ONLY the improved prompt, no explanations.";

                    var requestBody = new
                    {
                        contents = new object[]
                        {
                            new { parts = new[] { new { text = systemPrompt } } },
                            new { parts = new[] { new { text = originalPrompt } } }
                        },
                        generationConfig = new { maxOutputTokens = 500 }
                    };

                    string url = $"{BASE_URL}{API_ENDPOINT}?key={apiKey}";
                    
                    var request = new HttpRequestMessage(HttpMethod.Post, url);
                    request.Content = new StringContent(
                        JsonConvert.SerializeObject(requestBody),
                        System.Text.Encoding.UTF8,
                        "application/json"
                    );

                    var response = await _httpClient.SendAsync(request, cts.Token);

                    if (!response.IsSuccessStatusCode)
                    {
                        string errorContent = await response.Content.ReadAsStringAsync();
                        System.Diagnostics.Debug.WriteLine($"Google AI API error: {response.StatusCode} - {errorContent}");
                        throw new Exception($"Google AI API returned {response.StatusCode}");
                    }

                    string responseContent = await response.Content.ReadAsStringAsync();
                    var googleResponse = JsonConvert.DeserializeObject<GoogleResponse>(responseContent);

                    if (googleResponse?.candidates == null || googleResponse.candidates.Count == 0)
                    {
                        throw new Exception("Invalid response from Google AI API");
                    }

                    var firstCandidate = googleResponse.candidates[0];
                    if (firstCandidate?.content?.parts == null || firstCandidate.content.parts.Count == 0)
                    {
                        throw new Exception("Invalid response structure from Google AI API");
                    }

                    string improvedPrompt = firstCandidate.content.parts[0].text.Trim();
                    System.Diagnostics.Debug.WriteLine($"Google AI optimization successful (input: {originalPrompt.Length} chars, output: {improvedPrompt.Length} chars)");
                    return improvedPrompt;
                }
            }
            catch (OperationCanceledException)
            {
                System.Diagnostics.Debug.WriteLine("Google AI API request timeout (>10 seconds)");
                throw new Exception("Google AI API request timeout. Please try again.");
            }
            catch (HttpRequestException ex)
            {
                System.Diagnostics.Debug.WriteLine($"Google AI API connection error: {ex.Message}");
                throw new Exception("Cannot reach Google AI API. Check your internet connection.");
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Google AI API error: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Test if Google AI API is reachable.
        /// </summary>
        public static async Task<bool> IsAvailableAsync(CancellationToken cancellationToken = default)
        {
            try
            {
                using (var cts = CancellationTokenSource.CreateLinkedTokenSource(cancellationToken))
                {
                    cts.CancelAfter(TimeSpan.FromSeconds(5));

                    // Simple connectivity test
                    string url = $"{BASE_URL}/v1beta/models";
                    var request = new HttpRequestMessage(HttpMethod.Get, url);
                    var response = await _httpClient.SendAsync(request, cts.Token);
                    return response.IsSuccessStatusCode;
                }
            }
            catch
            {
                return false;
            }
        }
    }
}
