using System;
using System.IO;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace PromptOptimizer.AI
{
    /// <summary>
    /// Manages secure storage of API keys locally in AppData.
    /// Keys are stored in JSON format and never logged or displayed.
    /// </summary>
    public class APIKeyManager
    {
        private static readonly string AppDataPath = 
            Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ApplicationData), 
                        "PromptOptimizer");
        private static readonly string KeysFilePath = 
            Path.Combine(AppDataPath, "api_keys.json");

        /// <summary>
        /// Represents the API keys configuration
        /// </summary>
        public class APIKeys
        {
            [JsonProperty("groq_api_key")]
            public string GroqApiKey { get; set; }

            [JsonProperty("google_api_key")]
            public string GoogleApiKey { get; set; }

            [JsonProperty("preferred_provider")]
            public string PreferredProvider { get; set; } // "groq" or "google"
        }

        /// <summary>
        /// Load API keys from file asynchronously.
        /// Returns empty APIKeys if file doesn't exist.
        /// </summary>
        public static async Task<APIKeys> LoadKeysAsync()
        {
            try
            {
                if (!File.Exists(KeysFilePath))
                {
                    return new APIKeys 
                    { 
                        GroqApiKey = string.Empty,
                        GoogleApiKey = string.Empty,
                        PreferredProvider = "groq"
                    };
                }

                string json = await File.ReadAllTextAsync(KeysFilePath);
                APIKeys keys = JsonConvert.DeserializeObject<APIKeys>(json);
                
                return keys ?? new APIKeys 
                { 
                    GroqApiKey = string.Empty,
                    GoogleApiKey = string.Empty,
                    PreferredProvider = "groq"
                };
            }
            catch (Exception ex)
            {
                // Log error but don't expose keys
                System.Diagnostics.Debug.WriteLine($"Error loading API keys: {ex.Message}");
                return new APIKeys 
                { 
                    GroqApiKey = string.Empty,
                    GoogleApiKey = string.Empty,
                    PreferredProvider = "groq"
                };
            }
        }

        /// <summary>
        /// Save API keys to file asynchronously.
        /// Creates AppData folder if it doesn't exist.
        /// </summary>
        public static async Task SaveKeysAsync(APIKeys keys)
        {
            try
            {
                if (keys == null)
                {
                    throw new ArgumentNullException(nameof(keys));
                }

                // Ensure AppData folder exists
                if (!Directory.Exists(AppDataPath))
                {
                    Directory.CreateDirectory(AppDataPath);
                }

                // Serialize to JSON
                string json = JsonConvert.SerializeObject(keys, Formatting.Indented);

                // Write to file
                await File.WriteAllTextAsync(KeysFilePath, json);

                System.Diagnostics.Debug.WriteLine("API keys saved successfully (keys not logged)");
            }
            catch (Exception ex)
            {
                // Log error but don't expose keys
                System.Diagnostics.Debug.WriteLine($"Error saving API keys: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Check if API keys are configured (at least one key is set).
        /// </summary>
        public static async Task<bool> HasKeysConfiguredAsync()
        {
            try
            {
                APIKeys keys = await LoadKeysAsync();
                return !string.IsNullOrEmpty(keys.GroqApiKey) 
                    || !string.IsNullOrEmpty(keys.GoogleApiKey);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Get the preferred provider (Groq or Google).
        /// Defaults to Groq if not specified.
        /// </summary>
        public static async Task<string> GetPreferredProviderAsync()
        {
            try
            {
                APIKeys keys = await LoadKeysAsync();
                return keys.PreferredProvider ?? "groq";
            }
            catch
            {
                return "groq";
            }
        }

        /// <summary>
        /// Delete all stored API keys.
        /// </summary>
        public static async Task DeleteKeysAsync()
        {
            try
            {
                if (File.Exists(KeysFilePath))
                {
                    File.Delete(KeysFilePath);
                    System.Diagnostics.Debug.WriteLine("API keys deleted");
                }
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"Error deleting API keys: {ex.Message}");
                throw;
            }
        }

        /// <summary>
        /// Get the AppData path for API keys.
        /// </summary>
        public static string GetKeysFilePath()
        {
            return KeysFilePath;
        }
    }
}
