using System;
using System.Threading;
using System.Threading.Tasks;

namespace PromptOptimizer.AI
{
    /// <summary>
    /// High-level orchestrator for AI providers with primary/fallback logic.
    /// Primary: Groq (llama-3.3-70b-versatile)
    /// Fallback: Google AI (gemini-2.5-flash)
    /// </summary>
    public class AIProvider
    {
        /// <summary>
        /// Optimize a prompt using Groq primary, Google AI fallback.
        /// Returns the optimized prompt or error message.
        /// </summary>
        public static async Task<string> OptimizePromptAsync(
            string originalPrompt,
            CancellationToken cancellationToken = default)
        {
            if (string.IsNullOrEmpty(originalPrompt))
            {
                throw new ArgumentNullException(nameof(originalPrompt), "Original prompt is required");
            }

            try
            {
                // Load API keys
                var keys = await APIKeyManager.LoadKeysAsync();

                // Check if any keys are configured
                if (string.IsNullOrEmpty(keys.GroqApiKey) && string.IsNullOrEmpty(keys.GoogleApiKey))
                {
                    return "ERROR: Keine API Keys konfiguriert. Bitte öffnen Sie API Settings. (No API keys configured. Please open API Settings.)";
                }

                // Get preferred provider
                string preferredProvider = await APIKeyManager.GetPreferredProviderAsync();

                string result = null;
                string primaryError = null;

                // Try primary provider first
                if (preferredProvider == "groq" && !string.IsNullOrEmpty(keys.GroqApiKey))
                {
                    try
                    {
                        System.Diagnostics.Debug.WriteLine("Attempting optimization with Groq (primary)...");
                        result = await GroqConnector.EnhancePromptAsync(keys.GroqApiKey, originalPrompt, cancellationToken);
                        System.Diagnostics.Debug.WriteLine("Groq optimization successful");
                        return result;
                    }
                    catch (Exception ex)
                    {
                        primaryError = ex.Message;
                        System.Diagnostics.Debug.WriteLine($"Groq optimization failed: {ex.Message}");
                    }
                }
                else if (preferredProvider == "google" && !string.IsNullOrEmpty(keys.GoogleApiKey))
                {
                    try
                    {
                        System.Diagnostics.Debug.WriteLine("Attempting optimization with Google AI (primary)...");
                        result = await GoogleAIConnector.EnhancePromptAsync(keys.GoogleApiKey, originalPrompt, cancellationToken);
                        System.Diagnostics.Debug.WriteLine("Google AI optimization successful");
                        return result;
                    }
                    catch (Exception ex)
                    {
                        primaryError = ex.Message;
                        System.Diagnostics.Debug.WriteLine($"Google AI optimization failed: {ex.Message}");
                    }
                }

                // Try fallback provider
                if (preferredProvider == "groq" && !string.IsNullOrEmpty(keys.GoogleApiKey))
                {
                    try
                    {
                        System.Diagnostics.Debug.WriteLine("Groq failed, attempting fallback with Google AI...");
                        result = await GoogleAIConnector.EnhancePromptAsync(keys.GoogleApiKey, originalPrompt, cancellationToken);
                        System.Diagnostics.Debug.WriteLine("Google AI fallback optimization successful");
                        return result;
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine($"Google AI fallback failed: {ex.Message}");
                    }
                }
                else if (preferredProvider == "google" && !string.IsNullOrEmpty(keys.GroqApiKey))
                {
                    try
                    {
                        System.Diagnostics.Debug.WriteLine("Google AI failed, attempting fallback with Groq...");
                        result = await GroqConnector.EnhancePromptAsync(keys.GroqApiKey, originalPrompt, cancellationToken);
                        System.Diagnostics.Debug.WriteLine("Groq fallback optimization successful");
                        return result;
                    }
                    catch (Exception ex)
                    {
                        System.Diagnostics.Debug.WriteLine($"Groq fallback failed: {ex.Message}");
                    }
                }

                // Both providers failed
                return "ERROR: Alle Optimierungsanbieter fehlgeschlagen. Bitte überprüfen Sie Ihre API Keys. (All optimization providers failed. Please check your API keys.)";
            }
            catch (Exception ex)
            {
                System.Diagnostics.Debug.WriteLine($"AIProvider error: {ex.Message}");
                return $"ERROR: {ex.Message}";
            }
        }

        /// <summary>
        /// Get the current active provider status.
        /// Returns "Groq", "Google", or "Not Configured"
        /// </summary>
        public static async Task<string> GetActiveProviderAsync()
        {
            try
            {
                var keys = await APIKeyManager.LoadKeysAsync();

                if (string.IsNullOrEmpty(keys.GroqApiKey) && string.IsNullOrEmpty(keys.GoogleApiKey))
                {
                    return "Not Configured";
                }

                string preferredProvider = await APIKeyManager.GetPreferredProviderAsync();

                if (preferredProvider == "groq" && !string.IsNullOrEmpty(keys.GroqApiKey))
                {
                    return "Groq";
                }
                else if (preferredProvider == "google" && !string.IsNullOrEmpty(keys.GoogleApiKey))
                {
                    return "Google";
                }
                else if (!string.IsNullOrEmpty(keys.GroqApiKey))
                {
                    return "Groq";
                }
                else if (!string.IsNullOrEmpty(keys.GoogleApiKey))
                {
                    return "Google";
                }

                return "Not Configured";
            }
            catch
            {
                return "Not Configured";
            }
        }

        /// <summary>
        /// Check if any provider is available.
        /// </summary>
        public static async Task<bool> IsAnyProviderAvailableAsync()
        {
            try
            {
                var keys = await APIKeyManager.LoadKeysAsync();
                return !string.IsNullOrEmpty(keys.GroqApiKey) || !string.IsNullOrEmpty(keys.GoogleApiKey);
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Validate API keys before saving.
        /// </summary>
        public static async Task<(bool isValid, string message)> ValidateKeysAsync(string groqKey, string googleKey)
        {
            try
            {
                if (string.IsNullOrEmpty(groqKey) && string.IsNullOrEmpty(googleKey))
                {
                    return (false, "Mindestens ein API Key ist erforderlich. (At least one API key is required.)");
                }

                if (!string.IsNullOrEmpty(groqKey))
                {
                    if (!groqKey.StartsWith("gsk_"))
                    {
                        return (false, "Groq API Key ungültig. Muss mit 'gsk_' beginnen. (Invalid Groq key format. Must start with 'gsk_'.)");
                    }

                    bool groqValid = await GroqConnector.ValidateKeyAsync(groqKey);
                    if (!groqValid)
                    {
                        return (false, "Groq API Key ungültig oder nicht erreichbar. (Invalid Groq API key or unreachable.)");
                    }
                }

                if (!string.IsNullOrEmpty(googleKey))
                {
                    if (!googleKey.StartsWith("AIza"))
                    {
                        return (false, "Google AI API Key ungültig. Muss mit 'AIza' beginnen. (Invalid Google key format. Must start with 'AIza'.)");
                    }

                    bool googleValid = await GoogleAIConnector.ValidateKeyAsync(googleKey);
                    if (!googleValid)
                    {
                        return (false, "Google AI API Key ungültig oder nicht erreichbar. (Invalid Google AI API key or unreachable.)");
                    }
                }

                return (true, "Alle API Keys sind gültig. (All API keys are valid.)");
            }
            catch (Exception ex)
            {
                return (false, $"Validierungsfehler: {ex.Message} (Validation error: {ex.Message})");
            }
        }
    }
}
