# Prompt Optimizer - AI Integration Layer (Task 4)

## Overview

This deliverable contains the complete AI integration layer for the Prompt Optimizer Windows application, connecting to Groq (primary) and Google AI (fallback) for prompt optimization.

## What's Included

### Core AI Integration Files
- **APIKeyManager.cs** - Secure local storage of API keys in AppData
- **GroqConnector.cs** - REST API wrapper for Groq (llama-3.3-70b-versatile)
- **GoogleAIConnector.cs** - REST API wrapper for Google AI (gemini-2.5-flash)
- **AIProvider.cs** - High-level orchestrator with primary/fallback logic
- **APILogger.cs** - Logging of API interactions (no sensitive data)

### Documentation
- **INTEGRATION_GUIDE.md** - Complete integration guide with code examples
- **README.md** - This file

## Key Features

✅ **Secure Key Storage** - API keys stored locally in AppData, never logged or displayed
✅ **Primary/Fallback Logic** - Automatic failover from Groq to Google AI
✅ **Key Validation** - Format and connectivity validation before saving
✅ **Error Handling** - Graceful error handling with user-friendly messages (German)
✅ **Async/Await** - Non-blocking network calls for responsive UI
✅ **Comprehensive Logging** - All interactions logged without exposing keys
✅ **Timeout Protection** - 10-second timeout per API call with automatic retry
✅ **CancellationToken Support** - Cancellable requests for responsive UI

## Quick Start

### 1. Add to Your Project
Copy the `src/AI/` folder to your Prompt Optimizer project:
```
YourProject/
├── src/
│   ├── UI/
│   ├── Engine/
│   ├── AI/                    ← Copy here
│   │   ├── APIKeyManager.cs
│   │   ├── GroqConnector.cs
│   │   ├── GoogleAIConnector.cs
│   │   ├── AIProvider.cs
│   │   └── APILogger.cs
│   ├── Database/
│   └── Utils/
```

### 2. Install NuGet Dependencies
```powershell
Install-Package Newtonsoft.Json
```

### 3. Get API Keys
- **Groq**: https://console.groq.com (free: 14,400 tokens/day)
- **Google AI**: https://aistudio.google.com (free: 32,000 tokens/day)

### 4. Integrate with MainForm.cs
```csharp
// In your MainForm button click handler
private async void BtnOptimize_Click(object sender, EventArgs e)
{
    try
    {
        lblStatus.Text = "Optimizing...";
        string result = await AIProvider.OptimizePromptAsync(txtInputPrompt.Text);
        
        if (result.StartsWith("ERROR:"))
        {
            MessageBox.Show(result, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
        else
        {
            txtOutputPrompt.Text = result;
            lblProvider.Text = $"Provider: {await AIProvider.GetActiveProviderAsync()}";
        }
    }
    catch (Exception ex)
    {
        MessageBox.Show($"Error: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
    }
}
```

## API Key Storage

Keys are stored in:
```
C:\Users\[User]\AppData\Roaming\PromptOptimizer\api_keys.json
```

Example structure:
```json
{
  "groq_api_key": "gsk_...",
  "google_api_key": "AIza...",
  "preferred_provider": "groq"
}
```

## Error Messages

### German Error Messages
- "Groq API Key ungültig. Bitte überprüfen Sie den Key."
- "Google AI API Key ungültig. Bitte überprüfen Sie den Key."
- "Groq nicht erreichbar. Fallback zu Google..."
- "Google AI nicht erreichbar. Fallback zu Groq..."
- "Keine API Keys konfiguriert. Bitte öffnen Sie API Settings."
- "Alle Optimierungsanbieter fehlgeschlagen. Bitte überprüfen Sie Ihre API Keys."

## API Key Formats

### Groq API Key
- Format: `gsk_...` (starts with "gsk_")
- Get from: https://console.groq.com
- Free tier: 14,400 tokens/day

### Google AI API Key
- Format: `AIza...` (starts with "AIza")
- Get from: https://aistudio.google.com
- Free tier: 32,000 tokens/day

## Logging

All API interactions are logged to:
```
C:\Users\[User]\AppData\Roaming\PromptOptimizer\logs\api.log
```

Log entries include:
- Timestamp
- Provider (Groq or Google)
- Request/response metadata
- Error information
- Retry attempts

**Important**: API keys and full prompts are NEVER logged.

## Architecture

### Primary/Fallback Logic
1. Load API keys from AppData
2. Try primary provider (user's preference)
3. On failure, try fallback provider
4. If both fail, return error message

### Timeout Handling
- 10-second timeout per API call
- On timeout, automatically tries fallback
- If both timeout, returns error

### Error Handling
- Invalid key format detected before API call
- Connection failures caught and logged
- Network errors trigger fallback
- User-friendly error messages (German + English)

## Performance

- **Async/Await**: Non-blocking network calls
- **HTTP Client Reuse**: Connection pooling
- **Timeout**: 10 seconds per request
- **Retry**: Once on timeout before fallback
- **Cancellation**: CancellationToken support for responsive UI

## Security

### Key Protection
- Keys stored locally only (AppData\Roaming)
- Never logged or displayed
- Never transmitted except to official APIs
- Never backed up to cloud
- User can delete by deleting api_keys.json

### Best Practices
- Regenerate keys if compromised
- Use separate keys for dev/production
- Monitor API usage in provider dashboards
- Rotate keys periodically

## Testing

### Validate Keys
```csharp
bool valid = await GroqConnector.ValidateKeyAsync("gsk_...");
bool valid = await GoogleAIConnector.ValidateKeyAsync("AIza...");
```

### Optimize Prompt
```csharp
string improved = await AIProvider.OptimizePromptAsync("Your prompt here");
```

### Check Provider Status
```csharp
string provider = await AIProvider.GetActiveProviderAsync();
bool available = await AIProvider.IsAnyProviderAvailableAsync();
```

## Troubleshooting

### "Invalid API key format"
- Groq keys must start with `gsk_`
- Google keys must start with `AIza`
- Check for typos or extra spaces

### "Cannot reach [Provider]"
- Check internet connection
- Verify firewall allows HTTPS
- Check provider status page

### "Timeout (>10 seconds)"
- Check internet speed
- Try again (may be temporary)
- Fallback provider will be attempted

### "All optimization providers failed"
- Verify both API keys are valid
- Check internet connection
- Check logs for detailed errors

## File Structure

```
task_4_ai_complete_groq_google/
├── src/
│   └── AI/
│       ├── APIKeyManager.cs
│       ├── GroqConnector.cs
│       ├── GoogleAIConnector.cs
│       ├── AIProvider.cs
│       └── APILogger.cs
├── INTEGRATION_GUIDE.md
└── README.md
```

## Dependencies

### Required
- .NET 4.7.2 or higher
- Newtonsoft.Json (NuGet)

### Optional
- log4net (for advanced logging)

## Next Steps

1. Copy the `src/AI/` folder to your project
2. Install Newtonsoft.Json NuGet package
3. Add API Settings dialog (Task 2) for key entry
4. Integrate with MainForm.cs (see Quick Start)
5. Test with real API keys from Groq and Google
6. Deploy and monitor logs

## Support Resources

- **Groq Documentation**: https://console.groq.com/docs
- **Google AI Documentation**: https://ai.google.dev
- **Integration Guide**: See INTEGRATION_GUIDE.md
- **Logs**: C:\Users\[User]\AppData\Roaming\PromptOptimizer\logs\api.log

## License

This integration layer is part of the Prompt Optimizer project.

## Version

- **Version**: 1.0
- **Date**: January 2024
- **Status**: Production Ready
